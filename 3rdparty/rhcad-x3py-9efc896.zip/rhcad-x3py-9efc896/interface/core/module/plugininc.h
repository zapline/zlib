#ifndef X3_CORE_PLUGIN_INC_H
#define X3_CORE_PLUGIN_INC_H

#include <portability/x3port.h>
#include <module/classmacro.h>

//#include <utilfunc/vecfunc.h>
//#include <portability/func_s.h>

#endif