// x3py framework: https://github.com/rhcad/x3py
#ifndef X3_CORE_MANAGER_CLSID_H
#define X3_CORE_MANAGER_CLSID_H

#include <objptr.h>

BEGIN_NAMESPACE_X3

const char* const clsidManager = "1137fdae-fd69-4d4c-b3d1-e8f57b55f27e";

END_NAMESPACE_X3
#endif