
// demonstrate formatted objects

#include <lfc>
using namespace lfc;


class Test : public Object, public virtual _Formatable
{
public:
	virtual void formatObject(TextOutput &ts, string format = "") const throw()
	{
	    TRACE(Test::formatObject(TextOutput &ts, string format) const);

		ts << format;
	}
};


class TestTextStream4 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestTextStream5::main());

		Test obj;

		lfcOut << "[" << obj << "]\n";
		lfcOut << "[" << formattedOut(obj, "HH:MM:SS") << "]\n";

		lfcOut << "[";
		obj.formatObject(lfcOut, "the other way...");
		lfcOut << "]\n";
	}
} app;


