
#include <lfc>
using namespace lfc;


// demonstrate TextOutput::printf()
class TestTextStream3 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestTextStream3::main());

		File f("test3.txt", File::flWrite | File::flTruncate);
		TextOutput to(f);

		to.printf("Hello, world %s%c\n", "LFC2", '!');
		to.printf("%d %f\n", 128, 1000.25);
	}
} app;


