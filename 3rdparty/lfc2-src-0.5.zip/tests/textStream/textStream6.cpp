
// demonstrate flWriteThrough flag on File::Open()

#include <lfc>
using namespace lfc;


class TestTextStream6 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestTextStream6::main());

		File f("test6.txt",
		    File::flWrite | File::flTruncate | File::flWriteThrough);
		TextOutput to;

		to.connectOutputBase(f);
		to.connectOutputBase(lfcConsole);

		to << "Hello, world!\n";
	}
} app;


