
#include <lfc>
using namespace lfc;


// demonstrate MemoryIO
class TestTextStream4 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestTextStream4::main());

		MemoryIO buff;
		string s1 = "LFC 2.0";

		TextOutput(buff) << "[" << s1 << "]";
		lfcOut << s1 << " : " << buff.contents() << ENDL;
	}
} app;


