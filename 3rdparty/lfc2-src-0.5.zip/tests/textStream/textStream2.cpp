
#include <lfc.threads.application>
#include <lfc.streams.file>
#include <lfc.streams.console>
#include <lfc.streams.textStream>
using namespace lfc;


class TestTextStream2 : public Application
{
protected:
	virtual void test(TextOutput &to)
	{
	    TRACE(TestTextStream2::test(TextOutput &to));

		to << '\n';
		to << true << '\n';
		to << "LFC team presents..." << '\n' << "LFC 2.0!" << '\n';
		to << int(16) << '\n';
		to << short(16) << '\n';
		to << long(16) << '\n';
		to << float(16) << '\n';
		to << double(16) << '\n';
		to << Word(16) << '\n';
		to << DWord(16) << '\n';
	}

	virtual void main()
	{
	    TRACE(TestTextStream2::main());

		Console console;
		File f("test2.txt", File::flWrite);
		TextOutput to(f);

		to.setWidth(60);
		to.setAlign(TextOutput::left);
		to.setFillChar('_');
		test(to);

		to.connectOutputBase(console);

		to.setAlign(TextOutput::center);
		to.setPrecision(4);
		test(to);

		to.setAlign(TextOutput::right);
		to.setIntegerBase('X');
		test(to);

		f.close();
	}
} app;


