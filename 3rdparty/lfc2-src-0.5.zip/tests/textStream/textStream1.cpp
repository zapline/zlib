
#include <lfc.threads.application>
#include <lfc.streams.file>
#include <lfc.streams.textStream>
using namespace lfc;


class TestTextStream1 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestTextStream1::main());

		File f("test1.txt", File::flWrite);

		TextOutput(f) << true;
		TextOutput(f) << '!';
		TextOutput(f) << "\nLFC team presents...\n" << "LFC 2.0!\n";
		TextOutput(f) << int(16) << '\n';
		TextOutput(f) << short(16) << '\n';
		TextOutput(f) << long(16) << '\n';
		TextOutput(f) << float(16) << '\n';
		TextOutput(f) << double(16) << '\n';
		TextOutput(f) << Word(16) << '\n';
		TextOutput(f) << DWord(16) << '\n';

		f.close();
	}
} app;


