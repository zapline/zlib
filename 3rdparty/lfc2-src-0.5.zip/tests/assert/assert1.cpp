
// simple assert demonstration
//

#include <lfc>

using namespace lfc;


class Assert1 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Assert1::main());

	    test();
	}

	void test()
	{
	    TRACE(Assert1::test());

        Assert1::foo(1, 2);
	}

	static void foo(int a, int b)
	{
	    TRACE(Assert1::foo(int, int));

	    ASSERT(a != b);
	    ASSERT(a == b);
	}
} app;


