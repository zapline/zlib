
// simple assert demonstration
// (the same as assert1, with the asserts disabled)
//

#define LFC_DISABLE_ASSERTS

#include <lfc>
using namespace lfc;


class Assert2 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Assert2::main());

	    test();
	}

	void test()
	{
	    TRACE(Assert2::test());

        Assert2::foo(1, 2);
	}

	static void foo(int a, int b)
	{
	    TRACE(Assert2::foo(int, int));

	    ASSERT(a != b);
	    ASSERT(a == b);
	}
} app;


