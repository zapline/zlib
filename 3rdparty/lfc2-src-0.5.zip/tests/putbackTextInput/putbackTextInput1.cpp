
#include <lfc>
#include <ctype.h>
using namespace lfc;

const char *STREAM_DATA = "012345678901234567890123456789";

// This is a functionality test for the PutbackTextInput stream.  It does a
// tests to ensure that the putback test input is working, that it barfs when
// it tries to unread too much, etc.
class PutbackTest1 : public Application
{
protected:
	static const int   DATA_CNT = 30;
	static const int   BUFFER_SIZE = 5;
	// BUFFER_SIZE % PUTBACK_SIZE != 0 -- makes things easier to test
	static const long  PUTBACK_SIZE = 9;

	virtual void main()
	{
	    TRACE(PutbackTest1::main());

		MemoryIO memStream(DATA_CNT);
		// Make a very small putback buffer
		PutbackTextInput pbIn(memStream, PUTBACK_SIZE);
		int pos = -1; // we manually keep track of where we are in pbIn
		char c;
		char buffer[BUFFER_SIZE];
		// initialize the memroy stream
		lfcOut << "Initializing stream." << ENDL;
		memStream.write(STREAM_DATA, DATA_CNT);

		// Test failure of unread after no read() calls.
		try
		{
			pbIn.putback(2);
			lfcOut << "Failed!: putback 2 when pos = " << pos <<
				ENDL;
			Thread::exit();
		}
		catch(PutbackTextException &e)
		{
			lfcOut << "Passed: disallowed putback of more than " <<
				"actually read (no calls to read() made)." <<
				ENDL;
		}
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);

		// Test failure of unread of too many characters
		try
		{
			pbIn.putback(2);
			lfcOut << "Failed!: putback 2 when pos = " << pos <<
				ENDL;
			Thread::exit();
		}
		catch(PutbackTextException &e)
		{
			lfcOut << "Passed: disallowed putback of more than " <<
				"actually read (after call to read())" << ENDL;
		}
		// Test a putback()
		try
		{
			// Make sure we can put back a single character.
			pbIn.putback(1);
			lfcOut << "Passed: successfully putback single " <<
				"character read." << ENDL;
		}
		catch(PutbackTextException &e)
		{
			lfcOut << "Failed!: Didn't unread single character " <<
				"at pos = " << pos << ENDL;
			Thread::exit();
		}
		// validate character
		c = pbIn.pop();
		// position has stayed the same.
		testCharacter(c, pos);

		// Read in a little more, then don't clean out the entire
		// stream.
		pbIn.read(buffer, BUFFER_SIZE);
		pos += BUFFER_SIZE;
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);
		// Test putting back multiple characters
		try
		{
			pbIn.putback(BUFFER_SIZE);
		}
		catch(PutbackTextException &e)
		{
			lfcOut << "Failed!: Didn't allow putback of " <<
				BUFFER_SIZE << " when pos = " << pos << ENDL;
			Thread::exit();
		}
		pos -= BUFFER_SIZE;
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);
		lfcOut << "Passed: Allowed putback of multiple characters." <<
			ENDL;
		// Unread all the characters
		try
		{
			pbIn.putback(pos + 1);
			pos = -1;
		}
		catch(PutbackTextException &e)
		{
			lfcOut << "Failed!: to put back all characters" << ENDL;
			Thread::exit();
		}

		// Test reading beyond the half-buffer boundary
		pbIn.read(buffer, BUFFER_SIZE);
		pos += BUFFER_SIZE;
		pbIn.read(buffer, BUFFER_SIZE);
		pos += BUFFER_SIZE;
		// I have gone past the half-buffer boundary
		c = pbIn.pop();
		c = pbIn.pop();
		pos += 2;
		testCharacter(c, pos);
		// Test an unread that stays beyond the boundary
		try
		{
			pbIn.putback(1);
			c = pbIn.pop();
			// position stayed the same
			testCharacter(c, pos);
			lfcOut << "Passed: putback character beyond boundary" <<
					ENDL;
		}
		catch(PutbackTextException e)
		{
			lfcOut << "Failed!: unable to putback character " <<
				"beyond boundary." << ENDL;
			Thread::exit();
		}
		c = pbIn.pop();
		pos++;
		// Test an unread that goes back over the boundary
		try
		{
			// unread over boundary
			pbIn.putback(BUFFER_SIZE);
			pos -= BUFFER_SIZE;
			lfcOut << "Passed: putback unread over boundary." <<
				ENDL;
		}
		catch(PutbackTextException e)
		{
			lfcOut << "Failed: to putback " << BUFFER_SIZE <<
				" chars when pos = " << pos + BUFFER_SIZE <<
				ENDL;
			Thread::exit();
		}
		// Go back over the boundary with the read
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);
		pbIn.read(buffer, BUFFER_SIZE);
		pos += 5;
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);
		lfcOut << "Passed: Reread over boundary correctly." << ENDL;

		// Read enough to go to the third half-buffer
		pbIn.read(buffer, BUFFER_SIZE);
		pbIn.read(buffer, BUFFER_SIZE);
		pos += BUFFER_SIZE * 2;
		c = pbIn.pop();
		pos++;
		testCharacter(c, pos);
		lfcOut << "Passed: Read third half-buffer correctly." << ENDL;
		lfcOut << "Passed all tests" << ENDL;
	}

	virtual void testCharacter(char c, long pos)
	{
	    TRACE(PutbackTest1::testCharacter(char c, long pos));

		// The test below makes sure that the integer value of the
		// character is (1) a digit and (2) the same value as the
		// position, at least modulo 10
		if(!isdigit(c) || ((c - '0' - pos) % 10) != 0)
		{
			lfcOut << "Failed!: stream returned invalid " <<
				"character '" << c << "' at pos = " << pos <<
				ENDL;
			Thread::exit();
		}
	}
} app;
