
#include <lfc>
#include <ctype.h>
using namespace lfc;

class PutbackTest2 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(PutbackTest2::main());

		File f("putback2.txt");
		in = new PutbackTextInput(f);
		lfcOut << "------------------------------------------" << ENDL;
		lfcOut << "This test takes the file putback2.txt and"  << ENDL;
		lfcOut << "puts quotes around strings, puts () around" << ENDL;
		lfcOut << "integers, puts {} around floats and"        << ENDL;
		lfcOut << "compresses multiple spaces into one, and"   << ENDL;
		lfcOut << "multiple lines into one."                   << ENDL;
		lfcOut << "------------------------------------------" << ENDL;
		lfcOut << "---------Start tokenized output-----------" << ENDL;
		tokenize();
		lfcOut << "----------End tokenized output------------" << ENDL;
	}

	// This actually goes through all the tokens.
	virtual void tokenize()
	{
	    TRACE(PutbackTest2::tokenize());

		char c;
		while(in->hasMore())
		{
			c = in->pop();
			if(isdigit(c))
			{
				in->putback(1);
				if(!readFloat())
				{
					readInt();
				}
			}
			else if(isspace(c))
			{
				if(c == '\n')
				{
					bool hasMore;
					// compress newlines into a single
					// line
					lfcOut << ENDL;
					while( (hasMore = in->hasMore()) != 0 &&
							in->pop() == '\n')
						;
					if(hasMore)
						in->putback(1);
				}
				else
				{
					bool hasMore;
					// compress spaces into a single space
					lfcOut << ' ';
					while( (hasMore = in->hasMore()) != 0 &&
							isspace(in->pop()))
						;
					if(hasMore)
						in->putback(1);
				}
			}
			else
			{
				in->putback(1);
				readString();
			}
		}
	}

	// Floats are always like <digits>.<digits>, nothing else.
	virtual bool readFloat()
	{
	    TRACE(PutbackTest2::readFloat());

		char c;
		string s;
		long cnt = 0;
		while(in->hasMore())
		{
			c = in->pop();
			cnt++;
			if(isdigit(c))
			{
				s.append(&c, 1);
			}
			else
			{
				break;
			}
		}
		if(c == '.')
		{
			s.append(&c, 1);
		}
		else
		{
			in->putback(cnt);
			return false;
		}
		c = in->pop();
		cnt++;
		if(isdigit(c))
		{
			s.append(&c, 1);
		}
		else
		{
			in->putback(cnt);
			return false;
		}
		while(in->hasMore())
		{
			c = in->pop();
			cnt++;
			if(isdigit(c))
			{
				s.append(&c, 1);
			}
			else
			{
				in->putback(1);
				break;
			}
		}
		lfcOut << '{' << s << '}';
		return true;
	}

	// Integers are strings of digits
	virtual bool readInt()
	{
	    TRACE(PutbackTest2::readInt());

		char c;
		string s;
		while(in->hasMore())
		{
			c = in->pop();
			if(isdigit(c))
			{
				s.append(&c, 1);
			}
			else
			{
				// Unread the invalid character
				in->putback(1);
				break;
			}
		}
		lfcOut << '(' << s << ')';
		return true;
	}

	// Strings end in spaces or digits
	virtual bool readString()
	{
	    TRACE(PutbackTest2::readString());

		char c;
		string s;
		while(in->hasMore())
		{
			c = in->pop();
			if(!isspace(c) && !isdigit(c))
			{
				s.append(&c, 1);
			}
			else
			{
				// Unread the invalid character
				in->putback(1);
				break;
			}
		}
		lfcOut << '"' << s << '"';
		return true;
	}

	PutbackTextInput *in;
} app;
