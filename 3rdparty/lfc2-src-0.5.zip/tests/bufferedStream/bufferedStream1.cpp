
#include <lfc.globals>
#include <lfc.threads>
#include <lfc.streams>

using namespace lfc;


// This is a test of the functionality of the buffered stream. All it does is
// read from a buffered stream, character by character.
class TestBufferedStream1 : public Application
{
protected:
	// This is not necessarily super fast because I use pop() repeatedly
	// It is more a test of functionality.
	virtual void main()
	{
		if(m_arguments.size() != 2) 
		{
			lfcOut << "Usage: " << m_arguments[0] << " <file>"
			       << ENDL;
			lfcOut << "This tests character-by-character buffered "
			       << "input by copying a file to stdout." << ENDL;
			Thread::exit();
		}

		File f(m_arguments[1].c_str(), File::flRead);
		BufferedInput<char> in(f);
		char c;

		while(in.hasMore())
		{
			c = in.pop();
			lfcOut << c;
		}
	}
} app;


