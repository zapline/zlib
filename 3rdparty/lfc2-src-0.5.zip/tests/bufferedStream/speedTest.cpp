
#include <lfc.globals>
#include <lfc.threads>
#include <lfc.time.chronometer>
#include <lfc.streams>

using namespace lfc;


const int ITERATIONS = 100;

class BufferedSpeedTest : public Application
{
protected:
	virtual void main()
	{
		int i;
		long totalBuffTime, totalUnbuffTime;
		const char *fileName;

		if (m_arguments.size() != 2)
		{
			lfcOut << "Usage: " << m_arguments[0] << " <file>" 
			       << ENDL;
			lfcOut << "This does a speed comparison between "
			       << "buffered and unbuffered input." << ENDL;
			lfcOut << "It reads <file> " << ITERATIONS << " times"
			       << " and provides an average read time for"
			       << " the two methods." << ENDL;
			Thread::exit();
		}

		fileName = m_arguments[1].c_str();
		totalBuffTime = 0;
		totalUnbuffTime = 0;
		lfcOut << "[Starting unbuffered time test]" << ENDL;
		for(i = 0; i < ITERATIONS; ++i)
		{
			File f(fileName, File::flRead);
			totalUnbuffTime += timeSlurp(f);
			lfcOut << "\tCompleted unbuffered iteration "
			       << i << ENDL;
		}

		lfcOut << "[Done with unbuffered time test]" << ENDL;
		lfcOut << "[Starting buffered time test]" << ENDL;
		for(i = 0; i < ITERATIONS; ++i)
		{
			File f(fileName, File::flRead);
			BufferedInput<char > in(f);
			totalBuffTime += timeSlurp(in);
			lfcOut << "\tCompleted buffered iteration "
			       << i << ENDL;
		}

		lfcOut << "[Done with buffered time test]" << ENDL;
		lfcOut << "Unbuffered read average: "
		       << ((double )totalUnbuffTime / (double )ITERATIONS)
		       << ENDL;
		lfcOut << "Buffered read average: "
		       << ((double )totalBuffTime / (double )ITERATIONS)
		       << ENDL;
	}

	virtual long timeSlurp(_Input<char > &in)
	{
		Chronometer timer;
		char c;

		timer.start();
		while(in.hasMore()) 
		{
			c = in.pop();
		}
		timer.stop();

		return timer.duration().milliseconds();
	}
} app;


