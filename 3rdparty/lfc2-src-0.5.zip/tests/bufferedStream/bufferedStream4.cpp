
#include <lfc.globals>
#include <lfc.threads>
#include <lfc.streams>

using namespace lfc;

// This is a more 'real world' example of how one might use the buffered
// streams.  It reads in input and writes its output to a file named
// <file>.line.  The new file has line numbers in it.
class TestBufferedStream4 : public Application 
{
protected:
	virtual void main()
	{
		if(m_arguments.size() != 2)
		{
			lfcOut << "Usage: " << m_arguments[0] << " <file>"
			       << ENDL;
			lfcOut << "This reads in <file> and writes it to "
			       << "<file>.line, adding line numbers" << ENDL;
			Thread::exit();
		}
		File fIn(m_arguments[1].c_str(), File::flRead);
		File fOut((m_arguments[1] + ".line").c_str(), File::flWrite);
		BufferedOutput<char> bOut(fOut);
		BufferedInput<char> in(fIn);
		TextOutput out(bOut);

		char c;
		int line = 1;
		out << line << ": ";
		line++;
		// Read the input
		while(in.hasMore()) 
		{
			c = in.pop();
			out << c;
			if(c == '\n') // write out a line number
				out << line++ << ": ";
		}
		// This always needs to be called when using buffered outputs.
		out.flush();
	}

} app;
