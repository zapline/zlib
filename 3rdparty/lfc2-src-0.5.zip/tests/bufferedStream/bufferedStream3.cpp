
#include <lfc.globals>
#include <lfc.threads>
#include <lfc.streams>

using namespace lfc;


// This tests whether reading/writing in fragments of odd amounts 
// (amounts which don't divide the buffer size) causes problems. It creates a
// file called test3.txt which should be compared to the original file.
class TestBufferedStream3 : public Application
{
protected:
	static const long BUFFER_SIZE = 1024;
	static const long READ_SIZE   = 141;  // READ_SIZE % BUFFER_SIZE != 0

	virtual void main()
	{
		if(m_arguments.size() != 2)
		{
			lfcOut << "Usage: " << m_arguments[0] << " <file>"
			       << ENDL;
			lfcOut << "This tests block buffered input and output"
			       << " by copying file <file> " << ENDL;
			lfcOut << "to a file called 'test3.txt'." << ENDL;
			Thread::exit();
		}

		File fIn(m_arguments[1].c_str());
		BufferedInput<char> in(fIn, BUFFER_SIZE);
		File fOut("test3.txt", File::flWrite);
		BufferedOutput<char> out(fOut, BUFFER_SIZE);
		char buffer[READ_SIZE];

		while(in.hasMore())
		{
			long read = in.read(buffer, READ_SIZE);
			out.write(buffer, read);
		}

		out.flush(); // to get the last bit of data.
		lfcOut << "Wrote " << m_arguments[1] << " to test3.txt" << ENDL;
		lfcOut << "Please do a diff and make sure they are the same"
		       << ENDL;
	}
} app;


