
#include <lfc.globals>
#include <lfc.threads>
#include <lfc.streams>

using namespace lfc;


// This tests the buffered output stream by reading in a text file and 
// writing it to a file called test2.txt. This is done character by charcter.
class TestBufferedStream2 : public Application
{
protected:
	virtual void main()
	{
		if(m_arguments.size() != 2)
		{
			lfcOut << "Usage: " << m_arguments[0] << " <file>"
			       << ENDL;
			lfcOut << "This tests character-by-character buffered"
			       << " output by copying <file> to a file named"
			       << " 'test2.txt'." << ENDL;
			Thread::exit();
		}

		File fIn(m_arguments[1].c_str(), File::flRead);
		File fOut("test2.txt", File::flWrite);
		BufferedInput<char> in(fIn);
		BufferedOutput<char> out(fOut);
		char c;

		lfcOut << "Writing " << m_arguments[1] << " to test2.txt"
		       << ENDL;

		while(in.hasMore())
		{
			c = in.pop();
			out.push(c);
		}

		out.flush();
	}
} app;


