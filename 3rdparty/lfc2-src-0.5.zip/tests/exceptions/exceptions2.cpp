
// test exceptions, stack traces
//

#include <lfc>

using namespace lfc;


class TestApp : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestApp::main());

	    test();
	}

	void test()
	{
	    TRACE(TestApp::test());

        TestApp::foo(1, 2);
	}

	static void foo(int a, int b)
	{
	    TRACE(TestApp::foo(int, int));
	    throw Exception("just testing exceptions...");
	}
} app;


