
// test exceptions, stack traces
//

#include <lfc>

using namespace lfc;


class TestApp : public Application
{
protected:
	virtual void main()
	{
	    TRACE(TestApp::main());

	    test();
	}

	void test()
	{
	    TRACE(TestApp::test());

        TestApp::foo(1, 2);
	}

	static void foo(int a, int b)
	{
	    TRACE(TestApp::foo(int, int));

	    // try to open an inexistent file
	    // (to force the throwing of an exception)
	    //
	    File f("inexistent.file", File::flOpenExisting);
	}
} app;


