
#include <lfc>

using namespace lfc;

class Regexp2 : public Application 
{
protected:
	virtual void main()
	{
		RegexpPattern *pattern;
		if(m_arguments.size() < 3)
		{
			lfcOut << "Usage: " << m_arguments[0] << 
				" <pattern> <file1> ..." << ENDL;
			Thread::exit();
		}

		try
		{
			pattern = new RegexpPattern(m_arguments[1]);
		} 
		catch(RegexpException &e)
		{
			lfcOut << "Pattern error: " << e.message() << ENDL;
			Thread::exit();
		}

		for(unsigned int i = 2; i < m_arguments.size(); i++)
		{
			try
			{
				grep(pattern, m_arguments[i]);
			}
			catch(Exception &e)
			{
				lfcOut << "Unforseen exception: " << 
					e.message() << ENDL;
				Thread::exit();
			}
		}
	}

	virtual void grep(RegexpPattern *pattern, string name)
	{
		File f(name, File::flRead);
		BufferedInput<char> in(f);
		RegexpMatch match;
		string line;
		int lineCnt = 1;

		while(in.hasMore()) 
		{
			line = nextLine(in);
			try
			{
				if(pattern->match(line, match))
					lfcOut << name << ": " << lineCnt 
						<< ": " << line << ENDL;
			} 
			catch(RegexpException &e)
			{
				lfcOut << "Pattern error: " << e.message() <<
					ENDL;
				Thread::exit();
			}
		}
	}

	virtual string nextLine(_Input<char> &in)
	{
		string line = "";
		char c;
		while(in.hasMore())
		{
			c = in.pop();
			if(c == '\r')
			{
				if((c = in.pop()) == '\n')
				{
					return line;
				}
				else
				{
					line.append("\r");
					line.append(&c, 1);
				}
			}
			else if(c == '\n')
			{
				return line;
			}
			else
			{
				line.append(&c, 1);
			}
		}
		return line;
	}
} app;
