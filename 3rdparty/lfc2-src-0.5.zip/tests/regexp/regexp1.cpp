
#include <lfc>

using namespace lfc;

struct RegexpTestElement
{
	char *pattern;
	char *input;
	char *match;
	int   offset;
	bool  exception;
};


const static RegexpTestElement tests[] = 
{
	{ "no", "yes", NULL, 0, false },
	{ "no", "myno!", "no", 2, false },
	{ "^no", "myno!", NULL, 0, false },
	{ "no", "nnono", "no", 1, false},
	{ "yes$", "noyesno", NULL, 0, false },
	{ "yes$", "no, this is yes", "yes", 12, false },
	{ "[a-z]", "yes", "y", 0, false},
	{ "[A-Z]", "yes", NULL, 0, false},
	{ "[A-Z]", "yEs", "E", 1, false},
	{ "[a-zA-Z]", "yes", "y", 0, false},
	{ "[0-9]", "yes", NULL, 0, false},
	{ "[abc]", "yes", NULL, 0, false},
	{ "[w-z]b", "yes", NULL, 0, false},
	{ "[w-z]e", "yes", "ye", 0, false},
	{ "[w-z]s", "yes", NULL, 0, false},
	{ "[a-z]s$", "yes", "es", 1, false},
	{ "[\\taby]", "see\t", "\t", 3, false},
	{ "[\\t-Caby]", "see\t", NULL, 0, true},
	{ "[^t]", "ttt", NULL, 0, false},
	{ "[^tc]", "tcy", "y", 2, false},
	{ "[AB]*", "ABABAC", "ABABA", 0, false },
	{ "[AB]*$", "ABABAC", NULL, 0, false },
	{ "[AB]+", "ABABAC", "ABABA", 0, false },
	{ "B+[AB]*$", "ABABA", "BABA", 1, false },
	{ "^B*[AB]+$", "ABABA", "ABABA", 0, false },
	{ "^A.*B$", "Asomething is hereB", "Asomething is hereB", 0, false },
	{ "^A.*B$", "Asomething\n is hereB", NULL, 0, false },
	{ "(AB)*", "ABABA", "ABAB", 0, false },
	{ "(^AB)*", "ABABA", "AB", 0, false },
	{ "^(AB)*", "ABABA", "ABAB", 0, false },
	{ "^(AB)*", "ABABA", "ABAB", 0, false },
	{ "this|that", "not that", "that", 4, false },
	{ "^this|that", "not this", NULL, 0, false },
	{ "this|that|other", "other than that", "that", 11, false },
	{ "((this|that)[ ]*)+", "not this that this", "this that this", 
		4, false },
	{ NULL, NULL, NULL, 0, false }
};


class Regexp1 : public Application 
{
protected:
	virtual void main()
	{
		const RegexpTestElement *elem = tests;
		RegexpMatch match;

		while(elem->pattern)
		{
			if(!test(elem))
				Thread::exit();
			elem++;
		}

		// In addition, we grab a couple tests of the grouping system,
		// to make sure it is working.
		
		RegexpPattern *pattern = new RegexpPattern("(h[A-Za-z])*");
		try
		{
			if(!pattern->match("hiho", match))
			{
				lfcOut << "Failed!: /(h[A-Za-z])*/ did not "
					"match 'hiho'" << ENDL;
			}
			else if(match.getSavedSubmatchCount() != 2)
			{
				lfcOut << "Failed!: /(h[A-Za-z])*/ did not "
					"save the correct number of " <<
					"submatches." << ENDL;
			}
			else if(match.getSavedSubmatch(0)->match != "hi")
			{
				lfcOut << "Failed!: /(h[A-Za-z])*/ did not "
					"have the correct first submatch " <<
					"'hi', instead had " <<
					match.getSavedSubmatch(0)->match <<
					ENDL;
			}
			else if(match.getSavedSubmatch(1)->match != "ho")
			{
				lfcOut << "Failed!: /(h[A-Za-z])*/ did not "
					"have the correct second submatch " <<
					"'ho', instead had " <<
					match.getSavedSubmatch(0)->match <<
					ENDL;
			}
			else
			{
				lfcOut << "Passed: /(h[A-Za-z])*/ matched " <<
					"'hiho' with the correct submatches." <<
					ENDL;
			}
		} catch(RegexpException &e)
		{
			lfcOut << "Failed!: /(h[A-Za-z])*/ threw an " <<
				"exception: " << e.message() << ENDL;
		}
		lfcOut << "PASSED ALL TESTS!" << ENDL;
	}

	virtual bool test(const RegexpTestElement *elem)
	{
		RegexpPattern *pattern;
		RegexpMatch match;
		bool result;
		try
		{
			pattern = new RegexpPattern(elem->pattern);
			if(pattern->match(elem->input, match))
			{
				if(elem->match == NULL)
				{
					lfcOut << "Failed!: /" << 
						elem->pattern << "/ matched" <<
						" '" << elem->input << "'" << 
						" with '" << match.match << 
						"'." << ENDL;
					result = false;
				}
				else if(elem->match != match.match)
				{
					lfcOut << "Failed!: /" << 
						elem->pattern << "/ matched" <<
						" '" << elem->input << "'" << 
						" with '" << match.match << 
						"' instead of '" <<
						elem->match << "'." << ENDL;
					result = false;
				}
				else if(elem->offset != match.offset)
				{
					lfcOut << "Failed!: /" << 
						elem->pattern << "/ matched" <<
						" '" << elem->input << "'" << 
						" with offset " << 
						match.offset << 
						" instead of " <<
						elem->offset << "." << ENDL;
					result = false;
				}
				else
				{
					lfcOut << "Passed: /" <<
						elem->pattern << "/ matched" <<
						" '" << elem->input << "'" <<
						" with substring '" <<
						match.match << "' and " <<
						"offset " << match.offset << 
						"." << ENDL;
					result = true;
				}
			}
			else
			{
				if(elem->match != NULL)
				{
					lfcOut << "Failed!: /" << 
						elem->pattern << "/ should " <<
						"have matched '" << 
						elem->input << "' at offset" << 
						" " << elem->offset << "." <<
						ENDL;
					result = false;
				}
				else
				{
					lfcOut << "Passed: /" << 
						elem->pattern << "/ did not" <<
						" match '" << elem->input <<
						"' correctly." << ENDL;
					result = true;
				}
			}
			delete pattern;
		}
		catch(RegexpException &e)
		{
			if(elem->exception)
			{
				lfcOut << "Passed: /" << elem->pattern << 
					"/ threw an exception: " <<
					e.message() << "." << ENDL;
				result = true;
			}
			else
			{
				lfcOut << "Failed!: /" << elem->pattern <<
					"/ threw an exception: " << 
					e.message() << "." << ENDL;
				result = false;
			}
		}
		catch(Exception &e)
		{
			lfcOut << "Failed!: General Exception thrown: " << 
				ENDL << e << ENDL;
			result = false;
		}
		return result;
	}
} app;
