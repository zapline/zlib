
// simple LFC trace infrastructure test
//

#include <lfc>

using namespace lfc;

/////////////////////////////////////////////////////////////////////
//
// some class methods
//

class TestTrace : public Object
{
    // non-static methods
public:
    void nonStaticMethod(int, float)
    {
        TRACE(TestTrace::nonStaticMethod(int, float));

        // dump call stack
        //
        Log(lfcLogger) << Thread::self()->callStack();
    }

    // static member functions
public:
    static void staticMethod()
    {
        TRACE(TestTrace::staticMethod());

        TestTrace obj;
        obj.nonStaticMethod(1, 2.0);
    }
};

/////////////////////////////////////////////////////////////////////
//
// some global functions
//

void g()
{
    TRACE(g());
    TestTrace::staticMethod();
}

void f(int)
{
    TRACE(f(int));
    g();
}

void f()
{
    TRACE(f());
    f(1);
}


/////////////////////////////////////////////////////////////////////
//
// main app class
//

class Tracing1 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Tracing1::main);
	    f();
	}
} app;

