
// test Ptr<T> and callbacks

#include <lfc.smartPtr>
#include <lfc.debug>
#include <lfc.threads.application>
#include <lfc.threads.mutex>
#include <lfc.threads.guards>
#include <lfc.globals>
#include <lfc.callbacks.callbacks>
using namespace lfc;


void f() { TRACE(f()); lfcOut << "f\n"; }

struct X
{
	void g() { TRACE(X::g()); lfcOut << "X::g\n"; }
	void h(int i) { TRACE(X::h(int)); lfcOut << "X::h(" << i << ")\n"; }
};


// main app -------------------------------

class Test : public Application
{
protected:
	virtual void main()
	{
        TRACE(Test::main());

		lfcOut << "testPtr3\n\n";

		X *p1 = new X;
		Ptr<X> sp1(new X);

		Callback0<void> cb1 = callback(&f);
		Callback0<void> cb2 = callback(p1, &X::g);

		// ok, but dangerous (object pointer by sp1 may be auto-deleted anytime)
		Callback0<void> cb3 = callback(sp1.realPointer(), &X::g);

		// the 'right' way
		Callback0<void> cb4 = callback(sp1, &X::g);

		// using aux value
		Callback0<void> cb5 = callback(sp1, &X::h, 123);

		cb1();
		cb2();
		cb3();
		cb4();
		cb5();
	}
} app;


