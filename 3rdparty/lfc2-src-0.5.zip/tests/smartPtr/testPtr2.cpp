
#include <lfc.smartPtr>
#include <lfc.debug>
#include <lfc.threads.application>
#include <lfc.threads.mutex>
#include <lfc.threads.guards>
#include <lfc.globals>
#include <lfc.callbacks.callbacks>
using namespace lfc;


struct X
{
	X() { TRACE(X::X()); ++creationBalance; lfcOut << "+"; lfcOut.flush(); }
	~X() { TRACE(X::~X()); --creationBalance; lfcOut << "-"; lfcOut.flush(); }
	static long creationBalance;
};

long X::creationBalance = 0;


struct B1 { virtual ~B1() {} };
struct B2 { virtual ~B2() {} };
struct D1 : public virtual B1 {};
struct D2 : public B2 {};
struct D3 : public B1, public B2 {};
struct D4 : public virtual B1, public D1 {};
struct D5 : public virtual B1, private D1 {};


void miscTests()
{
    TRACE(miscTests());

	Ptr<int> p1(new int(0));
	p1 = new int(1);
	Ptr<int> p2 = p1;

	lfcOut << *p1 << ENDL;
	lfcOut << *p2 << ENDL;

	*p2 = 128;

	lfcOut << *p1 << ENDL;
	lfcOut << *p2 << ENDL;

	lfcOut << (p1 == p2) << ENDL;
	p1 = lfcNull;
	lfcOut << (p1 == p2) << ENDL;
	lfcOut << (p1 == lfcNull) << ENDL;

	Ptr<const int> p3;
	p3 = p2;
	lfcOut << *p3 << ENDL;
}


void dynamicCastTest()
{
    TRACE(dynamicCastTest());

	Ptr<D4> pd4(new D4);
	Ptr<D1> pd1 = pd4;
	//Ptr<D4> pd4p = pd1;					// fail (implicit upcast)
	Ptr<D4> pd4p = pd1.dynamicCast<D4>();	// ok
	assert(!pd4p.isNull());

	Ptr<D1> pd1p(new D1);
	Ptr<D4> pd4p2 = pd1p.dynamicCast<D4>();	// fail (not really D4)
	assert(pd4p2.isNull());
}


void realPointerTest()
{
    TRACE(realPointerTest());

	Ptr<D4> pd4(new D4);
	D4 *rp = pd4.realPointer();

	// avoid unused values warnings...
	rp;
}


void gcTest()
{
    TRACE(gcTest());

	lfcOut << "\n======== garbage colector test ========\n";

	{
		Ptr<X> sp1(new X);
		Ptr<const X> sp2;

		sp2 = sp1;
		sp1 = new X;
		sp2 = sp1;

		Ptr<X> sp3 = sp1;
		sp2 = lfcNull;
		sp3 = sp3;
		sp1 = lfcNull;
		sp3 = new X;

		const long N = 10000;

		Ptr<X> spt[N];
		for(long i = 0; i < N; ++i)
		{
			Ptr<X> lsp = sp3;
			spt[i] = sp3;
			spt[i] = sp1;
			sp3 = spt[i];
			spt[i] = sp1;
			sp3 = lsp;
		}
	}

	lfcOut << "\nCreation balance: " << X::creationBalance << " (should be 0)\n";
}


// main app -------------------------------

class Test : public Application
{
protected:
	virtual void main()
	{
        TRACE(Test::main());

		miscTests();
		dynamicCastTest();
		realPointerTest();
		gcTest();
	}
} app;


