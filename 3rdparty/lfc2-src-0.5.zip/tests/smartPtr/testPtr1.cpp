
#include <lfc.smartPtr>
#include <lfc.debug>
#include <lfc.threads.application>
#include <lfc.threads.mutex>
#include <lfc.threads.guards>
#include <lfc.globals>
#include <lfc.callbacks.callbacks>
using namespace lfc;


struct Base { void f() {} };
struct Deriv : public Base { int x; };


void miscSamples()
{
    TRACE(miscSamples());

	// smart pointer declarations
	Ptr<Base> sp1;				// null initialized
	Ptr<Deriv> sp2(new Deriv);	// point to new Base object
	Ptr<Base> sp3(sp2);			// init form another smart ptr (note Deriv -> Base conversion)
	//Ptr<Base> sp4 = new Base;	// fail: Ptr<T>(T*) is _explicit_
	Ptr<Deriv> sp4 = lfcNull;	// init to NULL (useful for func args)
	Ptr<const Base> sp5 = sp3;	// Ptr to const object (note non-const -> const conversion)
	Ptr<double> sp6;			// Ptr to a buid-in type

	// basic usage
	sp2->f();
	sp2->x = 10;
	Deriv obj = *sp2;
	//sp1->f();					// will throw an exception (null dereferencing)
	//*sp1;						// idem

	// copying and conversions
	// (similar to buil-in pointers, if T1* -> T2* then Ptr<T1> -> Ptr<T2>)
	sp1 = sp2;					// ok, Ptr<Deriv> -> Ptr<Base>
	//sp2 = sp3;				// fail, Ptr<Base> -> Ptr<Deriv> is illegal
	sp2 = sp2.dynamicCast<Deriv>();	// ok, dynamic cast (may return a null ptr)

	// comparations (2 smart ptr are equal if they point to the same object)
	sp1 == sp2;					// false
	sp1 == sp3;					// true
	sp1 == lfcNull;				// true
	lfcNull == sp1;				// true
	sp1.isNull();				// true

	// special usage
	Base *p = sp2.realPointer();	// use with caution!

	// avoid unused values warnings...
	p;
	obj;

	// now, all unreferenced objects
	// will be automaticaly deleted
}


// main app -------------------------------

class Test : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Test::main());

		miscSamples();
	}
} app;


