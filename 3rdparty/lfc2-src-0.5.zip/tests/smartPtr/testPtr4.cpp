
// test Ptr<T> thread safety

#include <lfc.debug>
#include <lfc.smartPtr>
#include <lfc.threads>
#include <lfc.globals>

using namespace lfc;


// test class -------------------------------

struct X
{
	X() { ++creationBalance; }
	~X() { --creationBalance; }
	static long creationBalance;
};

long X::creationBalance = 0;


// thread class -------------------------------

class TestThread : public lfc::Thread
{
protected:
	virtual void main()
	{
        TRACE(TestThread::main());

		Ptr<X> p1(new X);
		Ptr<X> p2;
		Ptr<X> p3 = p1;

		s_sp1 = new X;
		s_sp2 = new X;
		s_sp3 = new X;

		for(long i = 0; i < 5000; ++i)
		{
			p2 = new X;

			s_sp1 = new X;
			s_sp2 = new X;
			s_sp3 = new X;

			Ptr<X> lp1 = p1;

			p1 = p3;
			s_sp1 = lp1;
			s_sp2 = p3;
			p2 = p3;
			s_sp3 = p2;
			p2 = lfcNull;
			p1 = lp1;
		}

		s_sp1 = lfcNull;
		s_sp2 = lfcNull;
		s_sp3 = lfcNull;
	}

protected:
	static lfc::Ptr<X> s_sp1;
	static lfc::Ptr<X> s_sp2;
	static lfc::Ptr<X> s_sp3;
};

lfc::Ptr<X> TestThread::s_sp1;
lfc::Ptr<X> TestThread::s_sp2;
lfc::Ptr<X> TestThread::s_sp3;


// main app -------------------------------

class Test : public lfc::Application
{
protected:
	virtual void main()
	{
        TRACE(Test::main());

		const int THREADS_COUNT = 32;
		TestThread t[THREADS_COUNT];

		Log(lfcLogger) << "starting threads...\n";

		for(int i = 0; i < THREADS_COUNT; ++i)
			t[i].start();

		Log(lfcLogger) << "all threads started... (please wait)\n";

		for(int i = 0; i < THREADS_COUNT; ++i)
			t[i].join();

		Log(lfcLogger) << "\nCreation balance: " <<
			X::creationBalance << " (should be 0)\n";
	}
} app;


