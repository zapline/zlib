
// try to demonstrate a _very_ simple serial terminal
// (multiple threads version)

//$ tmp
#include <iostream>


#include <lfc.threads>
#include <lfc.globals>
#include <lfc.streams.serial>
using namespace lfc;


//////////////////////////////////////////////////////////////

class MiniTerminal : public Object
{
public:
	MiniTerminal() {}
	~MiniTerminal() throw() { close(); }

public:
	void open(string portName, string portSettings,
		const char *modemInit = "ATZ\r")
	{
	    TRACE(MiniTerminal::open(string portName, string portSettings, const char *modemInit));

		lfcOut << "opening... " << portName;
		lfcOut << " [" << portSettings << "]\n";

		m_modem.open(portName);
		m_modem.setup(portSettings);
		m_modem.setHardwareFlowControl(true);
		m_modem.setSoftwareFlowControl(false);
		m_modem.setBlockingRead(false);
		m_modem.setDTR(true);
		m_modem.setRTS(true);

		lfcOut << "initializing modem...\n";
		initModem(modemInit);
	}

	void close(const char *modemReset = "ATZ\r")
	{
	    TRACE(MiniTerminal::close(const char *modemReset));

		if(m_modem.state() == SerialPort::stOpen)
		{
    		resetModem(modemReset);
		    m_modem.close();
		}
	}

	void sendStr(string s)
	{
	    TRACE(MiniTerminal::sendStr(string s));

		m_modem.write(s.c_str(), s.size());
	}

	string readStr()
	{
	    TRACE(MiniTerminal::readStr());

		const int BUFF_SIZE = 1024;
		char buff[BUFF_SIZE];

		long readCount = m_modem.read(buff, BUFF_SIZE - 1, false);
		buff[readCount] = 0;
		return string(buff);
	}

	void initModem(const char *modemInit)
	{
	    TRACE(MiniTerminal::initModem(const char *modemInit));

		Thread::sleep(100);
		sendStr(modemInit);
		Thread::sleep(100);
	}

	void resetModem(const char *modemReset)
	{
	    TRACE(MiniTerminal::resetModem(const char *modemReset));

		lfcOut << "\nreseting modem...\n";

		sendStr("+++");
		Thread::sleep(500);
		sendStr(modemReset);
		Thread::sleep(500);
	}

	void start()
	{
	    TRACE(MiniTerminal::start());

		m_poolModemThread.setName("poolModemThread");
		m_poolModemThread.setCallback(
			callback(this, &MiniTerminal::poolModem), 10);
		m_poolModemThread.start();

		for(;;)
		{
			string cmd;
			std::cin >> cmd;	//$ replace with lfcIn (when available)

			if(cmd[0] == '/')
			{
				if(cmd == "/exit")
					break;
				else
					lfcOut << "unknown command.\n";
			}
			else
				sendStr(cmd + "\r");
		}

		m_poolModemThread.cancel();
		m_poolModemThread.join();
	}

protected:
	void poolModem()
	{
	    TRACE(MiniTerminal::poolModem());

		string s = readStr();
		if(s.size() != 0)
			lfcOut << s;
	}

protected:
	TimerThread m_poolModemThread;
	SerialPort m_modem;
};


//////////////////////////////////////////////////////////////

class Test : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Test::main());

		if(m_arguments.size() != 3)
		{
			lfcOut << "use: miniTerminal <portName> <portSettings>\n";
			lfcOut << "<portSettings> = <baud>,<B><P><S>   (ex. 19200,8n1)\n";
			return;
		}

		MiniTerminal t;
		t.open(m_arguments[1], m_arguments[2], "ATE0\r");
		t.start();
	}
} app;


