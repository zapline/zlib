
#include <lfc.debug>
#include <lfc.time.chronometer>
#include <lfc.threads.application>
#include <lfc.streams.file>
#include <lfc.globals>

using namespace lfc;


class ChronometerTest : public Application
{
protected:
	virtual void main()
	{
	    TRACE(ChronometerTest::main());

		Chronometer c;
		File f("chronometerResults.txt", File::flWrite);
		lfcOut.connectOutputBase(f);

		for(int i = 6000; (i *= 10) <= 600000000; )
		{
			long temp = i;

			lfcOut << "Time taken to make " << i
			       << " empty loops: ";

			c.start();
			while(--temp)
			{
			}
			c.stop();

			lfcOut << formattedOut(c, "-s 'secs', -ms 'msecs'")
			       << ENDL;
		}

		lfcOut.disconnectOutputBase(f);
	}
} app;

