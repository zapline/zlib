
#include <lfc.debug>
#include <lfc.time.time>
#include <lfc.threads.application>
#include <lfc.globals>
using namespace lfc;


class TimeTest : public lfc::Application
{
protected:
	virtual void main()
	{
	    TRACE(TimeTest::main());

		Time t(2016, Time::December, 25);

		lfcOut << "\nIn 2016, Christmas will be on a " <<
			t.dayName(t.dayOfTheWeek()) << ".\n" <<
			"Unfortunately, 'till then we'll have to wait for:\n" <<
			formattedOut(t - Time(),
				"-d 'days', -h 'hours', -m 'minutes and' -s 'seconds\n'") <<
			"That's a pretty long time, isn't it? :-)\n" <<
			"Or maybe isn't. Depends on when you are running this old demo. ;-)\n" << ENDL;
	}
} app;


