
#include <lfc.debug>
#include <lfc.time.chronometer>
#include <lfc.threads.application>
#include <lfc.globals>


class ChronometerTest : public lfc::Application
{
protected:
	virtual void main()
	{
	    TRACE(ChronometerTest::main());

		lfc::Chronometer c;

		// 1
		c.start();
		lfc::Thread::sleep(10);
		c.stop();
		lfc::lfcOut << c << lfc::ENDL;

		// 2
		c.start();
		lfc::Thread::sleep(250);
		c.stop();
		lfc::lfcOut << c << lfc::ENDL;

		// 3
		c.start();
		lfc::Thread::sleep(1500);
		c.stop();
		lfc::lfcOut << c << lfc::ENDL;
	}
} app;


