
// test callback functions and CallbackN<...> initialization

#include <lfc.debug>
#include <lfc.threads.application>
#include <lfc.callbacks.callbacks>
#include <lfc.globals>
using namespace lfc;


void f(int v) { lfcOut << "f(" << v << ")\n"; }


struct X
{
	int f(int x) { lfcOut << "X::f(" << x << ")\n"; return 2 * x; }
	int cf(int x) const { lfcOut << "X::cf(" << x << ")\n"; return 2 * x; }

	static void s(double v) { lfcOut << "X::s(" << v << ")\n"; }

private:
	void priv() {}
};


class Test : public Application
{
protected:
	// null
	void test1()
	{
        TRACE(Test::test1());

		lfcOut << ENDL;

		Callback0<void> cb1;
		Callback2<int, float, char*> cb2;
		Callback1<void, int> cb3 = lfcNull;

		// null callback (must throw exception)
		cb1();
		cb2(1.0, "...");
		cb3(123);
	}

	// static/global functions
	void test2()
	{
        TRACE(Test::test2());

		lfcOut << ENDL;

		// func
		Callback1<void, int> cb1 = callback(&f);
		Callback0<void> cb2 = callback(&::f, 2);				// aux

		// static method
		Callback1<void, double> cb3 = callback(&X::s);
		Callback0<void> cb4 = callback(&::X::s, 4.5);			// aux

		cb1(1);
		cb2();
		cb3(3.5);
		cb4();
	}

	// T*, methods
	void test3()
	{
        TRACE(Test::test3());

		lfcOut << ENDL;

		X obj;
		const X constObj = X();

		// obj, method
		Callback1<int, int> cb1 = callback(&obj, &X::f);
		Callback0<int> cb2 = callback(&obj, &X::f, -2);		// aux

		// const obj, method (must fail at compile-time)
		//Callback1<int, int> cb3 = callback(&constObj, &X::f);
		//Callback0<int> cb4 = callback(&constObj, &X::f, -4);	// aux

		// const obj, const method (ok)
		Callback1<int, int> cb5 = callback(&constObj, &X::cf);
		Callback0<int> cb6 = callback(&constObj, &X::cf, -6);	// aux

		// obj, const method (ok)
		Callback1<int, int> cb7 = callback(&obj, &X::cf);
		Callback0<int> cb8 = callback(&obj, &X::cf, -8);		// aux

		cb1(1);
		cb2();
		//cb3(3);
		//cb4();
		cb5(5);
		cb6();
		cb7(7);
		cb8();
	}

	// Ptr<T>, methods
	void test4()
	{
        TRACE(Test::test4());

		lfcOut << ENDL;

		Ptr<X> sp1(new X);
		Ptr<const X> sp2(new X);

		// Ptr<obj>, method
		Callback1<int, int> cb1 = callback(sp1, &X::f);
		Callback0<int> cb2 = callback(sp1, &X::f, -2);		// aux

		// Ptr<const obj>, method (must fail at compile-time)
		//Callback1<int, int> cb3 = callback(sp2, &X::f);
		//Callback0<int> cb4 = callback(sp2, &X::f, -4);	// aux

		//# bcc5.5 fail to compile when _both_ cb5 and cb6
		// are declared (with a strange error... investigate this!)

		// Ptr<const obj>, const method (ok)
		Callback1<int, int> cb5 = callback(sp2, &X::cf);
		Callback0<int> cb6 = callback(sp2, &X::cf, -6);		// aux

		// Ptr<obj>, const method (ok)
		Callback1<int, int> cb7 = callback(sp1, &X::cf);
		Callback0<int> cb8 = callback(sp1, &X::cf, -8);		// aux

		cb1(1);
		cb2();
		//cb3(3);
		//cb4();
		cb5(5);
		cb6();
		cb7(7);
		cb8();
	}

	// T*, methods (test access rights)
	void test5()
	{
        TRACE(Test::test5());

		lfcOut << ENDL;

		//X obj;

		// must fail at compile-time (priv is private within this context)
		//Callback0<void> cb1 = callback(&obj, &X::priv);
	}

	virtual void main()
	{
        TRACE(Test::main());

		//test1();
		test2();
		test3();
		test4();
		//test5();
	}
} app;


