
#include <lfc.debug>
#include <lfc.threads.application>
#include <lfc.callbacks.callbacks>
#include <lfc.globals>


class TestNull : public lfc::Application
{
protected:
	virtual void main()
	{
        TRACE(TestNull::main());

		using namespace lfc;

		// oarecum echivalente
		Callback0<void> cb1;
		Callback0<void> cb2 = Callback0<void>();
		Callback0<void> cb3 = lfcNull;
		Callback0<void> cb4 = Callback0<void>(lfcNull);

		// gresit!
		// (ar trebui semnalizata cumva ca erroare)
		Callback0<void> cb5 = NULL;

		Callback0<void> cb6, cb7, cb8, cb9;

		cb6 = Callback0<void>();
		cb7 = Null();
		cb8.invalidate();

		// gresit!
		// (ar trebui semnalizata cumva ca erroare)
		cb9 = NULL;

		lfcOut << (cb2 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb3 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb4 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb5 == cb1 ? "ok" : "fail") << ENDL;	// fail
		lfcOut << (cb6 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb7 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb8 == cb1 ? "ok" : "fail") << ENDL;
		lfcOut << (cb9 == cb1 ? "ok" : "fail") << ENDL;	// fail
	}
} app;


