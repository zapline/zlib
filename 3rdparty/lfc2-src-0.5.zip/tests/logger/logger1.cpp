
// simple Logger demonstration
// (also test DebugOutput class)
//

#include <lfc>

using namespace lfc;


class Logger1 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Logger1::main());

        // simple logging, nothing special is necessary,
        // by default all output goes to lfcDebugOutput
        //
        Log(lfcLogger) << "before connecting output to a file." << ENDL;

		// create a file and connect it to the logger
		//
		File f("logfile1.txt",
		    File::flWrite | File::flTruncate | File::flWriteThrough);
		lfcLogger.connectOutputBase(f);

        // log to file and debug output
        //
        Log(lfcLogger) << "logging to both DebugOutput and a file." << ENDL;

        // different style of logging multiple values
        //
        {
            Log log(lfcLogger);
            log << "Complex logging ";
            log << "can be splitted ";
            log << "accross separate statements ";
            log << "using a block scope ";
            log << ENDL;
        }

        // display the list of active threads
        //
        {
            Log log(lfcLogger);

            log << "----- active threads list begin -----\n";

            list<Thread *> threadsList = Thread::threadsSnapshot();
            list<Thread *>::const_iterator it;

            for(it = threadsList.begin(); it != threadsList.end(); ++it)
                log << (*it)->name() << ENDL;

            log << "----- active threads list end -----\n";
        }

        // disconnect the debug output
        //
        lfcLogger.disconnectOutputBase(lfcDebugOutput);

        // log only to the file
        //
        Log(lfcLogger) << "logging only to the file." << ENDL;

        // this is necessary, otherwise the file will be destructed
        // and the logger will still reference it as output base
        //
        lfcLogger.disconnectOutputBase(f);
	}
} app;


