
// the same as logger1.cpp, just with
// logging disabled with LFC_DISABLE_LOGGING
//

#define LFC_DISABLE_LOGGING

#include <lfc>

using namespace lfc;


class Logger2 : public Application
{
protected:
	virtual void main()
	{
	    TRACE(Logger2::main());

        // simple logging, nothing special is necessary,
        // by default all output goes to lfcDebugOutput
        //
        Log(lfcLogger) << "before connecting output to a file." << ENDL;

		// create a file and connect it to the logger
		//
		File f("logfile2.txt",
		    File::flWrite | File::flTruncate | File::flWriteThrough);
		lfcLogger.connectOutputBase(f);

        // log to file and debug output
        //
        Log(lfcLogger) << "logging to both DebugOutput and a file." << ENDL;

        // different style of logging multiple values
        //
        {
            Log log(lfcLogger);
            log << "Complex logging ";
            log << "can be splitted ";
            log << "accross separate statements ";
            log << "using a block scope ";
            log << ENDL;
        }

        // disconnect the debug output
        //
        lfcLogger.disconnectOutputBase(lfcDebugOutput);

        // log only to the file
        //
        Log(lfcLogger) << "logging only to the file." << ENDL;

        // this is necessary, otherwise the file will be destructed
        // and the logger will still reference it as output base
        //
        lfcLogger.disconnectOutputBase(f);
	}
} app;


