
#include <string>
#include <algorithm>
using namespace std;

#include <lfc.globals>
#include <lfc.threads>
#include <lfc.streams>
using namespace lfc;


const string __root = "./htmlDocs";
//const string __root = "/usr/local/httpd/htdocs";
const string __defaultFile = "index.html";

/*const*/ string __header =
	"HTTP/1.0 200 OK\n"
	"Allow: GET\n"
	"MIME-Version: 1.0\n"
	"Server: Lemo's microWebServer\n"
	"Content-Type: text/html\n";



class HTTPGenie : public Thread
{
public:
	HTTPGenie(SocketServer &socketServer)
	{
		TRACE(HTTPGenie::HTTPGenie(SocketServer &));
		m_socket.accept(socketServer);
	}

protected:
	virtual void main()
	{
		TRACE(HTTPGenie::main());
		lfcOut << "------\n";

		string line = getLine();
		while(getLine().size());

		//lfcOut << line << ENDL;

		if(line.substr(0, 4) != string("GET "))
		{
			lfcOut << "Method not implemented.\n";
			TextOutput(m_socket) << "Method not implemented (";
			TextOutput(m_socket) << line << ")\n";
		}
		else
		{
			string fileName = __root + getFileName(line.substr(4));

			if(isDirectory(fileName) && *fileName.rbegin() != '/')
				fileName += '/';

			if(*fileName.rbegin() == '/')
				fileName += __defaultFile;

			lfcOut << "serving file(" << fileName << ") ... ";

			try
			{
				File f(fileName, File::flRead | File::flOpenExisting);
				lfcOut << f.size() << " bytes ";

				MemoryIO header;
				TextOutput to(header);
				to << __header;
				to << "Content-Length: " << f.size() << "\n\n";
				header.resetInput();
				header.copyTo(m_socket);
				f.copyTo(m_socket);
				lfcOut << "ok.\n";
			}
			catch(int)
			{
				lfcOut << "fail.\n";

				try
				{
					TextOutput(m_socket) << "File not found! (";
					TextOutput(m_socket) << fileName << ")\n";
				}
				catch(int)
				{
					lfcOut << "connection dropped!\n";
				}
			}
		}
	}

	virtual bool isDirectory(string fileName)
	{
		TRACE(HTTPGenie::isDirectory(string));
		return false;
		/*!
		struct stat buf;
		if(::stat(fileName.pszData(), &buf) != 0)
			return false;
		return S_ISDIR(buf.st_mode);
		*/
	}

	virtual string getFileName(string line)
	{
		TRACE(HTTPGenie::getFileName(string));
		return string(line.begin(), find(line.begin(), line.end(), ' '));
	}

	virtual string getLine()
	{
		TRACE(HTTPGenie::getLine());
		string line;
		char c;

		while((c = m_socket.pop()) != '\r')
			line += c;
		c = m_socket.pop();
		ASSERT(c == '\n');
		return line;
	}

protected:
	Socket m_socket;
};


class MicroWebServer : public Application
{
protected:
	virtual void main()
	{
		TRACE(MicroWebServer::main());
		if(m_arguments.size() != 2)
		{
			lfcOut << "use: mws <port>\n";
			exit(1);
		}

		m_port = ::atoi(m_arguments[1].c_str());
		//lfcOut.disconnect();

		listen();

		lfcOut << "???\n";
	}

	virtual void listen()
	{
		TRACE(MicroWebServer::listen());
		lfcOut << "listen for connections on port " << m_port << ENDL;

		SocketServer serv(m_port);

		for(;;)
		{
			HTTPGenie *pGenie = new HTTPGenie(serv);
			pGenie->setAutoDelete(true);
			pGenie->start();
		}
	}

protected:
	long m_port;
} app;


