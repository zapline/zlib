
#include <lfc.exceptions>
#include <lfc.threads.thread>
#include <lfc.streams.textStream>


namespace lfc
{

Exception::Exception(string msg) throw() :
    m_message(msg)
{
    m_callStack = Thread::self()->callStack();
}


void Exception::formatObject(TextOutput &ts, string format) const throw()
{
	if(format == "m")
	{
        ts <<
            ENDL <<
            "=================== Exception information ====================\n" <<
            ENDL <<
            "name     : " << name() << ENDL <<
            "message  : " << message() << ENDL <<
            ENDL <<
            callStack() << ENDL;
	}
	else
		ts << name() << "[" << message() << "]";
}

}	// namespace lfc


