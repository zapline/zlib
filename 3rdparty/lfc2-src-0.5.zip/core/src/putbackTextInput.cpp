
#include <lfc.globals>
#include <lfc.streams>
#include <lfc.streams.putbackTextInput>


namespace lfc
{


long PutbackTextInput::read(char *buffer, long count, bool bWaitAll)
{
    TRACE(PutbackTextInput::read(char *buffer, long count, bool bWaitAll));

	char *src, *dst;
	src = m_buffer + m_bufferPosition;
	dst = buffer;

	if(m_pInputBase == NULL)
		throw IOException("No input base");

	for(long i = 0; i < count; ++i)
	{
		if(!*src)
		{
			// Either at EOF or end of buffer
			if(m_bufferPosition == m_marker1 ||
					m_bufferPosition == m_marker2)
			{
				// Either we need to make sure to read the
				// next buffer because we are waiting, or we
				// don't have anything written, so we can't
				// return yet.
				if(!bWaitAll && i != 0)
					return i;
				readNewBuffer(bWaitAll);
				src = m_buffer + m_bufferPosition;
				if(!*src)
					return i;
			}
			else if(m_pInputBase->hasMore())
			{
				// This can happen if at some point bWaitAll
				// was false and read() was called.  We just
				// try to fill in the rest of the half-buffer
				// and move on.
				long read;
				long fillCnt; // how much left in half-buffer

				if(m_bufferPosition < m_marker1)
					fillCnt = m_marker1 - m_bufferPosition;
				else
					fillCnt = m_marker2 - m_bufferPosition;

				read = m_pInputBase->read(m_buffer +
					m_bufferPosition, fillCnt, false);

				// place a marker at the end of valid data.
				m_buffer[m_bufferPosition + read] = '\0';
			}
			else
				return i; // reached EOF
		}

		// Copy to the buffer, increment the position and decrement
		// the putback count if necessary.
		*dst++ = *src++;
		m_bufferPosition++;
		if(m_putbackCnt > 0)
			m_putbackCnt--;
	}

	return count;
}


void PutbackTextInput::readNewBuffer(bool bWaitAll)
{
    TRACE(PutbackTextInput::readNewBuffer(bool bWaitAll));

	long read;

	// This should only be called when the position is on one of the
	// markers.
	ASSERT(m_marker1 == m_bufferPosition || m_marker2 == m_bufferPosition);

	// If putbackCnt > 0, that means that we have, at a prior point, read
	// in the other half-buffer, so we should just return after adjusting
	// the buffer position

	if(m_bufferPosition == m_marker1) // End of the 1st half-buffer
	{
		++m_bufferPosition; // shift past the marker
		if(m_putbackCnt > 0) // see above
			return;

		// Put an EOF in the proper position and return
		if(!m_pInputBase->hasMore())
		{
			m_buffer[m_bufferPosition] = '\0';
			return;
		}

		// place a marker at the end of valid data -- this is either
		// EOF or just as far as we read.
		read = m_pInputBase->read(m_buffer + m_bufferPosition,
					m_maxPutbackCnt, bWaitAll);
		m_buffer[m_bufferPosition + read] = '\0';
	}
	else if(m_bufferPosition == m_marker2) // End of 2nd half-buffer
	{
		m_bufferPosition = 0; // back to the beginning.
		m_readTwice = true;  // reading 2nd buffer, so we've read twice
		if(m_putbackCnt > 0) // see above
			return;

		// Put an EOF in the proper position and return
		if(!m_pInputBase->hasMore())
		{
			m_buffer[m_bufferPosition] = '\0';
			return;
		}

		// place a marker at the end of valid data -- this is either
		// EOF or just as far as we read.
		read = m_pInputBase->read(m_buffer, m_maxPutbackCnt, bWaitAll);
		m_buffer[read] = '\0';
	}
}


void PutbackTextInput::putback(long count)
{
    TRACE(PutbackTextInput::putback(long count));

	if(m_pInputBase == NULL)
		throw IOException("No input base");

	if(count == 0)
		return;

	if(count < 0)
		throw PutbackTextException("Negative putback count");

	if(count + m_putbackCnt > m_maxPutbackCnt)
		throw PutbackTextException("Exceeded maximum putback count");

	if(m_bufferPosition <= m_marker1)
	{
		if(!m_readTwice && count > m_bufferPosition)
			throw PutbackTextException("Putback more than read");

		m_bufferPosition -= count;
		m_putbackCnt += count;
		if(m_bufferPosition < 0)
		{
			// we've shifted back before the first element of the
			// buffer, meaning we are actually in the old
			// half-buffer (which is in the second half of buffer
			// space).  The proper amount to shift by is the
			// negative buffer position
			m_bufferPosition = m_marker2 + m_bufferPosition;
		}
	}
	else // in the second half-buffer
	{
		m_bufferPosition -= count;
		m_putbackCnt += count;
		if(m_bufferPosition <= m_marker1)
			// again, we've shifted too far back, so we take care
			// of it by accounting for the single element marker.
			m_bufferPosition--;
	}
}


} // namespace lfc


