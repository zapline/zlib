
#include <lfc.time.chronometer>

namespace lfc
{

void Chronometer::writeObject(BinaryOutput &stream) const
{
    TRACE(Chronometer::writeObject(BinaryOutput &stream) const);

	stream << m_start;
	stream << m_finish;
}


void Chronometer::readObject(BinaryInput &stream)
{
    TRACE(Chronometer::readObject(BinaryInput &stream));

	stream >> m_start;
	stream >> m_finish;
}


void Chronometer::formatObject(TextOutput &stream, string format) const
{
    TRACE(Chronometer::readObject(BinaryInput &stream));

	stream << formattedOut(duration(), format);
}


}	// namespace lfc


