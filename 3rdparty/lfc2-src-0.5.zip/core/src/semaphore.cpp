
#include <lfc.debug>
#include <lfc.threads.semaphore>

namespace lfc
{

Semaphore::Semaphore(long count) :
	m_handle(pal::threads::NULL_SEM_HANDLE)
{
    //TRACE(Semaphore::Semaphore(long));

	int retCode = pal::threads::createSemaphore(m_handle, count);
	if(retCode)
		throw SemaphoreException(pal::threads::message(retCode));
}


Semaphore::~Semaphore() throw()
{
	if(pal::threads::closeSemaphore(m_handle))
		/*?*/;
}


void Semaphore::wait()
{
    //TRACE(Semaphore::wait());

	int retCode = pal::threads::waitSemaphore(m_handle);
	if(retCode)
		throw SemaphoreException(pal::threads::message(retCode));
}

bool Semaphore::tryWait()
{
    //TRACE(Semaphore::tryWait());

	bool bLocked;
	int retCode = pal::threads::tryWaitSemaphore(m_handle, bLocked);
	if(retCode)
		throw SemaphoreException(pal::threads::message(retCode));
	return bLocked;
}

void Semaphore::post()
{
    //TRACE(Semaphore::post());

	int retCode = pal::threads::postSemaphore(m_handle);
	if(retCode)
		throw SemaphoreException(pal::threads::message(retCode));
}


}	// namespace lfc


