
#include <stdio.h>
#include <stdarg.h>
#include <lfc.streams.textStream>

namespace lfc
{

TextOutput::TextOutput() throw()
{
	// default parameters
	//
	m_align = left;
	m_precision = 2;
	m_fillChar = ' ';
	m_integerBase = 'd';

	// set width = 0
	//
	m_width = 0;
	m_buffer = NULL;
}


TextOutput::TextOutput(_Output<char> &outputBase)
{
    TRACE(TextOutput::TextOutput(_Output<char> &outputBase));

	m_align = left;
	m_width = 0;
	m_precision = 2;
	m_fillChar = ' ';
	m_integerBase = 'd';
	m_buffer = NULL;
	setWidth(0);

	connectOutputBase(outputBase);
}


TextOutput::~TextOutput() throw()
{
	delete[] m_buffer;
}


TextOutput &TextOutput::operator<<(bool value)
{
    TRACE(TextOutput::operator<<(bool value));

	char buff[128];

	::sprintf(buff, value ? "true" : "false");
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(Byte value)
{
    TRACE(TextOutput::operator<<(Byte value));

	char buff[128];

	::sprintf(buff, "%2x", value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(char value)
{
    TRACE(TextOutput::operator<<(char value));

	push(value);
	return *this;
}


TextOutput &TextOutput::operator<<(short value)
{
    TRACE(TextOutput::operator<<(short value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%%c", m_integerBase);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(int value)
{
    TRACE(TextOutput::operator<<(int value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%%c", m_integerBase);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(long value)
{
    TRACE(TextOutput::operator<<(long value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%%c", m_integerBase);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(Word value)
{
    TRACE(TextOutput::operator<<(Word value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%%c", m_integerBase);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(DWord value)
{
    TRACE(TextOutput::operator<<(DWord value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%%c", m_integerBase);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(float value)
{
    TRACE(TextOutput::operator<<(float value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%.%ldf", m_precision);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(double value)
{
    TRACE(TextOutput::operator<<(double value));

	char format[128];
	char buff[128];

	::sprintf(format, "%%.%ldf", m_precision);
	::sprintf(buff, format, value);
	return operator<<(buff);
}


TextOutput &TextOutput::operator<<(const string &value)
{
    TRACE(TextOutput::operator<<(const string &value));

	return operator<<(value.c_str());
}


TextOutput &TextOutput::operator<<(const char *psz)
{
    TRACE(TextOutput::operator<<(const char *psz));

	if(psz == NULL)
		throw TextStreamException("NULL string argument");

	long pszWidth = ::strlen(psz);

	if(m_width > pszWidth)
	{
		::memset(m_buffer, m_fillChar, m_width);

		switch(m_align)
		{
		case left:
			::memmove(m_buffer, psz, pszWidth);
			break;

		case center:
			::memmove(m_buffer + (m_width - pszWidth) / 2, psz, pszWidth);
			break;

		case right:
			::memmove(m_buffer + (m_width - pszWidth), psz, pszWidth);
			break;

		default:
			ASSERT(false);
		}

		baseWrite(m_buffer, m_width);
	}
	else
		baseWrite(psz, pszWidth);

	return *this;
}


TextOutput &TextOutput::operator<<(const _Formatable &obj)
{
    TRACE(TextOutput::operator<<(const _Formatable &obj));

	obj.formatObject(*this);
	return *this;
}


TextOutput &TextOutput::operator<<(FormattedObject formattedObj)
{
    TRACE(TextOutput::operator<<(FormattedObject formattedObj));

	formattedObj.m_obj.formatObject(*this, formattedObj.m_format);
	return *this;
}


void TextOutput::setAlign(Align align)
{
    TRACE(TextOutput::setAlign(Align align));

	m_align = align;
}


void TextOutput::setWidth(long width)
{
    TRACE(TextOutput::setWidth(long width));

	if(width < 0)
		throw TextStreamException("illegal width");
	delete[] m_buffer;
	m_buffer = new char[width];
	m_width = width;
}


void TextOutput::setPrecision(long precision)
{
    TRACE(TextOutput::setPrecision(long precision));

	m_precision = precision;
}


void TextOutput::setFillChar(char fillChar)
{
    TRACE(TextOutput::setFillChar(char fillChar));

	m_fillChar = fillChar;
}


void TextOutput::setIntegerBase(char integerBase)
{
    TRACE(TextOutput::setIntegerBase(char integerBase));

	if(::strchr("diouxX", integerBase) == NULL)
		throw TextStreamException("illegal integer base");
	m_integerBase = integerBase;
}


/*!
\bug buffer overflow
*/
void TextOutput::printf(const char *format, ...)
{
    TRACE(TextOutput::printf(const char *format, ...));

	const int BUFF_SIZE = 4096;
	char buff[BUFF_SIZE];

	// set last char to 0 for overflow checking
	//
#ifndef NDEBUG
	buff[BUFF_SIZE - 1] = 0;
#endif // NDEBUG

	va_list marker;
	va_start(marker, format);
	vsprintf(buff, format, marker);
	va_end(marker);

	// overflow checking
	//
#ifndef NDEBUG
	ASSERT(buff[BUFF_SIZE - 1] == 0);
#endif // NDEBUG

	operator<<(buff);
}


//! format the text representation of a FunctionCall object
//
TextOutput &TextOutput::operator<<(const FunctionCall &functionCall)
{
    // alex: don't trace this one

    *this <<
        functionCall.name() <<
        "\t[" << functionCall.sourceFile() <<
        ":" << functionCall.line() << "]";
    return *this;
}


//! format the text representation of a CallStack object
//
TextOutput &TextOutput::operator<<(const CallStack &callStack)
{
    // alex: don't trace this one

#if !defined(LFC_DISABLE_TRACING)
    *this << "====================== call stack begin ======================\n";

    CallStack::ConstIterator it;

    for(it = callStack.begin(); it != callStack.end(); ++it)
        *this << **it << ENDL;

    *this << "======================= call stack end =======================\n";
#else
    *this << "======== call stack tracing is disabled in this build ========\n";
#endif  // defined(LFC_DISABLE_TRACING)

    return *this;
}

}	// namespace lfc


