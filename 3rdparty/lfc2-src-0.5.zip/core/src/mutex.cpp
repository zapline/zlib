
#include <lfc.debug>
#include <lfc.threads.mutex>

namespace lfc
{

Mutex::Mutex() :
	m_handle(pal::threads::NULL_MUTEX_HANDLE)
{
	int retCode = pal::threads::createMutex(m_handle);
	if(retCode)
		throw MutexException(pal::threads::message(retCode));
}


Mutex::~Mutex() throw()
{
	if(pal::threads::closeMutex(m_handle))
		/*$?*/;
}


void Mutex::lock()
{
    //TRACE(Mutex::lock());

	int retCode = pal::threads::lockMutex(m_handle);
	if(retCode)
		throw MutexException(pal::threads::message(retCode));
}

bool Mutex::tryLock()
{
    //TRACE(Mutex::tryLock());

	bool bLocked;
	int retCode = pal::threads::tryLockMutex(m_handle, bLocked);
	if(retCode)
		throw MutexException(pal::threads::message(retCode));
	return bLocked;
}

void Mutex::unlock()
{
    //TRACE(Mutex::unlock());

	int retCode = pal::threads::unlockMutex(m_handle);
	if(retCode)
		throw MutexException(pal::threads::message(retCode));
}

}	// namespace lfc


