
#include <math.h>
#include <lfc.time.hiResTimeSpan>

namespace lfc
{


HiResTimeSpan::HiResTimeSpan(long msecs, long seconds, long minutes,
    long hours, long days)
{
    TRACE(HiResTimeSpan::HiResTimeSpan(long msecs, long seconds, long minutes, long hours, long days));

	if(msecs < 0 || msecs > 999)
		throw HiResTimeSpanException("invalid number of milliseconds");
	else if(seconds < 0 || seconds > 59)
		throw HiResTimeSpanException("invalid number of seconds");
	else if(minutes < 0 || minutes > 59)
		throw HiResTimeSpanException("invalid number of minutes");
	else if(hours < 0 || hours > 23)
		throw HiResTimeSpanException("invalid number of hours");
	else if(days < 0 || days > 24)
		throw HiResTimeSpanException("invalid number of days");
	else
		m_span = days    * (1000 * 60 * 60 * 24) +
			 hours   * (1000 * 60 * 60) +
			 minutes * (1000 * 60) +
			 seconds * 1000 +
			 msecs;
}


void HiResTimeSpan::writeObject(BinaryOutput &stream) const
{
    TRACE(HiResTimeSpan::writeObject(BinaryOutput &stream) const);

	stream << m_span;
}


void HiResTimeSpan::readObject(BinaryInput &stream)
{
    TRACE(HiResTimeSpan::readObject(BinaryInput &stream));

	stream >> m_span;
}


void HiResTimeSpan::formatObject(TextOutput &stream, string format) const
{
    TRACE(HiResTimeSpan::formatObject(TextOutput &stream, string format) const);

	if(format.empty())
	{
		stream << milliseconds() << " milliseconds";
		return;
	}

	double d;
	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'D':
			d = double(m_span / (1000 * 60 * 60 * 24));
			stream << d;
			break;

		case 'd':
			stream << days();
			break;

		case 'H':
			d = double(m_span / (1000 * 60 * 60));
			stream << d;
			break;

		case 'h':
			stream << hours();
			break;

		case 'M':
			d = double(m_span / (1000 * 60));
			stream << d;
			break;

		case 'm':
			if(format[i + 1] == 's')
			{
				stream << m_span;
				++i;
			}
			else
				stream << minutes();
			break;

		case 'S':
			d = double(m_span / 1000);
			stream << d;
			break;

		case 's':
			stream << seconds();
			break;

		case '-':
			++i;
			switch(format[i])
			{
			case 'd':
				stream << days();
				break;

			case 'h':
				stream <<
				(m_span - days() * (1000 * 60 * 60 * 24)) /
				(1000 * 60 * 60);
				break;

			case 'm':
				if(format[i + 1] == 's')
				{
					stream << m_span - seconds() * 1000;
					++i;
				}
				else
					stream <<
					(m_span - hours() * (1000 * 60 * 60)) /
					(1000 * 60);
				break;

			case 's':
				stream <<
				(m_span - minutes() * (1000 * 60)) /
				1000;
				break;

			default:
				--i;
				stream << format[i];
			}
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream << format[i];
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream << format[i];
					++i;
				}
			break;

		default:
			stream << format[i];
		}
}


void HiResTimeSpan::scanObject(TextInput &stream, string format)
{
    TRACE(HiResTimeSpan::scanObject(TextInput &stream, string format));

	if(format.empty())
	{
		HiResTimeSpan();
		return;
	}

	bool	categ1Flag = false,
		categ2Flag = false,
		dFlag = false,
		hFlag = false,
		mFlag = false,
		sFlag = false,
		msFlag = false;
	long tempL, result;
	double tempD;
	string tempS;

	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'D':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'D'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'D'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 24 * 60 * 60 * 1000));
			categ1Flag = true;
			break;

		case 'd':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'd'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'd'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 24 * 60 * 60 * 1000;
			categ1Flag = true;
			break;

		case 'H':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'H'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'H'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 60 * 60 * 1000));
			categ1Flag = true;
			break;

		case 'h':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'h'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'h'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 60 * 60 * 1000;
			categ1Flag = true;
			break;

		case 'M':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'M'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'M'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 60 * 1000));
			categ1Flag = true;
			break;

		case 'm':
			if(format[i + 1] == 's')
			{
				if(categ1Flag)
					throw HiResTimeSpanException(
					"invalid symbol 'ms'; multiple symbols"
					"from the 1st category are not allowed");
				else if(categ2Flag)
					throw HiResTimeSpanException(
					"invalid symbol 'ms'; multiple symbols"
					"from both categories are not allowed");

				stream >> m_span;
				categ1Flag = true;
				++i;
			}
			else
			{
				if(categ1Flag)
					throw HiResTimeSpanException(
					"invalid symbol 'm'; multiple symbols"
					"from the 1st category are not allowed");
				else if(categ2Flag)
					throw HiResTimeSpanException(
					"invalid symbol 'm'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				m_span = tempL * 60 * 1000;
				categ1Flag = true;
			}
			break;

		case 'S':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'S'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 'S'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 1000));
			categ1Flag = true;
			break;

		case 's':
			if(categ1Flag)
				throw HiResTimeSpanException(
					"invalid symbol 's'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw HiResTimeSpanException(
					"invalid symbol 's'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 1000;
			categ1Flag = true;
			break;

		case '-':
			++i;
			switch(format[i])
			{
			case 'd':
				if(dFlag)
					throw HiResTimeSpanException(
					"invalid symbol '-d'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw HiResTimeSpanException(
					"invalid symbol '-d'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 24 * 60 * 60 * 1000;
				categ2Flag = true;
				dFlag = true;
				break;

			case 'h':
				if(hFlag)
					throw HiResTimeSpanException(
					"invalid symbol '-h'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw HiResTimeSpanException(
					"invalid symbol '-h'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 60 * 60 * 1000;
				categ2Flag = true;
				hFlag = true;
				break;

			case 'm':
				if(format[i + 1] == 's')
				{
					if(msFlag)
						throw HiResTimeSpanException(
						"invalid symbol '-ms'; use of"
						"the same symbol from the 2nd"
						"category more than once is not"
						"allowed");
					else if(categ1Flag)
						throw HiResTimeSpanException(
						"invalid symbol '-ms'; multiple"
						"symbols from both categories"
						"are not allowed");

					stream >> tempL;
					result += tempL;
					categ2Flag = true;
					msFlag = true;
					++i;
				}
				else
				{
					if(mFlag)
						throw HiResTimeSpanException(
						"invalid symbol '-m'; use of"
						"the same symbol from the 2nd"
						"category more than once is not"
						"allowed");
					else if(categ1Flag)
						throw HiResTimeSpanException(
						"invalid symbol '-m'; multiple"
						"symbols from both categories"
						"are not allowed");

					stream >> tempL;
					result += tempL * 60 * 1000;
					categ2Flag = true;
					mFlag = true;
				}
				break;

			case 's':
				if(sFlag)
					throw HiResTimeSpanException(
					"invalid symbol '-s'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw HiResTimeSpanException(
					"invalid symbol '-s'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 1000;
				categ2Flag = true;
				sFlag = true;
				break;

			default:
				--i;
				stream >> tempS;
			}
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream >> tempS;
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream >> tempS;
					++i;
				}
			break;

		default:
			stream >> tempS;
		}

	if(categ2Flag)
		m_span = result;
}


}	// namespace lfc


