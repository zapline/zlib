
#include <lfc.streams.binaryStream>

namespace lfc
{

BinaryOutput::BinaryOutput()
{
}


BinaryOutput::BinaryOutput(_Output<char> &outputBase)
{
    connectOutputBase(outputBase);
}


BinaryOutput::~BinaryOutput() throw()
{
}


BinaryOutput &BinaryOutput::operator<<(bool value)
{
    TRACE(BinaryOutput::operator<<(bool value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(Byte value)
{
    TRACE(BinaryOutput::operator<<(Byte value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(char value)
{
    TRACE(BinaryOutput::operator<<(char value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(short value)
{
    TRACE(BinaryOutput::operator<<(short value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(long value)
{
    TRACE(BinaryOutput::operator<<(long value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(Word value)
{
    TRACE(BinaryOutput::operator<<(Word value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(DWord value)
{
    TRACE(BinaryOutput::operator<<(DWord value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(float value)
{
    TRACE(BinaryOutput::operator<<(float value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(double value)
{
    TRACE(BinaryOutput::operator<<(double value));

	//writeClassID(-1);
	writeValue(value);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(const _Serializable &obj)
{
    TRACE(BinaryOutput::operator<<(const _Serializable &obj));

	obj.writeObject(*this);
	return *this;
}


BinaryOutput &BinaryOutput::operator<<(const _Serializable *pObj)
{
    TRACE(BinaryOutput::operator<<(const _Serializable *pObj));

	if(pObj == NULL)
		writeClassID(0);
	else
	{
		writeClassID(RTTI::classID(dynamic_cast<const Object &>(*pObj)));
		writeObjectID(objectID(*pObj));

		if(m_writeMap.find(objectID(*pObj)) == m_writeMap.end())
		{
			m_writeMap[objectID(*pObj)] = pObj;
			pObj->writeObject(*this);
		}
	}

	return *this;
}


void BinaryOutput::writeClassID(RTTI::ID classID)
{
    TRACE(BinaryOutput::writeClassID(RTTI::ID classID));

	writeValue(classID);
}


void BinaryOutput::writeObjectID(long objectID)
{
    TRACE(BinaryOutput::writeObjectID(long objectID));

	writeValue(objectID);
}

}	// namespace lfc


