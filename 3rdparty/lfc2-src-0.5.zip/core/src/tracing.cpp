
#include <stdio.h>

#include <lfc.debug.tracing>
#include <lfc.debug.assert>
#include <lfc.threads.thread>
#include <lfc.threads.application>

namespace lfc
{

FunctionCall::FunctionCall(const char *funcName, int line, const char *filename) :
    m_funcName(funcName),
    m_line(line),
    m_sourceFile(filename)
{
    // if the app is not running, panic and
    // do a brutal abort
    //
    if(Application::applicationState() != Thread::stRunning)
    {
        fprintf(stderr,
            "\n=================== FATAL ERROR ===================\n\n"
            "message    : TRACE macro was hit while Application was in a non 'stRunning' state\n"
            "function   : %s\n"
            "location   : %s:%d\n\n",
            funcName, filename, line);
        fflush(stderr);

        // this never return
        //
        Application::abort("PANIC");
    }
}


__FunctionCallScope::__FunctionCallScope(FunctionCall *pFunctionCall) :
    m_pFunctionCall(pFunctionCall)
{
    Thread::self()->m_callStack.pushCall(*m_pFunctionCall);
}


__FunctionCallScope::~__FunctionCallScope()
{
    Thread::self()->m_callStack.popCall(*m_pFunctionCall);
}

}	// namespace lfc


