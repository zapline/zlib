
#include <PAL.files>

namespace lfc
{
namespace posixPAL
{
namespace files
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"posixPAL::files -- No error (ok)",
	"posixPAL::files -- Generic error",
	"posixPAL::files -- Not supported",
	"posixPAL::files -- Already exists",
};


} // namespace posixPAL::files
} // namespace posixPAL
} // namespace lfc


