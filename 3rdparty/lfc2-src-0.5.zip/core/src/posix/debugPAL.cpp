
#include <PAL.debug>

namespace lfc
{
namespace posixPAL
{
namespace debug
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"posixPAL::debug -- No error (ok)",
};


} // namespace posixPAL::debug
} // namespace posixPAL
} // namespace lfc


