
#include <PAL.console>

namespace lfc
{
namespace posixPAL
{
namespace console
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"posixPAL::console -- No error (ok)",
};


} // namespace posixPAL::console
} // namespace posixPAL
} // namespace lfc


