#ifdef __linux__

#ifndef _GNU_SOURCE
# define _GNU_SOURCE	1
#endif // _GNU_SOURCE

#endif // __linux

#include <PAL.threads>

namespace lfc
{
namespace posixPAL
{
namespace threads
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"posixPAL::threads -- No error (ok)",
	"posixPAL::threads -- Generic error",
};

/*!
\note new/delete must be thread safe
*/
void * __threadProc(void *p)
{
	int retVal;
    
	retVal = ::pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	assert(retVal == 0);
    retVal = ::pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
	assert(retVal == 0);

	__StartThreadInfo *pInfo = static_cast<__StartThreadInfo *>(p);
	void (*proc)(void *) = pInfo->proc;
	void *pData = pInfo->pData;
	delete pInfo;
	(*proc)(pData);
	
	return NULL;
}

int createMutex(MutexHandle &handle)
{
	assert(handle.valid == false);

	//$ non portable code
	//lemo: to my knowledge there is no standard way to setup
	//	a recursive mutex with posix threads, but virtualy every
	//	posix threads implementation have a way to do it, so try to
	//	select a setup code based on platform

#if defined(__linux__)
	// can't directly assign to handle.handle
	// because PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP is expanded
	// to an initialization def (ie. = { ... })
	pthread_mutex_t __recursiveMutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
	handle.handle = __recursiveMutex;
#elif defined(__FreeBSD__)
	pthread_mutexattr_t attr;
	::pthread_mutexattr_init(&attr);
	::pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	if(::pthread_mutex_init(&handle.handle, &attr) != 0)
		return errGeneric;
#else
#warning using generic mutex initialization (mutex will be non-recursive!)
	if(::pthread_mutex_init(&handle.handle, NULL) != 0)
		return errGeneric;
#endif

	handle.valid = true;
	return errOk;
}


} // namespace posixPAL::threads
} // namespace posixPAL
} // namespace lfc


