
#include <PAL.sockets>

namespace lfc
{
namespace posixPAL
{
namespace sockets
{

const char *messagesTable[MAX_ERROR_CODE+1] =
{
	"posixPAL::sockets -- No error (ok)",
	"posixPAL::sockets -- Generic socket error",
	"posixPAL::sockets -- Environment not initialized",
	"posixPAL::sockets -- Connection has been closed",
	"posixPAL::sockets -- Unbound socket",
	"posixPAL::sockets -- Socket should be listening",
	"posixPAL::sockets -- Invalid hostname/IP address",
};


} // namespace posixPAL::sockets
} // namespace posixPAL
} // namespace lfc


