
#include <PAL.serial>

namespace lfc
{
namespace posixPAL
{
namespace serial
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"posixPAL::serial -- No error (ok)",
	"posixPAL::serial -- Generic error",
	"posixPAL::serial -- Not supported",
};


} // namespace posixPAL::serial
} // namespace posixPAL
} // namespace lfc


