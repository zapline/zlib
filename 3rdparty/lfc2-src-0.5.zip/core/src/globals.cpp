
#include <lfc.globals>

namespace lfc
{

Console lfcConsole;
TextOutput lfcOut;

DebugOutput lfcDebugOutput;
Logger lfcLogger;

// definition of global objects used to define assertions behavior
// (initialized with the default behavior)
//
Callback3<bool, const char *, int, const char*> lfcAssertReport = callback(&__lfcDefaultAssertReport);
Callback0<void>                                 lfcAssertAction = callback(&__lfcDefaultAssertAction);

}	// namespace lfc


