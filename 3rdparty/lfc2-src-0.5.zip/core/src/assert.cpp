
#include <stdio.h>

#include <lfc.debug.assert>
#include <lfc.debug.logging>
#include <lfc.threads.thread>
#include <lfc.threads.application>
#include <lfc.globals>


namespace lfc
{

#if !defined(LFC_DISABLE_ASSERTS)


bool __lfcAssertReport(const char *expression, int line, const char *filename)
{
    // if the app is not running, panic and
    // do a brutal abort
    //
    if(Application::applicationState() != Thread::stRunning)
    {
        fprintf(stderr,
            "\n=============== ASSERTION FAILURE IN INVALID APP STATE ===============\n\n"
            "expression  : %s\n"
            "location    : %s:%d\n\n",
            expression, filename, line);
        fflush(stderr);

        // this never return
        //
        Application::abort("PANIC");
    }

    // call global callback
    //
    return lfcAssertReport(expression, line, filename);
}


void __lfcAssertAction()
{
    // call global callback
    //
    lfcAssertAction();
}


bool __lfcDefaultAssertReport(const char *expression, int line, const char *filename)
{
    Log(lfcLogger) <<
        ENDL <<
        "====================== ASSERTION FAILURE =====================\n" <<
        ENDL <<
        "expression  : " << expression << ENDL <<
        "thread      : " << Thread::self()->name() << ENDL <<
        "location    : " << filename << ":" << line << ENDL <<
        ENDL <<
        Thread::self()->callStack() << ENDL;

    // indicate that we should fail
    //
    return true;
}


void __lfcDefaultAssertAction()
{
    abort();
}


#endif // !LFC_DISABLE_ASSERTS

}	// namespace lfc

