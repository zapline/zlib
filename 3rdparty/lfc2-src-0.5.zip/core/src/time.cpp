
#include <lfc.time.time>

namespace lfc
{


const char *Time::s_monthNames[12] =
	{
		"January", "February", "March",
		"April",   "May",      "June",
		"July",    "August",   "September",
		"October", "November", "December"
	};


const char *Time::s_dayNames[7] =
	{
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday"
	};


Time::Time(int year, Month month, int day, int hour, int min, int sec)
{
    TRACE(Time::Time(int year, Month month, int day, int hour, int min, int sec));

	struct tm incompleteTime;

	incompleteTime.tm_year = year - 1900;
	incompleteTime.tm_mon = month;
	incompleteTime.tm_mday = day;
	incompleteTime.tm_hour = hour;
	incompleteTime.tm_min = min;
	incompleteTime.tm_sec = sec;
	incompleteTime.tm_isdst = -1;

	m_time = ::mktime(&incompleteTime);

	if(m_time == NULL_TIME)
		throw TimeException("invalid date/time");
}


void Time::setYear(int year)
{
    TRACE(Time::setYear(int year));

	struct tm *time = ::gmtime(&m_time);
	time->tm_year = year - 1900;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid year");
}


void Time::setMonth(Month month)
{
    TRACE(Time::setMonth(Month month));

	struct tm *time = ::gmtime(&m_time);
	time->tm_mon = month;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid month");
}


void Time::setDay(int day)
{
    TRACE(Time::setDay(int day));

	struct tm *time = ::gmtime(&m_time);
	time->tm_mday = day;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid day");
}


void Time::setHour(int hour)
{
    TRACE(Time::setHour(int hour));

	struct tm *time = ::gmtime(&m_time);
	time->tm_hour = hour;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid hour");
}


void Time::setMinute(int min)
{
    TRACE(Time::setMinute(int min));

	struct tm *time = ::gmtime(&m_time);
	time->tm_min = min;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid minute");
}


void Time::setSecond(int sec)
{
    TRACE(Time::setSecond(int sec));

	struct tm *time = ::gmtime(&m_time);
	time->tm_sec = sec;

	m_time = ::mktime(time);

	if(m_time == NULL_TIME)
		throw TimeException("invalid second");
}


const string Time::monthName(short monthIndex) const
{
    TRACE(Time::monthName(short monthIndex) const);

	if(monthIndex < 0 || monthIndex > 11)
		throw TimeException("invalid monthIndex");

	return string(s_monthNames[monthIndex]);
}


const string Time::dayName(short dayIndex) const
{
    TRACE(Time::dayName(short dayIndex) const);

	if(dayIndex < 0 || dayIndex > 6)
		throw TimeException("invalid dayIndex");

	return string(s_dayNames[dayIndex]);
}


void Time::writeObject(BinaryOutput &stream) const
{
    TRACE(Time::writeObject(BinaryOutput &stream) const);

	stream << long(m_time);
}


void Time::readObject(BinaryInput &stream)
{
    TRACE(Time::readObject(BinaryInput &stream));

	long temp;
	stream >> temp;
	m_time = time_t(temp);
}


void Time::formatObject(TextOutput &stream, string format) const
{
    TRACE(Time::formatObject(TextOutput &stream, string format) const);

	if(format.empty())
	{
		stream << ::ctime(&m_time);
		return;
	}

	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'y':
			if(format[i + 1] == 'y')
			{
				long l = (year() % 1000) % 100;
				stream.printf("%.2d", l);
				++i;
			}
			else
				stream << year();
			break;

		case 'M':
			if(format[i + 1] == 'M')
			{
				stream << monthName(month() - 1);
				++i;
			}
			else
				stream << month();
			break;

		case 'd':
			stream << day();
			break;

		case 'h':
			if(hour() == 0)
				stream << 12;
			else if(hour() <= 12)
				stream << hour();
			else
				stream << hour() - 12;
			break;

		case 'H':
			stream << hour();
			break;

		case 'm':
			stream << minute();
			break;

		case 's':
			stream << second();
			break;

		case 'E':
			stream << dayName(dayOfTheWeek());
			break;

		case 'a':
			stream << "AM";
			break;

		case 'p':
			stream << "PM";
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream << format[i];
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream << format[i];
					++i;
				}
			break;

		default:
			stream << format[i];
		}
}


void Time::scanObject(TextInput &stream, string format)
{
    TRACE(Time::scanObject(TextInput &stream, string format));

	if(format.empty())
	{
		Time();
		return;
	}

	struct tm incompleteTime;
	incompleteTime.tm_hour = 0;
	incompleteTime.tm_min = 0;
	incompleteTime.tm_sec = 0;
	incompleteTime.tm_isdst = -1;

	bool	yearFlag = false,
		monthFlag = false,
		dayFlag = false,
		hourFlag = false,
		minFlag = false,
		secFlag = false,
		amFlag = false,
		pmFlag = false;
	long tempL, hour;
	string tempS;

	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'y':
			if(format[i + 1] == 'y')
			{
				stream >> tempL;
				++i;
			}
			else
			{
				if(yearFlag)
					throw TimeException("year already read");
				stream >> tempL;
				incompleteTime.tm_year = tempL - 1900;
				yearFlag = true;
			}
			break;

		case 'M':
			if(format[i + 1] == 'M')
			{
				if(monthFlag)
					throw TimeException("month already read");
				stream >> tempS;
				tempL = monthIndex(tempS);
				if(tempL == -1)
					throw TimeException("invalid month name");
				else
					incompleteTime.tm_mon = tempL;
				monthFlag = true;
				++i;
			}
			else
			{
				if(monthFlag)
					throw TimeException("month already read");
				stream >> tempL;
				if(0 <= tempL && tempL <= 11)
					incompleteTime.tm_mon = tempL;
				else
					throw TimeException("invalid month index");
				monthFlag = true;
			}
			break;

		case 'd':
			if(dayFlag)
				throw TimeException("day already read");
			stream >> tempL;
			if(1 <= tempL && tempL <= 31)
				incompleteTime.tm_mday = tempL;
			else
				throw TimeException("invalid day");
			dayFlag = true;
			break;

		case 'h':
			if(hourFlag)
				throw TimeException("hour already read");
			stream >> hour;
			hourFlag = true;
			break;

		case 'H':
			if(hourFlag)
				throw TimeException("hour already read");
			stream >> tempL;
			if(0 <= tempL && tempL <= 23)
				incompleteTime.tm_hour = tempL;
			else
				throw TimeException("invalid hour");
			hourFlag = true;
			break;

		case 'm':
			if(minFlag)
				throw TimeException("minute already read");
			stream >> tempL;
			if(0 <= tempL && tempL <= 59)
				incompleteTime.tm_min = tempL;
			else
				throw TimeException("invalid minute");
			minFlag = true;
			break;

		case 's':
			if(secFlag)
				throw TimeException("second already read");
			stream >> tempL;
			if(0 <= tempL && tempL <= 59)
				incompleteTime.tm_sec = tempL;
			else
				throw TimeException("invalid second");
			secFlag = true;
			break;

		case 'E':
			stream >> tempS;
			break;

		case 'a':
			if(amFlag || pmFlag)
				throw TimeException("am/pm tag already read");
			stream >> tempS;
			amFlag = true;
			break;

		case 'p':
			if(pmFlag || amFlag)
				throw TimeException("am/pm tag already read");
			stream >> tempS;
			pmFlag = true;
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream >> tempS;
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream >> tempS;
					++i;
				}
			break;

		default:
			stream >> tempS;
		}

	if(amFlag)
	{
		if(hour == 12)
			incompleteTime.tm_hour = 0;
		else if(1 <= hour && hour <= 11)
			incompleteTime.tm_hour = hour;
		else
			throw TimeException("invalid am hour");
	}
	else if(pmFlag)
	{
		if(hour == 12)
			incompleteTime.tm_hour = 12;
		else if(1 <= hour && hour <= 11)
			incompleteTime.tm_hour = hour + 12;
		else
			throw TimeException("invalid pm hour");
	}
	else
		throw TimeException("am/pm tag not read");

	m_time = ::mktime(&incompleteTime);

	if(m_time == NULL_TIME)
		throw TimeException("invalid date/time");
}


short Time::monthIndex(const string &monthName) const
{
    TRACE(Time::monthIndex(const string &monthName) const);

	for(int i = 0; i < 12; ++i)
		if(monthName == s_monthNames[i])
			return i;

	return -1;
}


}	// namespace lfc


