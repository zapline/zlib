
#include <lfc.streams.sockets>

namespace lfc
{

SocketServer::SocketServer() throw() :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
}


SocketServer::SocketServer(Word port, Socket::SocketType type) :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    TRACE(SocketServer::SocketServer(Word port, Socket::SocketType type));

	listen(port, type);
}


SocketServer::SocketServer(string service, Socket::SocketType type) :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    TRACE(SocketServer::SocketServer(string service, Socket::SocketType type));

	listen(service, type);
}


SocketServer::~SocketServer() throw()
{
	try
	{
		if(state() == stOpen)
		    close();
	}
	catch(SocketException &)
	{
		// ignore it...
	}
}


void SocketServer::listen(Word port, Socket::SocketType type)
{
    TRACE(SocketServer::listen(Word port, Socket::SocketType type));

	int retCode;

	testState(stClosed);

	// 1. create socket
	retCode = pal::sockets::open(m_handle, Socket::pfINET, type);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	// 2. bind
	retCode = pal::sockets::bind(m_handle, Socket::pfINET, port);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	// 3. listen
	retCode = pal::sockets::listen(m_handle);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	m_state = stOpen;
	sigInit();
}


void SocketServer::listen(string service, Socket::SocketType type)
{
    TRACE(SocketServer::listen(string service, Socket::SocketType type));

	Word port;
	int retCode = pal::sockets::getServicePort(service.c_str(), port);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
	listen(port, type);
}


void SocketServer::close()
{
    TRACE(SocketServer::close());

	if(m_state == stClosed)
		return;

	int retCode = pal::sockets::close(m_handle);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	m_state = stClosed;
	m_handle = pal::sockets::NULL_HANDLE;
	sigShutdown();
}


pal::sockets::Handle SocketServer::accept()
{
    TRACE(SocketServer::accept());

	pal::sockets::Handle acceptedHandle = pal::sockets::NULL_HANDLE;

	int retCode = pal::sockets::accept(acceptedHandle, m_handle);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
	return acceptedHandle;
}


}	// namespace lfc


