
#include <lfc.smartPtr>

namespace lfc
{

Mutex *PtrBase::s_pMutex = NULL;
PtrBase::MutexInitializer PtrBase::s_mutexInitializer;

}	// namespace lfc


