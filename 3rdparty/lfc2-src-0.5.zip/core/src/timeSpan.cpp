
#include <math.h>
#include <lfc.time.timeSpan>

namespace lfc
{


TimeSpan::TimeSpan(long seconds, long minutes, long hours, long days)
{
    TRACE(TimeSpan::TimeSpan(long seconds, long minutes, long hours, long days));

	if(seconds < 0 || seconds > 59)
		throw TimeSpanException("invalid number of seconds");
	else if(minutes < 0 || minutes > 59)
		throw TimeSpanException("invalid number of minutes");
	else if(hours < 0 || hours > 23)
		throw TimeSpanException("invalid number of hours");
	else if(days < 0 || days > 24855)
		throw TimeSpanException("invalid number of days");
	else
		m_span = days    * (60 * 60 * 24) +
			 hours   * (60 * 60) +
			 minutes * 60 +
			 seconds;
}


void TimeSpan::writeObject(BinaryOutput &stream) const
{
    TRACE(TimeSpan::writeObject(BinaryOutput &stream) const);

	stream << m_span;
}


void TimeSpan::readObject(BinaryInput &stream)
{
    TRACE(TimeSpan::readObject(BinaryInput &stream));

	stream >> m_span;
}


void TimeSpan::formatObject(TextOutput &stream, string format) const
{
    TRACE(TimeSpan::formatObject(TextOutput &stream, string format) const);

	if(format.empty())
	{
		stream << seconds() << " seconds";
		return;
	}

	double d;
	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'D':
			d = double(m_span / (60 * 60 * 24));
			stream << d;
			break;

		case 'd':
			stream << days();
			break;

		case 'H':
			d = double(m_span / (60 * 60));
			stream << d;
			break;

		case 'h':
			stream << hours();
			break;

		case 'M':
			d = double(m_span / 60);
			stream << d;
			break;

		case 'm':
			stream << minutes();
			break;

		case 's':
			stream << m_span;
			break;

		case '-':
			++i;
			switch(format[i])
			{
			case 'd':
				stream << days();
				break;

			case 'h':
				stream << (m_span - days() * (60 * 60 * 24)) /
					(60 * 60);
				break;

			case 'm':
				stream << (m_span - hours() * (60 * 60)) / 60;
				break;

			case 's':
				stream << (m_span - minutes() * 60);
				break;

			default:
				--i;
				stream << format[i];
			}
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream << format[i];
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream << format[i];
					++i;
				}
			break;

		default:
			stream << format[i];
		}
}


void TimeSpan::scanObject(TextInput &stream, string format)
{
    TRACE(TimeSpan::scanObject(TextInput &stream, string format));

	if(format.empty())
	{
		TimeSpan();
		return;
	}

	bool	categ1Flag = false,
		categ2Flag = false,
		dFlag = false,
		hFlag = false,
		mFlag = false,
		sFlag = false;
	long tempL, result;
	double tempD;
	string tempS;

	for(unsigned int i = 0; i < format.size(); ++i)
		switch(format[i])
		{
		case 'D':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'D'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'D'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 24 * 60 * 60));
			categ1Flag = true;
			break;

		case 'd':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'd'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'd'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 24 * 60 * 60;
			categ1Flag = true;
			break;

		case 'H':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'H'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'H'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 60 * 60));
			categ1Flag = true;
			break;

		case 'h':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'h'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'h'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 60 * 60;
			categ1Flag = true;
			break;

		case 'M':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'M'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'M'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempD;
			m_span = long(floor(tempD * 60));
			categ1Flag = true;
			break;

		case 'm':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 'm'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 'm'; multiple symbols"
					"from both categories are not allowed");

			stream >> tempL;
			m_span = tempL * 60;
			categ1Flag = true;
			break;

		case 's':
			if(categ1Flag)
				throw TimeSpanException(
					"invalid symbol 's'; multiple symbols"
					"from the 1st category are not allowed");
			else if(categ2Flag)
				throw TimeSpanException(
					"invalid symbol 's'; multiple symbols"
					"from both categories are not allowed");

			stream >> m_span;
			categ1Flag = true;
			break;

		case '-':
			++i;
			switch(format[i])
			{
			case 'd':
				if(dFlag)
					throw TimeSpanException(
					"invalid symbol '-d'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw TimeSpanException(
					"invalid symbol '-d'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 24 * 60 * 60;
				categ2Flag = true;
				dFlag = true;
				break;

			case 'h':
				if(hFlag)
					throw TimeSpanException(
					"invalid symbol '-h'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw TimeSpanException(
					"invalid symbol '-h'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 60 * 60;
				categ2Flag = true;
				hFlag = true;
				break;

			case 'm':
				if(mFlag)
					throw TimeSpanException(
					"invalid symbol '-m'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw TimeSpanException(
					"invalid symbol '-m'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL * 60;
				categ2Flag = true;
				mFlag = true;
				break;

			case 's':
				if(sFlag)
					throw TimeSpanException(
					"invalid symbol '-s'; use of the same"
					"symbol from the 2nd category more than"
					"once is not allowed");
				else if(categ1Flag)
					throw TimeSpanException(
					"invalid symbol '-s'; multiple symbols"
					"from both categories are not allowed");

				stream >> tempL;
				result += tempL;
				categ2Flag = true;
				sFlag = true;
				break;

			default:
				--i;
				stream >> tempS;
			}
			break;

		case '\'':
			++i;
			if(format[i] == '\'')
			{
				stream >> tempS;
				break;
			}
			else
				while(format[i] != '\'')
				{
					stream >> tempS;
					++i;
				}
			break;

		default:
			stream >> tempS;
		}

	if(categ2Flag)
		m_span = result;
}


}	// namespace lfc


