
// File: core/src/regexp.cpp
// Author: Navin Vembar
//
// This contains the everything associated with the guts of regular expression
// system for LFC.  This includes all of the definitions and declarations for
// the RegexpPatternBlock classes, the RegexpPattern class itself, and the
// RegexpInput class.
//
// Important notes:
//
// The implementation of regular expression matching in split amongst many
// classes.  The parsing of the pattern is done by RegexpPattern itself.  It
// builds up a linked list of subclasses of RegexpPattern::RegexpPatternBlock.
// The "blocks" represent a basic subexpression of the global expression.  For
// example, matching a specific string, or a matching a single character to a
// character class is all done by individual classes.  Multiplicities are
// managed by encompassing subblocks in a multiplicity block, etc.
//
// Currently, the following subexperssions are supported:
// []: character classes, including negation by ^
// .: Matches any character but newline
// ^,$: anchors (start and end of line -- start anchor, when passed a stream
//      require that no movement from the original stream position is needed
//      for a match, not that one is at the start of a line).
// *,+,{m}, {m,}, {m,n}: Multiplicities, including ranged multiplicities.
// (): Grouping via parens -- this will allow for backreferences soon enough
// |: Alternation.
//
// What is not supported:  Use of [::alpha::], etc. in [], backreferences
// (e.g, \1 to refer to the first grouped submatch), \l, \L, \w, etc.  There
// are other features not supported yet, but these are the biggies, I think.
//
// There is no optimization yet.  There will be, at some point.  Specifically,
// .*, .+, etc. will be handled as special cases, there should be smarter
// handling of the case where the EOL anchor is used.
//
// See also: The commends about RegexpPattern::RegexpPatternBlock::doMatch().

#include <ctype.h>
#include <lfc.globals>
#include <lfc.streams.memoryIO>
#include <lfc.streams.putbackTextInput>
#include <lfc.utility.regexp>

namespace lfc
{

//////////////////////////////////////////////////////////////////
// class RegexpPatternBlock
//
// A class internal to RegexpPattern which does the actual work of matching a
// string in a PutbackTextInput stream.  It needs to be subclassed (and
// doMatch() implemented) to be useful.
RegexpPattern::RegexpPatternBlock::RegexpPatternBlock() throw()
{
	m_next = NULL;
}

// Does the actual matching for a particular block *and all subsequent
// blocks* -- m_next->doMatch() must be called by this method.
// The reason for this is made evident in the
// implementation of MultiplicityPatternBlock -- failure for the
// following patterns to match does not mean that the entire pattern
// didn't match, it just might need some backtracking.
//
// The match object is built forward so that backreferences can be
// made.  Meaning, the match must represent the currently matched substring.
bool RegexpPattern::RegexpPatternBlock::doMatch(PutbackTextInput &,
		RegexpMatch &, int)
{
	throw RegexpException("Internal error: RegexpPatternBlock was not subclassed");
}

///////////////////////////////////////////////////////////////////////
// class MultiplicityPatternBlock
//
// Implements repeated matching of a pattern.
bool RegexpPattern::MultiplicityPatternBlock::doMatch(
		PutbackTextInput &in, RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::MultiplicityPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	int m;
	string s;
	RegexpMatch submatch, nextMatch;
	long read = 0;
	unsigned int initialSaves;
	std::list<RegexpMatch *> optionalMatches;

	// In truth, this error should never occur unless the user has
	// directly used the set*Multiplicity methods to change
	// the values set by the user via the parsed regular
	// expression.
	if((m_maxMultiplicity != INFINITE_MULTIPLICITY &&
		m_minMultiplicity > m_maxMultiplicity) ||
		m_minMultiplicity < 0)
	{
		throw RegexpParseException("Invalid multiplicity range"
			" for regular expression");
	}

	initialSaves = match.savedMatches.size();

	// Read at least the minimum multiplicity of tokens.
	for(m = 0; m < m_minMultiplicity; m++)
	{
		if(!m_subblock->doMatch(in, submatch, offset))
		{
			in.putback(read);
			return false;
		}
		// No match offset stuff b/c no nontrivial block can have an
		// offset except for the OffsetBlock
		read += submatch.match.length();
		offset += submatch.match.length();

		// Append to the original match -- this includes saved
		// matches.
		match.match += submatch.match;
		if(submatch.savedMatches.size() > 0)
		{
			match.savedMatches.insert(
				match.savedMatches.end(),
				submatch.savedMatches.begin(),
				submatch.savedMatches.end());
		}
	}

	// Read optional matches -- that is, read matches beyond the
	// required minimum
	while(m_maxMultiplicity == INFINITE_MULTIPLICITY
			|| m < m_maxMultiplicity)
	{
		RegexpMatch *pmatch = new RegexpMatch;
		if(!m_subblock->doMatch(in, *pmatch, offset))
		{
			// I'm done matching here, so I just break
			break;
		}
		read += pmatch->match.length();
		offset += pmatch->match.length();
		optionalMatches.push_back(pmatch);
		m++;

		// Append the result.
		match.match += pmatch->match;
		if(pmatch->savedMatches.size() > 0)
		{
			match.savedMatches.insert(
				match.savedMatches.end(),
				pmatch->savedMatches.begin(),
				pmatch->savedMatches.end());
		}
	}

	if(m_next != NULL)
	{
		// Now I can unread unnecessary matches if the next
		// pattern fails to match.
		std::vector<RegexpMatch *>::const_iterator i;
		std::vector<RegexpMatch *>::const_iterator b;
		std::vector<RegexpMatch *>::const_iterator e;
		//while(optionalMatches.size() >= 0)
		for(;;)
		{
			// Note that we could have an zero optional
			// match size here -- this is because optional
			// matches are just that: optional.  Which
			// means, that as long as the next thing
			// matches, even if no optional matches made
			// it, we are safe.  That's why we have the
			// extra optionalMatches.size() test after the
			// failure of next next match.
			if(!m_next->doMatch(in, match, offset))
			{
				RegexpMatch *noMatch;
				int unread;
				int newSM;

				// We've failed to match.
				if(optionalMatches.size() == 0)
					break;

				// If we fail to match, we just drop
				// back by one optional match, if there
				// is one.  This includes unreading
				// the data from the stream
				noMatch = optionalMatches.back();
				optionalMatches.pop_back();
				unread = noMatch->match.length();

				read -= unread;
				offset -= unread;
				// Remove the part of the match string
				// corresponding to the optional
				// match.
				match.match.erase(match.match.length()
					- noMatch->match.length(),
					noMatch->match.length());
				// Removes the last portion of the
				// saved submatches.
				newSM = match.savedMatches.size() -
					noMatch->savedMatches.size();
				match.savedMatches.resize(newSM);

				// Free up memory used by saved
				// submatches
				b = noMatch->savedMatches.begin();
				e = noMatch->savedMatches.end();
				for(i = b; i != e; i++)
					delete (*i);

				delete noMatch;

				in.putback(unread);
			}
			else
			{
				// I have a successful match.
				return true;
			}
		}
	}
	else // there was no other pattern, so we matched.
	{
		return true;
	}

	// We've failed to match as we would have to unread required
	// matches.  So, we clear off our required match string which
	// we appended and return false.
	match.match.erase(match.match.length() - read, read);

	// We reset the size of the savedMatches to the correct
	// size, freeing up memory as we go.
	while(match.savedMatches.size() > initialSaves)
	{
		RegexpMatch *noMatch;
		noMatch = match.savedMatches.back();
		delete noMatch;
		match.savedMatches.pop_back();
	}

	in.putback(read);
	return false;
}

// Represents a range of characters from m_s to m_e
struct CharacterRange
{
	char m_s, m_e;
};

// Represents a collection of ranges.
class CharacterCollection
{
public:
	CharacterCollection() throw()
	{
		TRACE(CharacterCollection::CharacterCollection() throw());

		m_ranges.empty();
		m_allowNewLine = false;
		m_negated = false;
	}

	virtual ~CharacterCollection() throw()
	{
		TRACE(CharacterCollection::~CharacterCollection() throw());

		std::list<CharacterRange *>::const_iterator i;
		i = m_ranges.begin();
		while(i != m_ranges.end())
		{
			delete (*i);
			m_ranges.pop_front();
			i = m_ranges.begin();
		}
	}


public:
	// Allows the addition of a new range of characters
	// Returns false if s > e.
	virtual bool addRange(char s, char e) throw()
	{
		TRACE(CharacterCollection::addRange(char, char) throw());

		CharacterRange *range = new CharacterRange();
		if(s > e)
			return false;
		range->m_s = s;
		range->m_e = e;
		m_ranges.push_back(range);
		return true;
	}

	virtual void setNegated(bool negated) throw()
	{
		m_negated = negated;
	}

	virtual bool negated() const throw()
	{
		return m_negated;
	}

	// Tests whether a character is in this collection
	virtual bool inCollection(char c) const throw()
	{
		TRACE(CharacterCollection::inCollection(char) throw());

		std::list<CharacterRange *>::const_iterator i;
		// Special case out new lines.  Note negation does not affect
		// whether new lines are allowed or not.
		if(c == '\n')
			return m_allowNewLine;

		for(i = m_ranges.begin(); i != m_ranges.end(); ++i)
		{
			if((*i)->m_s <= c && (*i)->m_e >= c)
				return !m_negated;
		}
		return m_negated;
	}

	// By default, new lines will *never* match a collection -- this is
	// because they are treated as such in regular expression matching, in
	// general.  One has to specifically request that a new line be
	// allowed in this collection in order for inCollection('\n') to be
	// true.
	virtual void setAllowNewLine(bool allowNewLine) throw()
	{
		m_allowNewLine = allowNewLine;
	}

	virtual bool allowNewLine() const throw()
	{
		return m_allowNewLine;
	}
protected:
	std::list<CharacterRange *> m_ranges;

	bool m_negated;
	bool m_allowNewLine;
};

////////////////////////////////////////////////////////////////////
// class CharacterCollectionPatternBlock
//
// This block corresponds to a [a-z] type regexp subpattern.
RegexpPattern::CharacterCollectionPatternBlock::
	~CharacterCollectionPatternBlock() throw()
{
	delete m_pCollection;
}
//
// Simple match -- just check whether the next charater (if there is
// one) is in the given collection (or the opposite in case of negation)
bool RegexpPattern::CharacterCollectionPatternBlock::doMatch(
			PutbackTextInput &in, RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::CharacterCollectionPatternBlock::doMatch(
		PutbackTaxtInput &, RegexpMatch &, int));

	char c;
	if(!in.hasMore())
	{
		return false;
	}

	c = in.pop();

	// This checks whether the character matches (or doesn't, in
	// case of negation).
	if(m_pCollection->inCollection(c))
	{
		// Append the matched character.
		match.match.append(&c, 1);
		offset++;
		if(m_next == NULL ||
				m_next->doMatch(in, match, offset))
		{
			return true;
		}
		else
		{
			// remove the appended character
			match.match.erase(match.match.length() - 1, 1);
			in.putback(1);
			return false;
		}
	}
	else
	{
		in.putback(1);
		return false;
	}
}

/////////////////////////////////////////////////////////////////////
// class StringPatternBlock
//
// This block matches a string in the input.
bool RegexpPattern::StringPatternBlock::doMatch(PutbackTextInput &in,
			RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::StringPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	char *readBuffer;
	int length = m_s.length();
	int read;
	if(!in.hasMore())
	{
		return false;
	}

	readBuffer = new char[length + 1];
	readBuffer[length] = '\0';
	read = in.read(readBuffer, length);


	// Matched the string.
	if(read == length && m_s == readBuffer)
	{
		match.match.append(readBuffer);
		offset += length;

		// Find out whether the next pattern matches.
		if(m_next == NULL ||
				m_next->doMatch(in, match, offset))
		{
			return true;
		}
		else
		{
			match.match.erase(match.match.length() - length,
					length);
			return false;
		}
	}
	else
	{
		in.putback(read);
		return false;
	}
}

////////////////////////////////////////////////////////////////////////
// class AnyCharPatternBlock
//
// Matches any character but newline.
bool RegexpPattern::AnyCharPatternBlock::doMatch(PutbackTextInput &in,
		RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::AnyCharPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	char c;
	if(in.hasMore())
	{
		c = in.pop();
		if(c == '\n')
		{
			in.putback(1);
			return false;
		}

		// Otherwise, we have a match.
		match.match.append(&c, 1);
		offset++;
		if(m_next == NULL ||
			m_next->doMatch(in, match, offset))
		{
			return true;
		}
		else
		{
			match.match.erase(match.match.length() - 1, 1);
			return false;
		}
	}
	return false;
}

////////////////////////////////////////////////////////////////////////
// class GroupPatternBlock
//
// Implements the grouping "()" faciliity for regular expressions.  The
// m_patternBlock member is the first element of the grouped subexpressions.
bool RegexpPattern::GroupPatternBlock::doMatch(PutbackTextInput &in,
		RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::GroupPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	RegexpMatch *myMatch = new RegexpMatch;
	unsigned int initialSaves = match.savedMatches.size();

	if(m_patternBlock->doMatch(in, *myMatch, offset))
	{
		// Adjust the match string.
		match.match += myMatch->match;

		// Set the offset within the string.
		myMatch->offset = offset;

		// Adjust offset
		offset += myMatch->match.length();

		// We are a saved submatch, so we put ourselves into
		// the list.
		match.savedMatches.push_back(myMatch);

		// Here we "flatten" the saved submatches -- we don't
		// really want a structure that has nested submatches,
		// simply because backreferences won't work right.
		if(myMatch->savedMatches.size() > 0)
		{
			match.savedMatches.insert(
					match.savedMatches.end(),
					myMatch->savedMatches.begin(),
					myMatch->savedMatches.end());
			// empty the submatches of my match.
			myMatch->savedMatches.resize(0);
		}

		if(m_next == NULL || m_next->doMatch(in, match, offset))
		{
			return true;
		}

		// I've failed to match here.
		match.match.erase(match.match.length() -
				myMatch->match.length(),
				myMatch->match.length());

		// Removed the appended submatches
		while(match.savedMatches.size() > initialSaves)
		{
			RegexpMatch *noMatch =
				match.savedMatches.back();
			delete noMatch;
			match.savedMatches.pop_back();
		}

		delete myMatch;
		in.putback(myMatch->match.length());
		return false;
	}
	else
	{
		delete myMatch;
		return false;
	}
}

////////////////////////////////////////////////////////////////////////
// class OrPatternBlock
//
// Implements the alternation operator '|' for regular expressions.  The left
// and right blocks are the first node in the left and right expressions.
// Note that the left expression is evaluated first and that '|' is a short
// circuit operator.
bool RegexpPattern::OrPatternBlock::doMatch(PutbackTextInput &in,
			RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::OrPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	if(m_left->doMatch(in, match, offset) ||
			m_right->doMatch(in, match, offset))
	{
		if(m_next == NULL || m_next->doMatch(in, match, offset))
			return true;
		else
			return false;
	}
	else
	{
		return false;
	}
}

////////////////////////////////////////////////////////////////////////
// class OffsetPatternBlock
//
// This eats up the beginning of a string until the next block can match.  It
// should be used by top-level patterns at the start when the '^' was not
// specified.
bool RegexpPattern::OffsetPatternBlock::doMatch(PutbackTextInput &in,
			RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::OffsetPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	long read = 0;
	ASSERT(offset == 0);  // Offset blocks should only occur at start

	while(in.hasMore())
	{
		if(m_next->doMatch(in, match, read))
		{
			match.offset = read;
			return true;
		}
		read++;
		if(in.pop() == '\n')
			break;
	}

	// reached the end of line/end of string without matching
	in.putback(read);
	return false;
}

/////////////////////////////////////////////////////////////////////////
// class StartAnchorPatternBlock
//
// This ensures that the offset is zero.  It corresponds to specifying '^' at
// the start of the pattern
bool RegexpPattern::StartAnchorPatternBlock::doMatch(PutbackTextInput &in,
			RegexpMatch &match, int offset)
{
	TRACE(RegexpPattern::StartAnchorPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	ASSERT(m_next != NULL); // Internal error if this happens
	return offset == 0 && m_next->doMatch(in, match, offset);
}

/////////////////////////////////////////////////////////////////////////
// class EndAnchorPatternBlock
//
// This matches EOF or a new line, but does not append it to the match.  It
// corresponds to specifying '$' at the end of a pattern
bool RegexpPattern::EndAnchorPatternBlock::doMatch(PutbackTextInput &in,
		RegexpMatch &match, int) // param offset unused
{
	TRACE(RegexpPattern::EndAnchorPatternBlock::doMatch(
		PutbackTextInput &, RegexpMatch &, int));

	ASSERT(m_next == NULL); // this must be the last block

	if(!in.hasMore())
		return true;

	char c = in.pop();
	if(c == '\n')
	{
		// doesn't add to the match, but does eat up the EOL
		match.eolAnchorMatch = true;
		return true;
	}
	else if(c == '\r')
	{
		if(in.pop() != '\n')
		{
			in.putback(2);
			return false;
		}
		else
		{
			match.eolAnchorMatch = true;
			return true;
		}
	}
	else
	{
		in.putback(1);
		return false;
	}
}

// RegexpPattern methods

RegexpPattern::RegexpPattern(string pattern)
{
	m_topLevel = true;
	init(pattern);
}

RegexpPattern::RegexpPattern(string pattern, bool topLevel)
{
	m_topLevel = topLevel;
	init(pattern);
}

// An extremely non-trivial constructor.  It parses the regular expression
// pattern -- this probably shouldn't be put into a constructor.
void RegexpPattern::init(string pattern)
{
	TRACE(RegexpPattern::init(string));

	m_anchorStart = false;
	m_anchorEnd = false;

	m_headBlock = m_tailBlock = new RegexpPatternBlock();
	m_headBlock->m_next = NULL;
	parsePattern(pattern.c_str());
}

RegexpPattern::~RegexpPattern() throw()
{
	TRACE(RegexpPattern::~RegexpPattern() throw());

	RegexpPatternBlock *block = m_headBlock;
	while(block)
	{
		RegexpPatternBlock *nextBlock = block->m_next;
		delete block;
		block = nextBlock;
	}
}

// Parse methods

void RegexpPattern::parsePattern(const char *pattern)
{
	TRACE(RegexpPattern::parsePattern(const char *));

	const char *src = pattern;

	if(*src == '^')
	{
		// Anchored, so we create an anchor.
		m_tailBlock->m_next = new StartAnchorPatternBlock();
		m_tailBlock = m_tailBlock->m_next;
		m_anchorStart = true;
		src++;
	}
	else if(m_topLevel)
	{
		// no anchor and we are top level, so we allow for offset
		// reading.  This is the only difference between top-level and
		// non-top level patterns.
		m_tailBlock->m_next = new OffsetPatternBlock();
		m_tailBlock = m_tailBlock->m_next;
	}

	// Now read and parse the rest of the pattern
	while(*src)
	{
		string error = "";

		// The parseXXX methods move the src pointer forward
		switch(*src)
		{
		case '[':
			parseCharacterClassBlock(src);
			break;
		case '(':
			parseParensBlock(src);
			break;
		case '|':
			parseOrBlock(src);
			break;
		case '*': case '+': case '{':
			parseMultiplicityBlock(src);
			break;
		case '.':
			parseAnyCharBlock(src);
			break;
		case '$':
			parseEndAnchorBlock(src);
			break;
		case '^':
			throw RegexpParseException("Start-of-line anchor can"
				" only appear at start of regular expression");
		case ')': case ']': case '}':
			error.append("Mismatched '");
			error.append(src, 1);
			error.append("' in regular expression");
			throw RegexpParseException(error);
		default:
			parseStringBlock(src);
			break;
		}

	}
}

void RegexpPattern::parseStringBlock(const char *&src)
{
	TRACE(RegexpPattern::parseStringBlock(const char *&));

	StringPatternBlock *block;
	string s;
	while(*src && !isSpecialChar(*src))
	{
		char c;
		if(*src == '\\')
			c = getEscapeChar(src);
		else
			c = *src;
		s.append(&c, 1);
		src++;
	}
	block = new StringPatternBlock(s);

	// This even works in the case where this is the first block
	m_tailBlock->m_next = block;
	m_tailBlock = block;
}

// Reads a character class block -- something like [^A-Z].
void RegexpPattern::parseCharacterClassBlock(const char *&src)
{
	TRACE(RegexpPattern::parseCharacterClassBlock(const char *&));

	CharacterCollection *collection = new CharacterCollection;
	CharacterCollectionPatternBlock *block;
	char s, e;
	bool negated;

	ASSERT(*src == '[');

	src++;
	negated = (*src == '^');

	while(*src)
	{
		if(*src == ']')
		{
			src++; // shift past the ']'
			collection->setNegated(negated);
			block = new CharacterCollectionPatternBlock(collection);
			m_tailBlock->m_next = block;
			m_tailBlock = block;
			return;
		}
		else if(*src == '\\')
		{
			// Since \- isn't normally a valid escape character,
			// we treat it specially.
			if(src[1] == '-')
			{
				s = e = '-';
				src += 2;
			}
			else
			{
				s = e = getEscapeChar(src);
			}
		}
		else
		{
			s = e = *src++;
		}

		// Actually have a range.
		if(*src == '-')
		{
			e = *++src;

			// Even though I know there is going to be an error
			// (no ranges could possibly have escaped chars),
			// I still translate e so it can be used properly in
			// the error message.
			if(e == '\\')
			{
				if(src[1] == '-')
					e = '-';
				else
					e = getEscapeChar(src);
			}

			// Ranges can only be ranges of digits, upper or lower
			// case characters.  No ASCII weirdness allowed.
			if((!(isdigit(s) && isdigit(e)) &&
				!(isupper(s) && isupper(e)) &&
				!(islower(s) && islower(e))) ||
					(s > e))
			{
				string error = "Invalid character range: '";

				if(s == '\n')
					error.append("\\n");
				else if(s == '\t')
					error.append("\\t");
				else
					error.append(&s, 1);

				error.append("' to '");

				if(e == '\n')
					error.append("\\n");
				else if(e == '\t')
					error.append("\\t");
				else
					error.append(&e, 1);

				error.append("'");
				throw RegexpParseException(error);
			}
			src++;
		}

		// Specific request for new line to be included
		if(s == '\n' && !negated)
			collection->setAllowNewLine(true);
		collection->addRange(s, e);
	}
	throw RegexpParseException("Unmatched ']'");
}

void RegexpPattern::parseParensBlock(const char *&src)
{
	TRACE(RegexpPattern::parseParensBlock(const char *&));

	ASSERT(*src == '(');
	string subpattern = "";
	int len, parenCnt; // Length includes the last parens.
	GroupPatternBlock *block;
	RegexpPattern *group;

	len = 0;
	parenCnt = 1;
	src++;

	while(parenCnt > 0)
	{
		if(src[len] == '(')
			parenCnt++;
		else if(src[len] == ')')
			parenCnt--;
		else if(src[len] == '\0')
			throw RegexpParseException("Premature end of pattern");
		len++;
	}

	// This means that we only found the left parens
	if(len == 1)
		throw RegexpParseException("Empty parens not allowed");

	subpattern.append(src, len - 1);

	// This is not a top level pattern
	group = new RegexpPattern(subpattern, false);

	// Give the Group block the first nontrivial block.
	block = new GroupPatternBlock(group->m_headBlock->m_next);
	m_tailBlock->m_next = block;
	m_tailBlock = block;

	// Move past the left parens
	src += len;
}

void RegexpPattern::parseOrBlock(const char *&src)
{
	TRACE(RegexpPattern::parseOrBlock(const char *&));

	ASSERT(*src == '|');
	// This is a little weirder than most.  I use all of the pattern prior
	// to the '|' as the left expression, and construct a new pattern out of
	// the remainder of the string, then appropriate its
	// m_headBlock->m_next as the right expression.
	string rightStr;
	RegexpPatternBlock *right;
	RegexpPattern *pattern;
	OrPatternBlock *block;

	src++; // shift past the '|'

	if(*src == '\0')
	{
		throw RegexpParseException("A non-trivial expression must "
				"follow the alternation operator.");
	}
	else if(m_topLevel || m_anchorStart)
	{
		// We either have an offset block or an anchor block, so we
		// make sure we have one thing beyond that.
		if(m_headBlock->m_next->m_next == NULL)
			throw RegexpParseException("A non-trivial expression "
				"must precede the alternation operator.");
	}
	else if(m_headBlock->m_next == NULL)
	{
		throw RegexpParseException("A non-trivial expression must "
				"precede the alternation operator.");
	}
	// The rest of the string is the right block.
	rightStr.append(src);

	// Build the new pattern, making sure that it is indicated that the
	// subexpression is top-level exactly if we are.
	pattern = new RegexpPattern(rightStr, m_topLevel);
	right = pattern->m_headBlock->m_next;
	// So that deep destruction won't delete the stuff we need.
	pattern->m_headBlock->m_next = NULL;
	delete pattern;

	block = new OrPatternBlock(m_headBlock->m_next, right);
	block->m_next = NULL;
	m_headBlock->m_next = block;

	src += rightStr.length(); // put us at the end of the string.
}

void RegexpPattern::parseMultiplicityBlock(const char *&src)
{
	TRACE(RegexpPattern::parseMultiplicityBlock(const char *&));

	ASSERT(*src == '*' || *src == '+' || *src == '{');
	MultiplicityPatternBlock *block;
	RegexpPatternBlock *penult;  // The penultimate pattern block

	penult = m_headBlock;


	if(penult->m_next == NULL || !m_tailBlock->isModifiable())
		throw RegexpParseException("Multiplicity modifier must follow"
			" a modifiable expression");

	// Find the penultimate block
	while(penult->m_next != m_tailBlock)
		penult = penult->m_next;

	// We are applying this modifier to the last block
	block = new MultiplicityPatternBlock(m_tailBlock);
	if(*src == '*')
	{
		src++;
		block->setMinMultiplicity(0);
		block->setMaxMultiplicity(MultiplicityPatternBlock::INFINITE_MULTIPLICITY);
	}
	else if(*src == '+')
	{
		src++;
		block->setMinMultiplicity(1);
		block->setMaxMultiplicity(MultiplicityPatternBlock::INFINITE_MULTIPLICITY);
	}
	else if(*src == '{')
	{
		throw RegexpParseException("Ranged multiplicity unsupported");
	}

	// Replace the tail block with the new multiplicity block.
	penult->m_next = block;
	m_tailBlock = block;
}

void RegexpPattern::parseAnyCharBlock(const char *&src)
{
	TRACE(RegexpPattern::parseAnyCharBlock(const char *&));

	ASSERT(*src == '.');
	AnyCharPatternBlock *block = new AnyCharPatternBlock();

	src++;
	m_tailBlock->m_next = block;
	m_tailBlock = block;
}

void RegexpPattern::parseEndAnchorBlock(const char *&src)
{
	TRACE(RegexpPattern::parseEndAnchorBlock(const char *&));

	EndAnchorPatternBlock *block = new EndAnchorPatternBlock();
	m_anchorEnd = true;

	src++;
	if(*src != '\0' && *src != '|')
		throw RegexpParseException("End-of-line anchor must end the pattern");

	// Nothing besides the end of line or beginning of line anchor
	if(m_tailBlock == m_headBlock ||
			(!m_anchorStart && m_tailBlock == m_headBlock->m_next))
		throw RegexpParseException("End-of-line anchor must follow a "
			"non-trivial pattern");

	m_beforeAnchor = m_tailBlock;
	m_tailBlock->m_next = block;
	m_tailBlock = block;
}

// Set/unset anchors

void RegexpPattern::setAnchorAtEnd(bool anchorEnd)
{
	TRACE(RegexpPattern::setAnchorAtEnd(bool));

	if(!m_topLevel)
		throw RegexpException("Attempt to make invalid change to "
			"anchor state");


	// Nothing changed
	if(anchorEnd == m_anchorEnd)
		return;

	if(anchorEnd)
	{
		EndAnchorPatternBlock *block = new EndAnchorPatternBlock();

		m_anchorEnd = true;
		m_beforeAnchor = m_tailBlock;
		m_tailBlock->m_next = block;
		m_tailBlock = block;
	}
	else
	{
		delete m_beforeAnchor->m_next;  // delete the old anchor
		m_tailBlock = m_beforeAnchor; // reset the tail.
		m_tailBlock->m_next = NULL;
		m_beforeAnchor = NULL;
	}
}

void RegexpPattern::setAnchorAtStart(bool anchorStart)
{
	TRACE(RegexpPattern::setAnchorAtStart(anchorStart));

	if(!m_topLevel)
		throw RegexpException("Attempt to make invalid change to "
			"anchor state");

	// Nothing changed
	if(anchorStart == m_anchorStart)
		return;

	if(anchorStart)
	{
		StartAnchorPatternBlock *start = new StartAnchorPatternBlock();

		RegexpPatternBlock *offset = m_headBlock->m_next;

		// replace the offset block in the list.
		start->m_next = offset->m_next;
		m_headBlock->m_next = start;

		delete offset;
	}
	else
	{
		OffsetPatternBlock *offset = new OffsetPatternBlock;
		RegexpPatternBlock *start = m_headBlock->m_next;

		offset->m_next = start->m_next;
		m_headBlock->m_next = offset;

		delete start;
	}
}

// Character parsing methods

bool RegexpPattern::isSpecialChar(char c) const throw()
{
	TRACE(RegexpPattern::isSpecialChar(char) const throw());

	return  c == '[' || c == ']' || c == '|' || c == '(' || c == ')' ||
		c == '{' || c == '}' || c == '*' || c == '+' || c == '^' ||
		c == '$' || c == '.' || c == '\\';
}

char RegexpPattern::getEscapeChar(const char *&src) const
{
	TRACE(RegexpPattern::getEscapeChar(const char *&) const);

	ASSERT(*src == '\\');

	src++;
	if(*src == 'n')
	{
		src++;
		return '\n';
	}
	else if(*src == 't')
	{
		src++;
		return '\t';
	}
	else if(isSpecialChar(*src))
	{
		return *src++;
	}
	else
	{
		throw RegexpParseException("Invalid escape character");
	}
}

// Match methods

bool RegexpPattern::match(string s, RegexpMatch &match) const
{
	TRACE(RegexpPattern::match(string, RegexpMatch &) const);

	MemoryIO mIO;
	unsigned long len = s.length();
	// By setting this to have a putback of s.length() we ensure there
	// will never be a putback buffer problem when matching against
	// strings.
	PutbackTextInput in(mIO, len);

	// Create the input stream data
	mIO.write(s.c_str(), len);

	try
	{
		return m_headBlock->m_next->doMatch(in, match, 0);
	}
	catch(Exception &e)
	{
		throw RegexpMatchException("Error during match: " + e.message());
	}
}

bool RegexpPattern::match(string pattern, string s, RegexpMatch &match)
{
	TRACE(RegexpPattern::match(string, string, RegexpMatch &));

	RegexpPattern myPattern(pattern);
	return myPattern.match(s, match);
}

bool RegexpPattern::match(PutbackTextInput &in, RegexpMatch &match) const
{
	TRACE(RegexpPattern::match(PutbackTextInput &, RegexpMatch &) const);

	try
	{
		return m_headBlock->m_next->doMatch(in, match, 0);
	}
	catch(Exception &e)
	{
		throw RegexpMatchException("Error during match: " + e.message());
	}
}

} // namespace lfc
