
#include <lfc.threads.thread>
#include <lfc.threads.guards>
#include <lfc.globals>
#include <lfc.exceptions>

namespace lfc
{

Mutex Thread::s_globalMutex;
Thread::CurrentThreadTLS Thread::s_currentThreadTLS;
list<Thread *> Thread::s_threadsList;


/*
\todo handle the situation when allocTLS fail
*/
Thread::CurrentThreadTLS::CurrentThreadTLS()
{
	pal::threads::allocTLS(key);
}


Thread::CurrentThreadTLS::~CurrentThreadTLS()
{
	pal::threads::freeTLS(key);
}


void Thread::CurrentThreadTLS::set(Thread *pThread)
{
	int retCode = pal::threads::setTLS(key, pThread);
	if(retCode)
		throw ThreadException(pal::threads::message(retCode));
}


Thread *Thread::CurrentThreadTLS::get() const
{
	void *value;
	int retCode = pal::threads::getTLS(key, value);
	if(retCode)
		throw ThreadException(pal::threads::message(retCode));
	return static_cast<Thread *>(value);
}



Thread::Thread() throw()
{
	m_handle = pal::threads::NULL_THREAD_HANDLE;
	m_state = stCreated;
	m_priority = priorityNormal;
	m_bCancel = false;
	m_exitCode = 0;
	m_bAutoDelete = false;
}


Thread::~Thread() throw()
{
	Guard guard(m_mutex);

	switch(m_state)
	{
	case stRunning:
		/*todo: ?*/;
        ASSERT(false);
        break;

	case stFinished:
		if(pal::threads::closeThread(m_handle))
			/*todo: ?*/;
		break;

	case stCreated:
	case stInvalid:
		break;

	case stInitializing:
	default:
		ASSERT(false);
	}
}


void Thread::start()
{
    TRACE(Thread::start());

	Guard guard(m_mutex);

	if(m_state != stCreated)
		throw ThreadException("invalid thread state");

	m_state = stInitializing;

	int retCode = pal::threads::createThread(m_handle, &startRoutine, this);
	if(retCode)
	{
		m_state = stInvalid;
		throw ThreadException(pal::threads::message(retCode));
	}
}


void Thread::destroy()
{
    TRACE(Thread::destroy());

	Guard guard1(m_mutex);
	Guard guard2(s_globalMutex);
	int retCode;

	// cases order is important!
	// (notice lack of 'break' statements)
	switch(m_state)
	{
	case stRunning:
		if(self() == this)
			throw ThreadException("threads can't self destroy");
		retCode = pal::threads::destroyThread(m_handle);
		if(retCode)
			throw ThreadException(pal::threads::message(retCode));
		s_threadsList.remove(this);

	case stFinished:
		retCode = pal::threads::closeThread(m_handle);
		if(retCode)
			throw ThreadException(pal::threads::message(retCode));
		// \todo? m_handle = pal::threads::NULL_THREAD_HANDLE;

	case stCreated:
		m_state = stInvalid;

	case stInvalid:
		break;

	case stInitializing:
	default:
		ASSERT(false);
	}
}


void Thread::cancel()
{
    TRACE(Thread::cancel());

	Guard guard(m_mutex);
	m_bCancel = true;
}


int Thread::join() const
{
    TRACE(Thread::join() const);

	Guard guard(m_mutex);
	int retCode;

	switch(m_state)
	{
	case stCreated:
	case stInvalid:
		throw ThreadException("invalid thread state");

	case stFinished:
		return m_exitCode;

	case stRunning:
	case stInitializing:
	    ASSERT(!pal::threads::isNullThreadHandle(m_handle));

		m_mutex.unlock();

		retCode = pal::threads::joinThread(m_handle);
		if(retCode)
			throw ThreadException(pal::threads::message(retCode));

		m_mutex.lock();
		if(m_state != stFinished)
			throw ThreadException("thread join failed");
		return m_exitCode;

	default:
		ASSERT(false);
		return 0;
	}
}


void Thread::setPriority(Priority priority)
{
    TRACE(Thread::setPriority(Priority));

	Guard guard(m_mutex);

	if(m_state != stRunning)
		throw ThreadException("invalid thread state");

	int retCode = pal::threads::setThreadPriority(m_handle, priority);
	if(retCode)
		throw ThreadException(pal::threads::message(retCode));

	m_priority = priority;
}


void Thread::setAutoDelete(bool bAutoDelete)
{
    TRACE(Thread::setAutoDelete(bool));

	Guard guard(m_mutex);
	m_bAutoDelete = bAutoDelete;
}


void Thread::yield()
{
    TRACE(Thread::yield());

	int retCode = pal::threads::yield();
	if(retCode)
		throw ThreadException(pal::threads::message(retCode));
}


void Thread::sleep(long miliseconds)
{
    TRACE(Thread::sleep(long));

	int retCode = pal::threads::sleep(miliseconds);
	if(retCode)
		throw ThreadException(pal::threads::message(retCode));
}


Thread *Thread::self()
{
    // alex: don't add TRACE here!

	// todo: handle error cases!
	return s_currentThreadTLS.get();
}


void Thread::exit(int exitCode)
{
    TRACE(Thread::exit(int));
	throw ThreadDeath(exitCode);
}


void Thread::testCancel(int exitCode)
{
    TRACE(Thread::testCancel(int));

	Guard guard(self()->m_mutex);

	if(self()->m_bCancel)
		Thread::exit(exitCode);
}


list<Thread *> Thread::threadsSnapshot()
{
    TRACE(Thread::threadsSnapshot());

	Guard guard(s_globalMutex);
	return s_threadsList;
}


void Thread::startRoutine(void *arg)
{
	Thread *pThis = static_cast<Thread *>(arg);
	ASSERT(pThis != NULL);

	// setup thread
	{
		Guard guard(s_globalMutex);
		s_currentThreadTLS.set(pThis);
		s_threadsList.push_back(pThis);
	}

	// mark the thread as running
	{
		Guard guard1(pThis->m_mutex);
    	pThis->m_state = stRunning;
	}

	// better design? (abort thread if exception?)
	try
	{
		pThis->sigInit();
	}
	catch(...)
	{
		Log(lfcLogger) << "\n[unhandled exception in thread init]\n";
	}

	// call thread main() method
	try
	{
		pThis->main();
	}
	catch(const ThreadDeath &e)
	{
		pThis->m_exitCode = e.exitCode;
	}
	catch(const Exception &e)
	{
		// ? or 'virtual unhandledException()'
		Log(lfcLogger) << "\nunhandled exception in thread \"" << pThis->name() << "\"\n";
		Log(lfcLogger) << formattedOut(e, "m") << ENDL;
	}
	catch(...)
	{
		// ? or 'virtual unhandledUnknownException()'
		Log(lfcLogger) << "\nunhandled exception in thread \"" << pThis->name() << "\"";
		Log(lfcLogger) << ": " << "unknown exception" << ENDL;
	}

	try
	{
		pThis->sigShutdown();
	}
	catch(...)
	{
		Log(lfcLogger) << "\n[unhandled exception in thread shutdown]\n";
	}

	// finish thread :-)
	{
		Guard guard1(pThis->m_mutex);
		Guard guard2(s_globalMutex);

		pThis->m_state = stFinished;
		s_threadsList.remove(pThis);
	}

	if(pThis->m_bAutoDelete)
		delete pThis;
}

}	// namespace lfc


