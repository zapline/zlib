
#include <lfc.streams.binaryStream>

namespace lfc
{

BinaryInput::BinaryInput()
{
}


BinaryInput::BinaryInput(_Input<char> &inputBase)
{
    connectInputBase(inputBase);
}


BinaryInput::~BinaryInput() throw()
{
}


BinaryInput &BinaryInput::operator>>(bool &value)
{
    TRACE(BinaryInput::operator>>(bool &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(Byte &value)
{
    TRACE(BinaryInput::operator>>(Byte &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(char &value)
{
    TRACE(BinaryInput::operator>>(char &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(short &value)
{
    TRACE(BinaryInput::operator>>(short &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(long &value)
{
    TRACE(BinaryInput::operator>>(long &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(Word &value)
{
    TRACE(BinaryInput::operator>>(Word &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(DWord &value)
{
    TRACE(BinaryInput::operator>>(DWord &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(float &value)
{
    TRACE(BinaryInput::operator>>(float &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(double &value)
{
    TRACE(BinaryInput::operator>>(double &value));

	//readClassID();
	readValue(value);
	return *this;
}


BinaryInput &BinaryInput::operator>>(_Serializable &obj)
{
    TRACE(BinaryInput::operator>>(_Serializable &obj));

	obj.readObject(*this);
	return *this;
}


RTTI::ID BinaryInput::readClassID()
{
    TRACE(BinaryInput::readClassID());

	RTTI::ID classID;
	readValue(classID);
	return classID;
}


long BinaryInput::readObjectID()
{
    TRACE(BinaryInput::readObjectID());

	long objectID;
	readValue(objectID);
	return objectID;
}

}	// namespace lfc


