
#include <lfc.streams.sockets>

namespace lfc
{

Socket::Socket() throw() :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    setName("Closed");
}


Socket::Socket(string host, Word port, SocketType type) :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    TRACE(Socket::Socket(string host, Word port, SocketType type));

    setName("Closed");
	connect(host, port, type);
}


Socket::Socket(string host, string service, SocketType type) :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    TRACE(Socket::Socket(string host, string service, SocketType type));

    setName("Closed");
	connect(host, service, type);
}


Socket::Socket(SocketServer &socketServer) :
	m_handle(pal::sockets::NULL_HANDLE), m_state(stClosed)
{
    TRACE(Socket::Socket(SocketServer &socketServer));

    setName("Closed");
	accept(socketServer);
}


Socket::~Socket() throw()
{
	try
	{
	    if(state() == stOpen)
    		close();
	}
	catch(SocketException &)
	{
		// ignore it...
	}
}


char Socket::pop()
{
    TRACE(Socket::pop());

	char value;
	read(&value, 1);
	return value;
}


bool Socket::hasMore() const
{
    TRACE(Socket::hasMore() const);

	// ?? there is any way to test
	// if there is data available?

	testState(stOpen);
	return true;
}


/*!
\todo support transfer flags
*/
long Socket::read(char *buffer, long count, bool bWaitAll)
{
    TRACE(Socket::read(char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long readCount;
			int retCode = pal::sockets::recv(m_handle, buffer, leftCount,
				0, readCount);
			if(retCode)
				throw SocketException(pal::sockets::message(retCode));
			buffer += readCount;
			leftCount -= readCount;
		}

		return count;
	}
	else
	{
		long readCount;
		int retCode = pal::sockets::recv(m_handle, buffer, count, 0, readCount);
		if(retCode)
			throw SocketException(pal::sockets::message(retCode));
		return readCount;
	}
}


void Socket::push(const char &value)
{
    TRACE(Socket::push(const char &value));

	write(&value, 1);
}


/*!
\todo support transfer flags
*/
long Socket::write(const char *buffer, long count, bool bWaitAll)
{
    TRACE(Socket::write(const char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long writeCount;
			int retCode = pal::sockets::send(m_handle, buffer, leftCount,
				0, writeCount);
			if(retCode)
				throw SocketException(pal::sockets::message(retCode));
			buffer += writeCount;
			leftCount -= writeCount;
		}

		return count;
	}
	else
	{
		long writeCount;
		int retCode = pal::sockets::send(m_handle, buffer, count, 0, writeCount);
		if(retCode)
			throw SocketException(pal::sockets::message(retCode));
		return writeCount;
	}
}


void Socket::connect(string host, Word port, SocketType type)
{
    TRACE(Socket::connect(string host, Word port, SocketType type));

	int retCode;

	testState(stClosed);

	// 1. create socket
	retCode = pal::sockets::open(m_handle, Socket::pfINET, type);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	// 2. connect
	retCode = pal::sockets::connect(m_handle, host.c_str(),
		Socket::pfINET, port);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));

	m_state = stOpen;
	sigInit();
}


void Socket::connect(string host, string service, SocketType type)
{
    TRACE(Socket::connect(string host, string service, SocketType type));

	Word port;
	int retCode = pal::sockets::getServicePort(service.c_str(), port);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
	connect(host, port, type);
}


void Socket::accept(SocketServer &socketServer)
{
    TRACE(Socket::accept(SocketServer &socketServer));

	testState(stClosed);
	m_handle = socketServer.accept();
	m_state = stOpen;
	sigInit();
}


void Socket::close()
{
    TRACE(Socket::close());

	if(m_state == stClosed)
		return;

	int retCode = pal::sockets::close(m_handle);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
	m_state = stClosed;
	m_handle = pal::sockets::NULL_HANDLE;
	sigShutdown();
}


/*!
\todo support transfer flags
*/
long Socket::readFrom(string &host, Word port,
	char *buffer, long count, bool bWaitAll)
{
    TRACE(Socket::readFrom(string &host, Word port, char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	char hostBuffer[64];

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long readCount;
			int retCode = pal::sockets::recvFrom(m_handle, buffer, leftCount,
				0, hostBuffer, Socket::pfINET, port, readCount);
			if(retCode)
				throw SocketException(pal::sockets::message(retCode));
			buffer += readCount;
			leftCount -= readCount;
		}

		host = hostBuffer;

		return count;
	}
	else
	{
		long readCount;
		int retCode = pal::sockets::recvFrom(m_handle, buffer, count,
			0, hostBuffer, Socket::pfINET, port, readCount);
		if(retCode)
			throw SocketException(pal::sockets::message(retCode));

		host = hostBuffer;
		return readCount;
	}
}


/*!
\todo support transfer flags
*/
long Socket::writeTo(string host, Word port,
	const char *buffer, long count, bool bWaitAll)
{
    TRACE(Socket::writeTo(string host, Word port, const char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long writeCount;
			int retCode = pal::sockets::sendTo(m_handle, buffer, leftCount,
				0, host.c_str(), Socket::pfINET, port, writeCount);
			if(retCode)
				throw SocketException(pal::sockets::message(retCode));
			buffer += writeCount;
			leftCount -= writeCount;
		}

		return count;
	}
	else
	{
		long writeCount;
		int retCode = pal::sockets::sendTo(m_handle, buffer, count,
			0, host.c_str(), Socket::pfINET, port, writeCount);
		if(retCode)
			throw SocketException(pal::sockets::message(retCode));
		return writeCount;
	}
}


void Socket::setBlocking(bool bBlocking)
{
    TRACE(Socket::setBlocking(bool bBlocking));

	testState(stOpen);

	int retCode = pal::sockets::setBlocking(m_handle, bBlocking);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
}


void Socket::flush()
{
    TRACE(Socket::flush());

	testState(stOpen);

	int retCode = pal::sockets::flush(m_handle);
	if(retCode)
		throw SocketException(pal::sockets::message(retCode));
}


}	// namespace lfc


