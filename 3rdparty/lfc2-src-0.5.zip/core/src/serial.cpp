
#include <lfc.streams.serial>

namespace lfc
{

SerialPort::SerialPort() throw() :
	m_handle(pal::serial::NULL_HANDLE), m_state(stClosed)
{
    setName("Closed");
}


SerialPort::SerialPort(string name) :
	m_handle(pal::serial::NULL_HANDLE), m_state(stClosed)
{
    TRACE(SerialPort::SerialPort(string name));

    setName("Closed");
	open(name);
}


/*!
close serial port if open
*/
SerialPort::~SerialPort() throw()
{
	try
	{
	    if(state() == stOpen)
		    close();
	}
	catch(SerialPortException &)
	{
		//$ ignore it...
	}
}


/*!
\return the char that was read from serial port
\sa read
*/
char SerialPort::pop()
{
    TRACE(SerialPort::pop());

	char retValue;

	read(&retValue, 1, true);
	return retValue;
}


/*!
purge input buffer content
*/
void SerialPort::resetInput()
{
    TRACE(SerialPort::resetInput());

	testState(stOpen);

	int retCode = pal::serial::purgeBuffer(m_handle, pal::serial::purgeInput);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\return allways true
*/
bool SerialPort::hasMore() const
{
    TRACE(SerialPort::hasMore() const);

	testState(stOpen);
	return true;
}


/*!
\param buffer will receive read bytes
\param count the requested number of bytes (might return less bytes if bWaitAll is false)
\parem bWaitAll if true will try to read exactly count bytes (or throw an exception if fail)
\return the number of bytes actually read
*/
long SerialPort::read(char *buffer, long count, bool bWaitAll)
{
    TRACE(SerialPort::read(char *buffer, long count, bool bWaitAll));

	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	testState(stOpen);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long readCount;
			int retCode = pal::serial::read(m_handle, buffer, leftCount, readCount);
			if(retCode)
				throw SerialPortException(pal::serial::message(retCode));
			buffer += readCount;
			leftCount -= readCount;
		}

		return count;
	}
	else
	{
		long readCount = 0;
		int retCode = pal::serial::read(m_handle, buffer, count, readCount);
		if(retCode)
			throw SerialPortException(pal::serial::message(retCode));
		return readCount;
	}
}


/*!
\param value the byte to be written
\sa write
*/
void SerialPort::push(const char &value)
{
    TRACE(SerialPort::push(const char &value));

	write(&value, 1);
}


/*!
purge output buffer contents
*/
void SerialPort::resetOutput()
{
    TRACE(SerialPort::resetOutput());

	testState(stOpen);

	int retCode = pal::serial::purgeBuffer(m_handle, pal::serial::purgeOutput);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\return allways true
*/
bool SerialPort::acceptMore() const
{
    TRACE(SerialPort::acceptMore() const);

	testState(stOpen);
	return true;
}


/*!
\param buffer with bytes to be written
\param count the requested number of bytes (might write fewer bytes if bWaitAll is false)
\parem bWaitAll if true will try to write exactly count bytes (or throw an exception if fail)
\return the number of bytes actually written
*/
long SerialPort::write(const char *buffer, long count, bool bWaitAll)
{
    TRACE(SerialPort::write(const char *buffer, long count, bool bWaitAll));

	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	testState(stOpen);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long writeCount;
			int retCode = pal::serial::write(m_handle, buffer, leftCount, writeCount);
			if(retCode)
				throw SerialPortException(pal::serial::message(retCode));
			buffer += writeCount;
			leftCount -= writeCount;
		}

		return count;
	}
	else
	{
		long writeCount;
		int retCode = pal::serial::write(m_handle, buffer, count, writeCount);
		if(retCode)
			throw SerialPortException(pal::serial::message(retCode));
		return writeCount;
	}
}


/*!
\param name serial port name (ex. "com1" under win32, "/dev/ttyS0" under Linux)
\note will save original port settings
*/
void SerialPort::open(string name)
{
    TRACE(SerialPort::open(string name));

	int retCode;

	testState(stClosed);

	// open port
	retCode = pal::serial::open(m_handle, name.c_str());
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));

	// save original settings
	retCode = pal::serial::saveSettings(m_handle, m_originalSettings);
	if(retCode)
	{
		pal::serial::close(m_handle);
		throw SerialPortException(pal::serial::message(retCode));
	}

	setName(name);
	m_state = stOpen;
	sigInit();
}


/*!
close serial port (if it's open, else do nothing)
\note will restore original port settings
*/
void SerialPort::close()
{
    TRACE(SerialPort::close());

	int retCode;

	if(m_state == stClosed)
		return;

	// restore settings
	pal::serial::restoreSettings(m_handle, m_originalSettings);

	// close
	retCode = pal::serial::close(m_handle);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));

	setName("Closed");
	m_state = stClosed;
	m_handle = pal::serial::NULL_HANDLE;
	sigShutdown();
}


long SerialPort::availableCount() const
{
    TRACE(SerialPort::availableCount() const);

	testState(stOpen);
	long count;
	int retCode = pal::serial::availableCount(m_handle, count);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
	return count;
}


/*!
\param settings describe port settings in the following format:
	<baud>,<B><P><S>
	where
	- baud is serial transmition speed
	- B is byte size (4..8)
	- P is parity (n-none, o-odd, e-even, s-space)
	- S is stop bits (1 or 2)
\note settings string is not case sensitive and it can't containt whitespaces
*/
void SerialPort::setup(string settings)
{
    TRACE(SerialPort::setup(string settings));

	testState(stOpen);

	int retCode = pal::serial::setup(m_handle, settings.c_str());
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\param bEnable if true enable hardware flow control, else disable
*/
void SerialPort::setHardwareFlowControl(bool bEnable)
{
    TRACE(SerialPort::setHardwareFlowControl(bool bEnable));

	testState(stOpen);

	int retCode = pal::serial::setHardwareFlowControl(m_handle, bEnable);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\param bEnable if true enable software flow control, else disable
\param Xon XON character
\param Xoff XOFF character
*/
void SerialPort::setSoftwareFlowControl(bool bEnable, char Xon, char Xoff)
{
    TRACE(SerialPort::setSoftwareFlowControl(bool bEnable, char Xon, char Xoff));

	testState(stOpen);

	int retCode = pal::serial::setSoftwareFlowControl(m_handle, bEnable, Xon, Xoff);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


void SerialPort::flush()
{
    TRACE(SerialPort::flush());

	testState(stOpen);

	int retCode = pal::serial::flush(m_handle);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\param timeout time (in ms) to wait until a char is received
*/
void SerialPort::setReadTimeout(long timeout)
{
    TRACE(SerialPort::setReadTimeout(long timeout));

	testState(stOpen);

	int retCode = pal::serial::setReadTimeouts(m_handle, timeout);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


void SerialPort::setBlockingRead(bool bBlocking)
{
    TRACE(SerialPort::setBlockingRead(bool bBlocking));

	testState(stOpen);

	int retCode = pal::serial::setBlockingRead(m_handle, bBlocking);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


void SerialPort::sendBreak()
{
    TRACE(SerialPort::sendBreak());

	testState(stOpen);

	int retCode = pal::serial::sendBreak(m_handle);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


/*!
\return modem status bits, as a bitwise combination of the following:
	- mstatusCTS - clear to send
	- mstatusDSR - data set ready
	- mstatusRNG - ring
	- mstatusDCD - data carrier detect
*/
DWord SerialPort::modemStatus() const
{
    TRACE(SerialPort::modemStatus() const);

	testState(stOpen);

	int status;
	int retCode = pal::serial::getModemStatus(m_handle, status);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
	return status;
}


void SerialPort::setDTR(bool bEnable)
{
    TRACE(SerialPort::setDTR(bool bEnable));

	testState(stOpen);

	int retCode = pal::serial::setDTR(m_handle, bEnable);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


void SerialPort::setRTS(bool bEnable)
{
    TRACE(SerialPort::setRTS(bool bEnable));

	testState(stOpen);

	int retCode = pal::serial::setRTS(m_handle, bEnable);
	if(retCode)
		throw SerialPortException(pal::serial::message(retCode));
}


}	// namespace lfc


