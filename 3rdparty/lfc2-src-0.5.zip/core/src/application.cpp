
#include <lfc.exceptions>
#include <lfc.threads.application>
#include <lfc.threads.guards>
#include <lfc.globals>

#include <PAL.console>
#include <PAL.debug>
#include <PAL.files>
#include <PAL.sockets>
#include <PAL.threads>


namespace lfc
{

Application *Application::s_pInstance = NULL;


Application::Application()
{
	//? a better checking (and message)
	ASSERT(s_pInstance == NULL);

	s_pInstance = this;
}


Application::~Application() throw()
{
}


int Application::run(int argc, char *argv[])
{
	//? a better checking (and message)
	ASSERT(s_pInstance != NULL);
	ASSERT(s_pInstance->m_state == stCreated);

	// init arguments list
	for(int i = 0; i < argc; ++i)
		s_pInstance->m_arguments.push_back(argv[i]);

	// setup thread state
	//! there must be a better way
	{
		Guard guard(Thread::s_globalMutex);

		int retCode = pal::threads::getCurrentThread(s_pInstance->m_handle);
		if(retCode)
			throw ApplicationException(pal::threads::message(retCode));

		s_pInstance->setName("MainThread");
	}

	// connect this to perform first time initialization
	//
	s_pInstance->sigInit.connect(callback(&Application::firstTimeInit));

	// connect this to perform final cleanup
	//
	s_pInstance->sigShutdown.connect(callback(&Application::finalCleanup));

	startRoutine(s_pInstance);
	return s_pInstance->m_exitCode;
}


void Application::firstTimeInit()
{
    // connect lfcLogger to lfcDebugOutput
    //
    // alex: this should always succed, and must be
    //   done first, so we can log if something wrong happen
    //
    lfcLogger.connectOutputBase(lfcDebugOutput);

    // reset lfcLogger panic mode, so we'll get
    // normal stream behavior
    //
    lfcLogger.setPanicMode(false);

    // connect lfcOut to lfcConsole
    //
    lfcOut.connectOutputBase(lfcConsole);
}


void Application::finalCleanup()
{
    // disconect all output bases for
    // global streams objects
    //
    lfcOut.disconnectOutputBase();
    lfcLogger.disconnectOutputBase();

    // put lfcLogger in panic mode, so we'll get
    // any more messages to stderr
    //
    lfcLogger.setPanicMode(true);
}


//////////////////////////////////////////////////////////////////////
//
// lfcMain()
//

/*
\brief LFC2 entry point
\todo check PALs init/cleanup return values
*/
int lfcMain(int argc, char *argv[])
{
	pal::debug::init();
	pal::console::init();
	pal::files::init();
	pal::sockets::init();
	pal::threads::init();

	int retCode = Application::run(argc, argv);

	pal::threads::cleanup();
	pal::sockets::cleanup();
	pal::files::cleanup();
	pal::console::cleanup();
	pal::debug::cleanup();

	return retCode;
}

}	// namespace lfc


//! standard entry point
int main(int argc, char *argv[])
{
	try
	{
        return lfc::lfcMain(argc, argv);
    }
	catch(const lfc::Exception &e)
	{
	    lfc::Application::abort("\nunhandled LFC exception outside Application lifetime!");
	}
	catch(...)
	{
	    lfc::Application::abort("\nunhandled unknown exception outside Application lifetime!");
	}

	return -1;
}


