
#include <lfc.streams.file>

namespace lfc
{

File::File() throw() :
	m_handle(pal::files::NULL_HANDLE), m_state(stClosed)
{
    setName("Closed");
}


File::File(string filename, int flags, int shareFlags) :
	m_handle(pal::files::NULL_HANDLE), m_state(stClosed)
{
    TRACE(File::File(string filename, int flags, int shareFlags));

    setName("Closed");
	open(filename, flags, shareFlags);
}


File::~File() throw()
{
	try
	{
    	if(m_state != stClosed)
		    close();
	}
	catch(FileException &)
	{
		// ignore it...
	}
}


char File::pop()
{
    TRACE(File::pop());

	char retValue;

	read(&retValue, 1, true);
	return retValue;
}


void File::resetInput()
{
    TRACE(File::resetInput());

	seek(0);
}


bool File::hasMore() const
{
    TRACE(File::hasMore() const);

	return position() < size();
}


long File::read(char *buffer, long count, bool bWaitAll)
{
    TRACE(File::read(char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long readCount;
			int retCode = pal::files::read(m_handle, buffer, leftCount, readCount);
			if(retCode)
				throw FileException(pal::files::message(retCode));
			buffer += readCount;
			leftCount -= readCount;
		}

		return count;
	}
	else
	{
		long readCount = 0;
		int retCode = pal::files::read(m_handle, buffer, count, readCount);
		if(retCode)
			throw FileException(pal::files::message(retCode));
		return readCount;
	}
}


void File::push(const char &value)
{
    TRACE(File::push(const char &value));

	write(&value, 1);
}


void File::resetOutput()
{
    TRACE(File::resetOutput());

	seek(0);
}


bool File::acceptMore() const
{
	return true;
}


long File::write(const char *buffer, long count, bool bWaitAll)
{
    TRACE(File::write(const char *buffer, long count, bool bWaitAll));

	testState(stOpen);
	ASSERT(buffer != NULL);
	ASSERT(count >= 0);

	if(bWaitAll)
	{
		for(long leftCount = count; leftCount > 0;)
		{
			long writeCount;
			int retCode = pal::files::write(m_handle, buffer, leftCount, writeCount);
			if(retCode)
				throw FileException(pal::files::message(retCode));
			buffer += writeCount;
			leftCount -= writeCount;
		}

		return count;
	}
	else
	{
		long writeCount;
		int retCode = pal::files::write(m_handle, buffer, count, writeCount);
		if(retCode)
			throw FileException(pal::files::message(retCode));
		return writeCount;
	}
}


void File::open(string filename, int flags, int shareFlags)
{
    TRACE(File::open(string filename, int flags, int shareFlags));

	testState(stClosed);
	int retCode = pal::files::open(m_handle, filename.c_str(), flags, shareFlags);
	if(retCode)
		throw FileException(pal::files::message(retCode));
	setName(filename);
	m_state = stOpen;
	sigInit();
}


void File::close()
{
    TRACE(File::close());

	if(m_state == stClosed)
		return;
	int retCode = pal::files::close(m_handle);
	if(retCode)
		throw FileException(pal::files::message(retCode));
	setName("Closed");
	m_state = stClosed;
	m_handle = pal::files::NULL_HANDLE;
	sigShutdown();
}


long File::seek(long offset, SeekMode mode)
{
    TRACE(File::seek(long offset, SeekMode mode));

	testState(stOpen);
	long newPosition;
	int retCode = pal::files::seek(m_handle, offset, mode, newPosition);
	if(retCode)
		throw FileException(pal::files::message(retCode));
	return newPosition;
}


long File::position() const
{
    TRACE(File::position() const);

	testState(stOpen);
	long newPosition;
	int retCode = pal::files::seek(m_handle, 0, File::seekCurrent, newPosition);
	if(retCode)
		throw FileException(pal::files::message(retCode));
	return newPosition;
}


long File::size() const
{
    TRACE(File::size() const);

	testState(stOpen);
	long oldPosition = position();
	long endPosition;
	int retCode = pal::files::seek(m_handle, 0, File::seekEnd, endPosition);
	if(retCode)
	{
		pal::files::seek(m_handle, oldPosition, File::seekSet, oldPosition);
		throw FileException(pal::files::message(retCode));
	}
	pal::files::seek(m_handle, oldPosition, File::seekSet, oldPosition);
	return endPosition;
}


void File::setEof(long offset)
{
    TRACE(File::setEof(long offset));

	testState(stOpen);
	if(offset != -1)
		seek(offset);
	int retCode = pal::files::setEof(m_handle);
	if(retCode)
		throw FileException(pal::files::message(retCode));
}


void File::flush()
{
    TRACE(File::flush());

	testState(stOpen);
	int retCode = pal::files::flush(m_handle);
	if(retCode)
		throw FileException(pal::files::message(retCode));
}


}	// namespace lfc


