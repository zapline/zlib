
#include <PAL.threads>

namespace lfc
{
namespace win32PAL
{
namespace threads
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"win32PAL::threads -- No error (ok)",
	"win32PAL::threads -- Generic error",
};

/*!
\note new/delete must be thread safe
*/
DWORD WINAPI __threadProc(void *p)
{
	__StartThreadInfo *pInfo = static_cast<__StartThreadInfo *>(p);
	void (*proc)(void *) = pInfo->proc;
	void *pData = pInfo->pData;
	delete pInfo;
	(*proc)(pData);
	return 0;
}


} // namespace win32PAL::threads
} // namespace win32PAL
} // namespace lfc


