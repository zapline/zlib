
#include <PAL.sockets>

namespace lfc
{
namespace win32PAL
{
namespace sockets
{

const char *messagesTable[MAX_ERROR_CODE+1] =
{
	"win32PAL::sockets -- No error (ok)",
	"win32PAL::sockets -- Generic socket error",
	"win32PAL::sockets -- Environment not initialized",
	"win32PAL::sockets -- Connection has been closed",
	"win32PAL::sockets -- Unbound socket",
	"win32PAL::sockets -- Socket should be listening",
	"win32PAL::sockets -- Invalid hostname/IP address",
};


} // namespace win32PAL::sockets
} // namespace win32PAL
} // namespace lfc


