
#include <PAL.debug>

namespace lfc
{
namespace win32PAL
{
namespace debug
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"win32PAL::debug -- No error (ok)",
};


} // namespace win32PAL::debug
} // namespace win32PAL
} // namespace lfc


