
#include <PAL.files>

namespace lfc
{
namespace win32PAL
{
namespace files
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"win32PAL::files -- No error (ok)",
	"win32PAL::files -- Generic error",
	"win32PAL::files -- Not supported",
	"win32PAL::files -- Already exists",
	"win32PAL::files -- Can't truncate",
};


} // namespace win32PAL::files
} // namespace win32PAL
} // namespace lfc


