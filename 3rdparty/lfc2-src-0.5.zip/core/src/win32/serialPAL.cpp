
#include <PAL.serial>

namespace lfc
{
namespace win32PAL
{
namespace serial
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"win32PAL::serial -- No error (ok)",
	"win32PAL::serial -- Generic error",
	"win32PAL::serial -- Not supported",
};


} // namespace win32PAL::serial
} // namespace win32PAL
} // namespace lfc


