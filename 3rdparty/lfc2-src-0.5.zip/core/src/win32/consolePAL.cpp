
#include <PAL.console>

namespace lfc
{
namespace win32PAL
{
namespace console
{

const char *messagesTable[MAX_ERROR_CODE + 1] =
{
	"win32PAL::console -- No error (ok)",
};


} // namespace win32PAL::console
} // namespace win32PAL
} // namespace lfc


