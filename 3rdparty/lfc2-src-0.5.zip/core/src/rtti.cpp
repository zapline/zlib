
#include <lfc.rtti>

namespace lfc
{

vector<RTTI::ClassInfo> RTTI::s_registeredClasses;


string RTTI::className(ID id)
{
    TRACE(RTTI::className(ID id));

	for(size_t i = 0; i < s_registeredClasses.size(); ++i)
		if(s_registeredClasses[i].id == id)
			return s_registeredClasses[i].name;

	throw RTTIException("class not found");
}


string RTTI::className(const Object &obj)
{
    TRACE(RTTI::className(const Object &obj));

	for(size_t i = 0; i < s_registeredClasses.size(); ++i)
		if(*s_registeredClasses[i].pTypeInfo == typeid(obj))
			return s_registeredClasses[i].name;

	throw RTTIException("class not found");
}


RTTI::ID RTTI::classID(string className)
{
    TRACE(RTTI::classID(string className));

	for(size_t i = 0; i < s_registeredClasses.size(); ++i)
		if(s_registeredClasses[i].name == className)
			return s_registeredClasses[i].id;

	throw RTTIException("class not found");
}


RTTI::ID RTTI::classID(const Object &obj)
{
    TRACE(RTTI::classID(const Object &obj));

	for(size_t i = 0; i < s_registeredClasses.size(); ++i)
		if(*s_registeredClasses[i].pTypeInfo == typeid(obj))
			return s_registeredClasses[i].id;

	throw RTTIException("class not found");
}

}	// namespace lfc


