
#ifndef __DEBUG_WIN32_PAL_HPP__
#define __DEBUG_WIN32_PAL_HPP__

#include <stdio.h>
#include <assert.h>

namespace lfc
{
namespace win32PAL
{

//! win32 debug PAL
/*!
\todo need testing
*/
namespace debug
{

const int MAX_ERROR_CODE = 0;

enum ErrorCodes
{
	errOk,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! init debug PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}

//! cleanup debug PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}

//! send a character to debug output (stderr right now)
/*!
\param value character code
\return error code (0 means no error)
*/
inline int putChar(int value)
{
	putc(value, stderr);
	return errOk;
}

//! flush console output buffer
/*!
\return error code (0 means no error)
*/
inline int flush()
{
	fflush(stderr);
	return errOk;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace win32PAL::debug
} // namespace win32PAL

namespace pal = win32PAL;

} // namespace lfc


#endif	// __DEBUG_WIN32_PAL_HPP__
