
#ifndef __THREADS_WIN32_PAL_HPP__
#define __THREADS_WIN32_PAL_HPP__

#include <limits.h>
#include <assert.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


namespace lfc
{
namespace win32PAL
{

//! win32 threads PAL
/*!
\todo need testing
\todo more detailed return codes
\bug win32api doc states that we should use beginthread instread of CreateThread
	if we use CRT libs
*/
namespace threads
{

const int MAX_ERROR_CODE = 1;

enum ErrorCodes
{
	errOk,
	errGeneric,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! starting point for win32 threads
DWORD WINAPI __threadProc(void *);

//! used to pass __threadProc needed information
struct __StartThreadInfo
{
	void (*proc)(void *);
	void *pData;
};


//! Win32 thread handle type
typedef ::HANDLE ThreadHandle;
//! a handle value designating an invalid thread handle
const ThreadHandle NULL_THREAD_HANDLE = NULL;

//! Win32 mutex handle type
typedef ::HANDLE MutexHandle;
//! a handle value designating an invalid mutex handle
const MutexHandle NULL_MUTEX_HANDLE = NULL;

//! Win32 semaphore handle type
typedef ::HANDLE SemHandle;
//! a handle value designating an invalid semaphore handle
const SemHandle NULL_SEM_HANDLE = NULL;

//! Win32 TLS key type
typedef DWORD TLSKey;


//! thread priority
const int
	priorityMin		= THREAD_PRIORITY_LOWEST,
	priorityNormal	= THREAD_PRIORITY_NORMAL,
	priorityMax		= THREAD_PRIORITY_HIGHEST;


//! init threads PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup threads PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullThreadHandle(const ThreadHandle &handle)
{
    return handle == NULL_THREAD_HANDLE;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullMutexHandle(const MutexHandle &handle)
{
    return handle == NULL_MUTEX_HANDLE;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullSemHandle(const SemHandle &handle)
{
    return handle == NULL_SEM_HANDLE;
}


//! create a new thread
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\param proc address of thread starting function
\param pData application defined value (passed to proc)
\return error code (0 means no error)
\note passing address of an __StartThreadInfo may not be the best solution.
	Any sugestions?
*/
inline int createThread(ThreadHandle &handle, void (*proc)(void *), void *pData)
{
	DWORD threadId;

	__StartThreadInfo *pInfo = new __StartThreadInfo;
	pInfo->proc = proc;
	pInfo->pData = pData;

	ThreadHandle h = ::CreateThread(NULL, 0, &__threadProc, pInfo, 0,
		&threadId);
	if(h != NULL)
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! close a thread handle
/*!
\param handle thread handle
\return error code (0 means no error)
*/
inline int closeThread(ThreadHandle &handle)
{
	return ::CloseHandle(handle) ? errOk : errGeneric;
}


//! get current thread handle
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\return error code (0 means no error)
\note the handle returned is not a pseudohandle, and must be closed
	when no longer used. There is no guarantee that this handle is the same
	with that returned when thread was created.
*/
inline int getCurrentThread(ThreadHandle &handle)
{
	ThreadHandle pseudoHandle = ::GetCurrentThread();
	ThreadHandle h;

	if(::DuplicateHandle(::GetCurrentProcess(), pseudoHandle,
		::GetCurrentProcess(), &h, 0, false, DUPLICATE_SAME_ACCESS))
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! destory a thread (terminate async)
/*!
\param handle thread handle
\return error code (0 means no error)
*/
inline int destroyThread(const ThreadHandle &handle)
{
	return ::TerminateThread(handle, 0) ? errOk : errGeneric;
}


//! wait for a thread to terminate
/*!
\param handle thread handle
\return error code (0 means no error)
*/
inline int joinThread(const ThreadHandle &handle)
{
	if(::WaitForSingleObject(handle, INFINITE) != WAIT_FAILED)
		return errOk;
	else
		return errGeneric;
}


//! set thread priority
/*!
\param handle thread handle
\param priority new thread priority
\return error code (0 means no error)
*/
inline int setThreadPriority(const ThreadHandle &handle, int priority)
{
	return ::SetThreadPriority(handle, priority) ? errOk : errGeneric;
}


//! yield
/*!
\return error code (0 means no error)
*/
inline int yield()
{
	::Sleep(0);
	return errOk;
}


//! suspends execution for a specified interval
/*!
\param miliseconds the interval duration
\return error code (0 means no error)
*/
inline int sleep(long miliseconds)
{
	::Sleep(miliseconds);
	return errOk;
}


//! alloc new TLS
/*!
\param key will contain the new key
\return error code (0 means no error)
*/
inline int allocTLS(TLSKey &key)
{
	TLSKey k = ::TlsAlloc();
	if(k != 0xFFFFFFFF)
	{
		key = k;
		return errOk;
	}
	else
		return errGeneric;
}


//! free TLS
/*!
\param key TLS key
\return error code (0 means no error)
\note TLS are freed at the process termination
*/
inline int freeTLS(TLSKey key)
{
	return ::TlsFree(key) ? errOk : errGeneric;
}


//! set TLS
/*!
\param key TLS key
\param value the value
\return error code (0 means no error)
*/
inline int setTLS(TLSKey key, void *value)
{
	return ::TlsSetValue(key, value) ? errOk : errGeneric;
}


//! get TLS
/*!
\param key TLS key
\param value will contain the value
\return error code (0 means no error)
*/
inline int getTLS(TLSKey key, void *&value)
{
	void *v = ::TlsGetValue(key);
	if(::GetLastError() == NO_ERROR)
	{
		value = v;
		return errOk;
	}
	else
		return errGeneric;
}


//! create a new mutex object
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\return error code (0 means no error)
*/
inline int createMutex(MutexHandle &handle)
{
	MutexHandle h = ::CreateMutex(NULL, false, NULL);
	if(h != NULL)
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! close a mutex
/*!
\param handle indicate mutex to be closed
\return error code (0 means no error)
*/
inline int closeMutex(MutexHandle &handle)
{
	return ::CloseHandle(handle) ? errOk : errGeneric;
}


//! lock a mutex
/*!
\param handle indicate mutex
\return error code (0 means no error)
\note recursive locks ok
*/
inline int lockMutex(MutexHandle &handle)
{
	if( ::WaitForSingleObject(handle, INFINITE) != WAIT_FAILED)
		return errOk;
	else
		return errGeneric;
}

//! lock a mutex
/*!
\param handle indicate mutex
\param bLocked return true if lock succeded
\return error code (0 means no error)
\note recursive locks ok
*/
inline int tryLockMutex(MutexHandle &handle, bool &bLocked)
{
	DWORD retCode = ::WaitForSingleObject(handle, 0);

	if(retCode != WAIT_FAILED)
	{
		bLocked = (retCode != WAIT_TIMEOUT);
		return errOk;
	}
	else
		return errGeneric;
}

//! unlock a mutex
/*!
\param handle indicate mutex
\return error code (0 means no error)
*/
inline int unlockMutex(MutexHandle &handle)
{
	return ::ReleaseMutex(handle) ? errOk : errGeneric;
}


//! create a new semaphore object
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\param count initial semaphore value
\return error code (0 means no error)
*/
inline int createSemaphore(SemHandle &handle, long count)
{
	SemHandle h = ::CreateSemaphore(NULL, count, LONG_MAX, NULL);
	if(h != NULL)
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! close a semaphore
/*!
\param handle indicate semaphore to be closed
\return error code (0 means no error)
*/
inline int closeSemaphore(SemHandle &handle)
{
	return ::CloseHandle(handle) ? errOk : errGeneric;
}


//! wait a semaphore (lock)
/*!
\param handle indicate semaphore
\return error code (0 means no error)
*/
inline int waitSemaphore(SemHandle &handle)
{
	DWORD retCode = ::WaitForSingleObject(handle, INFINITE);

	if(retCode != WAIT_FAILED)
		return errOk;
	else
		return errGeneric;
}

//! try to wait a semaphore w/o blocking (lock)
/*!
\param handle indicate semaphore
\param bLocked return true if lock succeded
\return error code (0 means no error)
*/
inline int tryWaitSemaphore(SemHandle &handle, bool &bLocked)
{
	DWORD retCode = ::WaitForSingleObject(handle, 0 );

	if(retCode != WAIT_FAILED)
	{
		bLocked = (retCode != WAIT_TIMEOUT);
		return errOk;
	}
	else
		return errGeneric;
}

//! post a semaphore (unlock)
/*!
\param handle indicate semaphore
\return error code (0 means no error)
*/
inline int postSemaphore(SemHandle &handle)
{
	return ::ReleaseSemaphore(handle, 1, NULL) ? errOk : errGeneric;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace win32PAL::threads
} // namespace win32PAL

namespace pal = win32PAL;

} // namespace lfc


#endif	// __THREADS_WIN32_PAL_HPP__
