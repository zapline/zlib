
#ifndef __FILES_WIN32_PAL_HPP__
#define __FILES_WIN32_PAL_HPP__

#include <assert.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


namespace lfc
{
namespace win32PAL
{

//! win32 files PAL
/*!
\todo lock, unlock file
\todo need testing
*/
namespace files
{

const int MAX_ERROR_CODE = 4;

enum ErrorCodes
{
	errOk,
	errGeneric,
	errNotSupported,
	errAlreadyExists,
	errCantTruncate,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! Win32 file handle type
typedef ::HANDLE Handle;

//! a handle value designating an invalid handle
const Handle NULL_HANDLE = INVALID_HANDLE_VALUE;

//! seek mode
const int
	seekSet			= 0x0001,
	seekCurrent		= 0x0002,
	seekEnd			= 0x0004;

//! open mode
const int
	flAppend		= 0x0001,
	flRead			= 0x0002,
	flWrite			= 0x0004,
	flTruncate		= 0x0008,
	flOpenExisting	= 0x0010,
	flCreateNew		= 0x0020,
	flTemp			= 0x0040,
	flWriteThrough  = 0x0080;

//! share mode
const int
	shRead		    = 0x0001,
	shWrite		    = 0x0002;


// forward declarations
inline int close(Handle handle);
inline int seek(Handle handle, long offset, int mode, long &pos);
inline int setEof(Handle handle);


//! init files PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup files PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullHandle(const Handle &handle)
{
    return handle == NULL_HANDLE;
}


//! open/create a file
/*!
\param handle will contain the handle if the operation succed, no modification otherwhise
\param name file name
\param flags open mode, see File::OpenMode
\param shareFlags sharing, see File::ShareMode
\return error code (0 means no error)
\bug flApplend is not implemented
*/
inline int open(Handle &handle, const char *name, int flags, int shareFlags)
{
	DWORD dwAccess = 0;
	dwAccess |= (flags & flRead ? GENERIC_READ : 0);
	dwAccess |= (flags & flWrite ? GENERIC_WRITE : 0);

	DWORD dwShare = 0;
	dwShare |= (shareFlags & shRead ? FILE_SHARE_READ : 0);
	dwShare |= (shareFlags & shWrite ? FILE_SHARE_WRITE : 0);

	DWORD dwCreation = 0;
	if(flags & flOpenExisting)
		dwCreation = OPEN_EXISTING;
	else if(flags & flCreateNew)
		dwCreation = CREATE_NEW;
	else if(flags & flTruncate)
		dwCreation = CREATE_ALWAYS;
	else
		dwCreation = OPEN_ALWAYS;

	DWORD dwFlagsAndAttrs = FILE_ATTRIBUTE_NORMAL;
	dwFlagsAndAttrs |= (flags & flTemp ? FILE_FLAG_DELETE_ON_CLOSE : 0);
	dwFlagsAndAttrs |= (flags & flWriteThrough ? FILE_FLAG_WRITE_THROUGH : 0);

	::SetLastError(NO_ERROR);
	HANDLE h = ::CreateFile(name, dwAccess, dwShare, NULL, dwCreation,
		FILE_ATTRIBUTE_NORMAL, NULL);

	if(h != INVALID_HANDLE_VALUE)
	{
		handle = h;
		return errOk;
	}
	else
		switch(::GetLastError())
		{
		case ERROR_NOT_SUPPORTED:
			return errNotSupported;

		case ERROR_ALREADY_EXISTS:
			return errAlreadyExists;

		default:
			return errGeneric;
		}
}

//! close a file
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/
inline int close(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::CloseHandle(handle) ? errOk : errGeneric;
}

//! moves the file pointer of an open file
/*!
\param handle a valid file handle
\param offset offset to move file pointer (see SeekMode)
\param mode indicate relative moving base
\param pos return new position
\return error code (0 means no error)
*/
inline int seek(Handle handle, long offset, int mode, long &pos)
{
	DWORD dwMode = 0;
	switch(mode)
	{
	case seekSet: dwMode = FILE_BEGIN; break;
	case seekCurrent: dwMode = FILE_CURRENT; break;
	case seekEnd: dwMode = FILE_END; break;
	default:
		assert(false);
	}

	::SetLastError(NO_ERROR);
	long newPos = ::SetFilePointer(handle, offset, NULL, dwMode);

	if(::GetLastError() == NO_ERROR)
	{
		pos = newPos;
		return errOk;
	}
	else
		return errGeneric;
}

//! set EOF to current position
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/
inline int setEof(Handle handle)
{
	return ::SetEndOfFile(handle) ? errOk : errGeneric;
}

//! write data to a file
/*!
\param handle a valid file handle
\param buff pointer to the data to be written
\param count number of bytes to write
\param written return the actual number of bytes written
\return error code (0 means no error)
*/
inline int write(Handle handle, const void *buff, long count, long &written)
{
	DWORD dwCount = static_cast<DWORD>(count);
	DWORD dwWritten = 0;

	if(::WriteFile(handle, buff, dwCount, &dwWritten, NULL))
	{
		written = static_cast<long>(dwWritten);
		return errOk;
	}
	else
		return errGeneric;
}

//! read data from a file
/*!
\param handle a valid file handle
\param buff pointer to the buffer that will receive the data
\param count number of bytes to read
\param written return the actual number of bytes read
\return error code (0 means no error)
*/
inline int read(Handle handle, void *buff, long count, long &read)
{
	DWORD dwCount = static_cast<DWORD>(count);
	DWORD dwRead = 0;

	if(::ReadFile(handle, buff, dwCount, &dwRead, NULL))
	{
		read = static_cast<long>(dwRead);
		return errOk;
	}
	else
		return errGeneric;
}


//! flush file buffers
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/
inline int flush(Handle handle)
{
	return ::FlushFileBuffers(handle) ? errOk : errGeneric;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace win32PAL::files
} // namespace win32PAL

namespace pal = win32PAL;

} // namespace lfc


#endif	// __FILES_WIN32_PAL_HPP__
