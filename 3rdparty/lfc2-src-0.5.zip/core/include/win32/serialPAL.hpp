
#ifndef __SERIAL_WIN32_PAL_HPP__
#define __SERIAL_WIN32_PAL_HPP__

#include <assert.h>
#include <ctype.h>
#include <stdio.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


namespace lfc
{
namespace win32PAL
{

//! win32 serial communications PAL
/*!
\todo more datalied error codes
\todo need testing
*/
namespace serial
{

const int MAX_ERROR_CODE = 2;

enum ErrorCodes
{
	errOk,
	errGeneric,
	errNotSupported,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! Win32 serial port handle type
typedef ::HANDLE Handle;

//! a handle value designating an invalid handle
const Handle NULL_HANDLE = INVALID_HANDLE_VALUE;


//! contain port settings to save/restore
struct PortSettings
{
	DCB dcb;
	COMMTIMEOUTS commTimeouts;
};


//! purge buffer flags
const int
	purgeInput		= 0x0001,
	purgeOutput		= 0x0002;

//! modem status flags
const int
	mstatusDSR		= 0x0001,
	mstatusDTR		= 0x0002,//$ not supported!
	mstatusRTS		= 0x0004,//$ not supported!
	mstatusCTS		= 0x0008,
	mstatusDCD		= 0x0010,
	mstatusRNG		= 0x0020;


//! init PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullHandle(const Handle &handle)
{
    return handle == NULL_HANDLE;
}


//! open serial port
/*!
\param handle will contain the handle if the operation succed, no modification otherwhise
\param name comm device name (ex. "com1" under win32, "/dev/ttyS0" under Linux)
\return error code (0 means no error)
*/
inline int open(Handle &handle, const char *name)
{
	assert(handle == NULL_HANDLE);

	HANDLE h = ::CreateFile(name, GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(h != INVALID_HANDLE_VALUE)
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! close a serial port
/*!
\param handle a valid serial port handle
\return error code (0 means no error)
*/
inline int close(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::CloseHandle(handle) ? errOk : errGeneric;
}


//! write data to a serial device
/*!
\param handle a valid handle
\param buff pointer to the data to be written
\param count number of bytes to write
\param written return the actual number of bytes written
\return error code (0 means no error)
*/
inline int write(Handle handle, const void *buff, long count, long &writtenCount)
{
	assert(handle != NULL_HANDLE);

	DWORD dwCount = static_cast<DWORD>(count);
	DWORD dwWritten = 0;

	if(::WriteFile(handle, buff, dwCount, &dwWritten, NULL))
	{
		writtenCount = static_cast<long>(dwWritten);
		return errOk;
	}
	else
		return errGeneric;
}

//! read data from a serial device
/*!
\param handle a valid handle
\param buff pointer to the buffer that will receive the data
\param count number of bytes to read
\param written return the actual number of bytes read
\return error code (0 means no error)
*/
inline int read(Handle handle, void *buff, long count, long &readCount)
{
	assert(handle != NULL_HANDLE);

	DWORD dwCount = static_cast<DWORD>(count);
	DWORD dwRead = 0;

	if(::ReadFile(handle, buff, dwCount, &dwRead, NULL))
	{
		readCount = static_cast<long>(dwRead);
		return errOk;
	}
	else
		return errGeneric;
}


//! flush output buffer
/*!
\param handle a valid handle
\return error code (0 means no error)
*/
inline int flush(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::FlushFileBuffers(handle) ? errOk : errGeneric;
}


//! set port settings (baud rate, parity, ...)
/*!
\param handle a valid handle
\param portSettings describe port settings in the following format:
	<baud>,<B><P><S>
	where
	- baud is serial transmition speed
	- B is byte size (5..8)
	- P is parity (n-none, o-odd, e-even, s-space)
	- S is stop bits (1 or 2)
\note settings string is not case sensitive and it can't containt whitespaces
\return error code (0 means no error)
*/
inline int setup(Handle handle, const char *portSettings)
{
	assert(handle != NULL_HANDLE);
	assert(portSettings != NULL);

	const char *p = portSettings;
	long baud = 0;
	long byteSize = 0;
	long stopBits = 0;
	char parity = '#';

	// parse settings
	while( isdigit(*p) )
		baud = baud * 10 + *p++ - '0';
	if(*p++ != ',')
		return errGeneric;
	byteSize = *p++ - '0';
	if(byteSize < 5 || byteSize > 8)
		return errGeneric;
	parity = toupper(*p++);
	if(::strchr("NOES", parity) == NULL)
		return errGeneric;
	stopBits = *p++ - '0';
	if(stopBits != 1 && stopBits != 2)
		return errGeneric;
	if(*p != 0)
		return errGeneric;

	// setup DCB
	char buff[1024];
	::sprintf(buff, "%ld,%c,%ld,%ld", baud, parity, byteSize, stopBits);

	DCB dcb = {0};
	dcb.DCBlength = sizeof(DCB);

	// warning: under win9x first BuildCommDCB must not be r/o!
	if(!::BuildCommDCB(buff, &dcb))
		return errGeneric;

	return ::SetCommState(handle, &dcb) ? errOk : errGeneric;
}


//! get the number of bytes available in the input buffer
/*!
\param handle a valid handle
\param count return the count of available bytes in the input buffer
\warning this method reset comm error under win32!
\return error code (0 means no error)
*/
inline int availableCount(Handle handle, long &count)
{
	assert(handle != NULL_HANDLE);

	DWORD dwErrors;
	COMSTAT comStat = {0};

	::ClearCommError(handle, &dwErrors, &comStat);
	assert(dwErrors == 0);

	count = static_cast<long>(comStat.cbInQue);
	return errOk;
}


//! enable/disable hardware flow control
/*!
\param handle a valid handle
\param bEnable if true enable hardware flow control, else disable
\return error code (0 means no error)
*/
inline int setHardwareFlowControl(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);

	DCB dcb = {0};
	dcb.DCBlength = sizeof(DCB);

	if(!::GetCommState(handle, &dcb))
		return errGeneric;

	if(bEnable)
	{
		dcb.fOutxCtsFlow = true;
		dcb.fOutxDsrFlow = true;
		dcb.fDtrControl = DTR_CONTROL_HANDSHAKE;//$?
		dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;//$?
	}
	else
	{
		dcb.fOutxCtsFlow = false;
		dcb.fOutxDsrFlow = false;
		dcb.fDtrControl = DTR_CONTROL_ENABLE;
		dcb.fRtsControl = RTS_CONTROL_ENABLE;
	}

	return ::SetCommState(handle, &dcb) ? errOk : errGeneric;
}


//! enable/disable software flow control
/*!
\param handle a valid handle
\param bEnable if true enable software flow control, else disable
\param Xon XON character
\param Xoff XOFF character
\return error code (0 means no error)
*/
inline int setSoftwareFlowControl(Handle handle, bool bEnable, char Xon, char Xoff)
{
	assert(handle != NULL_HANDLE);

	DCB dcb = {0};
	dcb.DCBlength = sizeof(DCB);

	if(!::GetCommState(handle, &dcb))
		return errGeneric;

	if(bEnable)
	{
		dcb.fOutX = true;
		dcb.fInX = true;
		dcb.fTXContinueOnXoff = false;//$?
		dcb.XonLim = 256;//$?
		dcb.XoffLim = 512;//$?
	}
	else
	{
		dcb.fOutX = false;
		dcb.fInX = false;
	}

	return ::SetCommState(handle, &dcb) ? errOk : errGeneric;
}


//! set read timeouts
/*!
\param handle a valid handle
\param timeout time (in ms) to wait until a char is received
\return error code (0 means no error)
*/
inline int setReadTimeouts(Handle handle, long timeout)
{
	assert(handle != NULL_HANDLE);

	COMMTIMEOUTS to = {0};

	if(!::GetCommTimeouts(handle, &to))
		return errGeneric;

	to.ReadIntervalTimeout = MAXDWORD;
	to.ReadTotalTimeoutMultiplier = MAXDWORD;
	to.ReadTotalTimeoutConstant = timeout;

	return ::SetCommTimeouts(handle, &to) ? errOk : errGeneric;
}


//! enable/disable blocking read
/*!
\param handle a valid handle
\param bBlocking if true read blocks until all requested data is read, else
	read will return immediately with available bytes (possibly none)
\return error code (0 means no error)
\note this function might affect read timeouts
*/
inline int setBlockingRead(Handle handle, bool bBlocking)
{
	assert(handle != NULL_HANDLE);

	COMMTIMEOUTS to = {0};

	if(!::GetCommTimeouts(handle, &to))
		return errGeneric;

	if(bBlocking)
	{
		to.ReadIntervalTimeout = 0;
		to.ReadTotalTimeoutMultiplier = 0;
		to.ReadTotalTimeoutConstant = 0;
	}
	else
	{
		to.ReadIntervalTimeout = MAXDWORD;
		to.ReadTotalTimeoutMultiplier = 0;
		to.ReadTotalTimeoutConstant = 0;
	}

	return ::SetCommTimeouts(handle, &to) ? errOk : errGeneric;
}


//! purge i/o buffers
/*!
\param handle a valid handle
\param flags a combination of the following:
	- purgeInput - clear input buffer
	- purgeOutput - clear output buffer
\return error code (0 means no error)
*/
inline int purgeBuffer(Handle handle, int flags)
{
	assert(handle != NULL_HANDLE);

	DWORD win32flags = 0;
	win32flags |= flags & purgeInput ? PURGE_RXCLEAR : 0;
	win32flags |= flags & purgeOutput ? PURGE_TXCLEAR : 0;

	return ::PurgeComm(handle, win32flags) ? errOk : errGeneric;
}


//! send a break (for 500ms)
/*!
\param handle a valid handle
\return error code (0 means no error)
*/
inline int sendBreak(Handle handle)
{
	assert(handle != NULL_HANDLE);

	if(!::SetCommBreak(handle))
		return errGeneric;
	::Sleep(500);
	if(!::ClearCommBreak(handle))
		return errGeneric;

	return errOk;
}


//! get modem status bits (DSR, DTR, RTS, CTS, DCD, RNG)
/*!
\param handle a valid handle
\param status will receive modem status flags
	- mstatusCTS - clear to send
	- mstatusDSR - data set ready
	- mstatusRNG - ring
	- mstatusDCD - data carrier detect
\return error code (0 means no error)
\warning doesn't get RTS, DTR
*/
inline int getModemStatus(Handle handle, int &status)
{
	assert(handle != NULL_HANDLE);

	DWORD win32status = 0;

	if(!::GetCommModemStatus(handle, &win32status))
		return errGeneric;

	status = 0;
	status |= win32status & MS_CTS_ON ? mstatusCTS : 0;
	status |= win32status & MS_DSR_ON ? mstatusDSR : 0;
	status |= win32status & MS_RING_ON ? mstatusRNG : 0;
	status |= win32status & MS_RLSD_ON ? mstatusDCD : 0;

	return errOk;
}


//! enable/disable DTR
/*!
\param handle a valid handle
\param bEnable enable or disable DTR
\return error code (0 means no error)
\note hardware flow control must be disabled to use this
*/
inline int setDTR(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);
	return ::EscapeCommFunction(handle, bEnable ? SETDTR : CLRDTR) ?
		errOk : errGeneric;
}


//! enable/disable RTS
/*!
\param handle a valid handle
\param bEnable enable or disable RTS
\return error code (0 means no error)
\note hardware flow control must be disabled to use this
*/
inline int setRTS(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);
	return ::EscapeCommFunction(handle, bEnable ? SETRTS : CLRRTS) ?
		errOk : errGeneric;
}


//! save current port settings
/*!
\param handle a valid handle
\param settings will store current port settings
\return error code (0 means no error)
*/
inline int saveSettings(Handle handle, PortSettings &settings)
{
	assert(handle != NULL_HANDLE);

	// get current DCB
	DCB dcb = {0};
	dcb.DCBlength = sizeof(DCB);
	if(!::GetCommState(handle, &dcb))
		return errGeneric;

	// get current comm timeouts
	COMMTIMEOUTS to = {0};
	if(!::GetCommTimeouts(handle, &to))
		return errGeneric;

	settings.dcb = dcb;
	settings.commTimeouts = to;
	return errOk;
}


//! restore current port settings
/*!
\param handle a valid handle
\param settings contain previously saved settings
\return error code (0 means no error)
*/
inline int restoreSettings(Handle handle, const PortSettings &settings)
{
	assert(handle != NULL_HANDLE);

	DCB dcb = settings.dcb;
	COMMTIMEOUTS commTimeouts = settings.commTimeouts;

	// restore DCB
	if(!::SetCommState(handle, &dcb))
		return errGeneric;

	// restore comm timeouts
	if(!::SetCommTimeouts(handle, &commTimeouts))
		return errGeneric;

	return errOk;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace win32PAL::serial
} // namespace win32PAL

namespace pal = win32PAL;

} // namespace lfc


#endif	// __SERIAL_WIN32_PAL_HPP__

