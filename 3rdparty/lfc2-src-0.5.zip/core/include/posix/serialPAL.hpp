
#ifndef __SERIAL_POSIX_PAL_HPP__
#define __SERIAL_POSIX_PAL_HPP__

#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

namespace lfc
{
namespace posixPAL
{

//! posix serial communications PAL
/*!
\todo more datalied error codes
\todo need testing
*/
namespace serial
{

const int MAX_ERROR_CODE = 2;

enum ErrorCodes
{
	errOk,
	errGeneric,
	errNotSupported,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! serial port handle type
typedef int Handle;

//! a handle value designating an invalid handle
const Handle NULL_HANDLE = -1;


//! contain port settings to save/restore
struct PortSettings
{
	termios dcb;
};


//! purge buffer flags
const int
	purgeInput		= 0x0001,
	purgeOutput		= 0x0002;

//! modem status flags
const int
	mstatusDSR		= 0x0001,
	mstatusDTR		= 0x0002,//$ not supported!
	mstatusRTS		= 0x0004,//$ not supported!
	mstatusCTS		= 0x0008,
	mstatusDCD		= 0x0010,
	mstatusRNG		= 0x0020;


//! init PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullHandle(const Handle &handle)
{
    return handle == NULL_HANDLE;
}


//! open serial port
/*!
\param handle will contain the handle if the operation succed, no modification otherwhise
\param name comm device name (ex. "com1" under win32, "/dev/ttyS0" under Linux)
\return error code (0 means no error)
*/
inline int open(Handle &handle, const char *name)
{
	assert(handle == NULL_HANDLE);

	Handle h = ::open(name, O_RDWR | O_NOCTTY | O_NDELAY);
	if(h != NULL_HANDLE)
	{
		handle = h;
		return errOk;
	}
	else
		return errGeneric;
}


//! close a serial port
/*!
\param handle a valid serial port handle
\return error code (0 means no error)
*/
inline int close(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::close(handle) == 0 ? errOk : errGeneric;
}


//! write data to a serial device
/*!
\param handle a valid handle
\param buff pointer to the data to be written
\param count number of bytes to write
\param written return the actual number of bytes written
\return error code (0 means no error)
*/
inline int write(Handle handle, const void *buff, long count, long &writtenCount)
{
	assert(handle != NULL_HANDLE);

	long wc = ::write(handle, buff, count);

	if(wc != -1)
	{
		writtenCount = wc;
		return errOk;
	}
	else if(errno == EAGAIN)
	{
		writtenCount = 0;
		return errOk;
	}
	else
		return errGeneric;
}

//! read data from a serial device
/*!
\param handle a valid handle
\param buff pointer to the buffer that will receive the data
\param count number of bytes to read
\param written return the actual number of bytes read
\return error code (0 means no error)
*/
inline int read(Handle handle, void *buff, long count, long &readCount)
{
	assert(handle != NULL_HANDLE);

	long rc = ::read(handle, buff, count);

	if(rc != -1)
	{
		readCount = rc;
		return errOk;
	}
	else if(errno == EAGAIN)
	{
		readCount = 0;
		return errOk;
	}
	else
		return errGeneric;
}


//! flush output buffer
/*!
\param handle a valid handle
\return error code (0 means no error)
*/
inline int flush(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::tcdrain(handle) == 0 ? errOk : errGeneric;
}


//! set port settings (baud rate, parity, ...)
/*!
\param handle a valid handle
\param portSettings describe port settings in the following format:
	<baud>,<B><P><S>
	where
	- baud is serial transmition speed
	- B is byte size (5..8)
	- P is parity (n-none, o-odd, e-even, s-space)
	- S is stop bits (1 or 2)
\note settings string is not case sensitive and it can't containt whitespaces
\return error code (0 means no error)
*/
inline int setup(Handle handle, const char *portSettings)
{
	assert(handle != NULL_HANDLE);
	assert(portSettings != NULL);

	const char *p = portSettings;
	long baud = 0;
	long byteSize = 0;
	long stopBits = 0;
	char parity = '#';

	// parse settings
	while(isdigit(*p))
		baud = baud * 10 + *p++ - '0';
	if(*p++ != ',')
		return errGeneric;
	byteSize = *p++ - '0';
	if(byteSize < 4 || byteSize > 8)
		return errGeneric;
	parity = toupper(*p++);
	if(::strchr("NOES", parity) == NULL)
		return errGeneric;
	stopBits = *p++ - '0';
	if(stopBits != 1 && stopBits != 2)
		return errGeneric;
	if(*p != 0)
		return errGeneric;

	// setup port settings: baud, byteSize, parity, stopBits
	termios dcb = {0};

	// get current settings
	if(::tcgetattr(handle, &dcb))
		return errGeneric;

	// other flags ($ CLOCAL might not be always wantted...)
	::cfmakeraw(&dcb);
	dcb.c_cflag |= (CLOCAL | CREAD);
	dcb.c_iflag |= (INPCK | ISTRIP);

	// set speed
	speed_t speed = 0;
	switch(baud)
	{
	case 50:		speed = B50; break;
	case 75:		speed = B75; break;
	case 110:		speed = B110; break;
	case 134:		speed = B134; break;
	case 150:		speed = B150; break;
	case 200:		speed = B200; break;
	case 300:		speed = B300; break;
	case 600:		speed = B600; break;
	case 1200:		speed = B1200; break;
	case 1800:		speed = B1800; break;
	case 2400:		speed = B2400; break;
	case 4800:		speed = B4800; break;
	case 9600:		speed = B9600; break;
	case 19200:		speed = B19200; break;
	case 38400:		speed = B38400; break;
	case 57600:		speed = B57600; break;
	case 115200:	speed = B115200; break;
	case 230400:	speed = B230400; break;

	default: return errGeneric;
	}

	if(::cfsetospeed(&dcb, speed))
		return errGeneric;
	if(::cfsetispeed(&dcb, speed))
		return errGeneric;

	// set byte size
	int posixByteSize = -1;

	switch(byteSize)
	{
	case 5:	posixByteSize = CS5; break;
	case 6:	posixByteSize = CS6; break;
	case 7:	posixByteSize = CS7; break;
	case 8:	posixByteSize = CS8; break;

	default: return errGeneric;
	}

	dcb.c_cflag &= ~CSIZE;
	dcb.c_cflag |= posixByteSize;

	// set parity
	switch(parity)
	{
	case 'N': dcb.c_cflag &= ~PARENB; break;
	case 'O': dcb.c_cflag |= (PARENB | PARODD); break;
	case 'E': dcb.c_cflag |= PARENB; dcb.c_cflag &= ~PARODD; break;
	case 'S': dcb.c_cflag &= ~PARENB; break;

	default: return errGeneric;
	}

	// set stop bits
	if(stopBits == 1)
		dcb.c_cflag &= ~CSTOPB;
	else
		dcb.c_cflag |= CSTOPB;

	// finally setup serial port
	return ::tcsetattr(handle, TCSANOW, &dcb) == 0 ? errOk : errGeneric;
}


//! get the number of bytes available in the input buffer
/*!
\param handle a valid handle
\param count return the count of available bytes in the input buffer
\return error code (0 means no error)
*/
inline int availableCount(Handle handle, long &count)
{
	assert(handle != NULL_HANDLE);

	int tmp = -1;
	if(::ioctl(handle, FIONREAD, &tmp))
		return errGeneric;
	count = tmp;
	return errOk;
}


//! enable/disable hardware flow control
/*!
\param handle a valid handle
\param bEnable if true enable hardware flow control, else disable
\return error code (0 means no error)
*/
inline int setHardwareFlowControl(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);

	termios dcb = {0};

	// get current settings
	if(::tcgetattr(handle, &dcb))
		return errGeneric;

	if(bEnable)
		dcb.c_cflag |= CRTSCTS;
	else
		dcb.c_cflag &= ~CRTSCTS;

	return ::tcsetattr(handle, TCSANOW, &dcb) == 0 ? errOk : errGeneric;
}


//! enable/disable software flow control
/*!
\param handle a valid handle
\param bEnable if true enable software flow control, else disable
\param Xon XON character
\param Xoff XOFF character
\return error code (0 means no error)
*/
inline int setSoftwareFlowControl(Handle handle, bool bEnable, char Xon, char Xoff)
{
	assert(handle != NULL_HANDLE);

	termios dcb = {0};

	// get current settings
	if(::tcgetattr(handle, &dcb))
		return errGeneric;

	if(bEnable)
	{
		dcb.c_iflag |= (IXON | IXOFF);
		dcb.c_cc[VSTART] = Xon;
		dcb.c_cc[VSTOP] = Xoff;
	}
	else
		dcb.c_iflag &= ~(IXON | IXOFF | IXANY);

	return ::tcsetattr(handle, TCSANOW, &dcb) == 0 ? errOk : errGeneric;
}


//! set read timeouts
/*!
\param handle a valid handle
\param timeout time (in ms) to wait until a char is received
\return error code (0 means no error)
*/
inline int setReadTimeouts(Handle handle, long timeout)
{
	assert(handle != NULL_HANDLE);

	termios dcb = {0};

	// get current settings
	if(::tcgetattr(handle, &dcb))
		return errGeneric;

	dcb.c_cc[VMIN] = 0;
	dcb.c_cc[VTIME] = timeout / 100;

	return ::tcsetattr(handle, TCSANOW, &dcb) == 0 ? errOk : errGeneric;
}


//! enable/disable blocking read
/*!
\param handle a valid handle
\param bBlocking if true read blocks until all requested data is read, else
	read will return immediately with available bytes (possibly none)
\return error code (0 means no error)
\note this function might affect read timeouts
*/
inline int setBlockingRead(Handle handle, bool bBlocking)
{
	assert(handle != NULL_HANDLE);
	return ::fcntl(handle, F_SETFL, bBlocking ? 0 : FNDELAY) != -1 ? errOk : errGeneric;
}


//! purge i/o buffers
/*!
\param handle a valid handle
\param flags a combination of the following:
	- purgeInput - clear input buffer
	- purgeOutput - clear output buffer
\return error code (0 means no error)
*/
inline int purgeBuffer(Handle handle, int flags)
{
	assert(handle != NULL_HANDLE);

	int posixPurgeFlags = -1;

	if(flags == purgeInput)
		posixPurgeFlags = TCIFLUSH;
	else if(flags == purgeOutput)
		posixPurgeFlags = TCOFLUSH;
	else if(flags == (purgeInput | purgeOutput))
		posixPurgeFlags = TCIOFLUSH;
	else
		return errGeneric;

	return ::tcflush(handle, posixPurgeFlags) == 0 ? errOk : errGeneric;
}


//! send a break (for 500ms)
/*!
\param handle a valid handle
\return error code (0 means no error)
*/
inline int sendBreak(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::tcsendbreak(handle, 0) == 0 ? errOk : errGeneric;
}


//! get modem status bits (DSR, DTR, RTS, CTS, DCD, RNG)
/*!
\param handle a valid handle
\param status will receive modem status flags
	- mstatusCTS - clear to send
	- mstatusDSR - data set ready
	- mstatusRNG - ring
	- mstatusDCD - data carrier detect
\return error code (0 means no error)
\warning doesn't get RTS, DTR
*/
inline int getModemStatus(Handle handle, int &status)
{
	assert(handle != NULL_HANDLE);

	int posixFlags = 0;

	if(::ioctl(handle, TIOCMGET, &posixFlags))
		return errGeneric;

	status = 0;
	status |= posixFlags & TIOCM_CTS ? mstatusCTS : 0;
	status |= posixFlags & TIOCM_DSR ? mstatusDSR : 0;
	status |= posixFlags & TIOCM_RNG ? mstatusRNG : 0;
	status |= posixFlags & TIOCM_CAR ? mstatusDCD : 0;

	return errOk;
}


//! enable/disable DTR
/*!
\param handle a valid handle
\param bEnable enable or disable DTR
\return error code (0 means no error)
\note hardware flow control must be disabled to use this
*/
inline int setDTR(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);

	int posixFlags = 0;

	if(::ioctl(handle, TIOCMGET, &posixFlags))
		return errGeneric;

	if(bEnable)
		posixFlags |= TIOCM_DTR;
	else
		posixFlags &= ~TIOCM_DTR;

	if(::ioctl(handle, TIOCMSET, &posixFlags))
		return errGeneric;

	return errOk;
}


//! enable/disable RTS
/*!
\param handle a valid handle
\param bEnable enable or disable RTS
\return error code (0 means no error)
\note hardware flow control must be disabled to use this
*/
inline int setRTS(Handle handle, bool bEnable)
{
	assert(handle != NULL_HANDLE);

	int posixFlags = 0;

	if(::ioctl(handle, TIOCMGET, &posixFlags))
		return errGeneric;

	if(bEnable)
		posixFlags |= TIOCM_RTS;
	else
		posixFlags &= ~TIOCM_RTS;

	if(::ioctl(handle, TIOCMSET, &posixFlags))
		return errGeneric;

	return errOk;
}


//! save current port settings
/*!
\param handle a valid handle
\param settings will store current port settings
\return error code (0 means no error)
*/
inline int saveSettings(Handle handle, PortSettings &settings)
{
	assert(handle != NULL_HANDLE);
	return ::tcgetattr(handle, &settings.dcb) == 0 ? errOk : errGeneric;
}


//! restore current port settings
/*!
\param handle a valid handle
\param settings contain previously saved settings
\return error code (0 means no error)
*/
inline int restoreSettings(Handle handle, const PortSettings &settings)
{
	assert(handle != NULL_HANDLE);
	return ::tcsetattr(handle, TCSANOW, &settings.dcb) == 0 ? errOk : errGeneric;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace posixPAL::serial
} // namespace posixPAL

namespace pal = posixPAL;

} // namespace lfc


#endif	// __SERIAL_POSIX_PAL_HPP__
