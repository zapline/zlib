
#ifndef __CONSOLE_POSIX_PAL_HPP__
#define __CONSOLE_POSIX_PAL_HPP__

#include <stdio.h>
#include <assert.h>

namespace lfc
{
namespace posixPAL
{

//! posix console PAL
/*!
\todo need testing
*/
namespace console
{

const int MAX_ERROR_CODE = 0;

enum ErrorCodes
{
	errOk,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! init console PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}

//! cleanup console PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}

//! send a character to console
/*!
\param value character code
\return error code (0 means no error)
*/
inline int putChar(int value)
{
	putchar(value);
	return errOk;
}

//! read a character from console
/*!
\param value returned character code
\return error code (0 means no error)
*/
inline int getChar(int &value)
{
	value = getchar();
	return errOk;
}


//! flush console output buffer
/*!
\return error code (0 means no error)
*/
inline int flush()
{
	fflush(stdout);
	return errOk;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace posixPAL::console
} // namespace posixPAL

namespace pal = posixPAL;

} // namespace lfc


#endif	// __CONSOLE_POSIX_PAL_HPP__
