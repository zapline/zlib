#ifndef __THREADS_POSIX_PAL_HPP__
#define __THREADS_POSIX_PAL_HPP__

#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <assert.h>

namespace lfc
{
namespace posixPAL
{

//! posix threads PAL
/*!
\todo needs testing
\todo more detailed return codes
*/
namespace threads
{

const int MAX_ERROR_CODE = 1;

enum ErrorCodes
{
	errOk,
	errGeneric,
};


extern const char *messagesTable[MAX_ERROR_CODE + 1];

//! tool for using posix threads
void* __threadProc(void *);

//! used to pass __threadProc needed information
struct __StartThreadInfo
{
	void (*proc)(void *);
	void *pData;
};

//! posix thread handle type
struct ThreadHandle
{
    ::pthread_t handle;
    bool valid;

    ThreadHandle() : valid(false) {}
	bool isNull() const { return !valid; }

private:
	void operator==(const ThreadHandle &) const;	// disabled, no implementation
};

//! posix mutex handle type
struct MutexHandle
{
    ::pthread_mutex_t handle;
    bool valid;

    MutexHandle() : valid(false) {}
	bool isNull() const { return !valid; }

private:
	void operator==(const MutexHandle &) const;	// disabled, no implementation
};

//! posix semaphore handle type

struct SemHandle
{
    ::sem_t handle;
    bool valid;

    SemHandle() : valid(false) {}
	bool isNull() const { return !valid; }

private:
	void operator==(const SemHandle &) const;	// disabled, no implementation
};

//! posix TLS key type
typedef ::pthread_key_t TLSKey;


//! a handle value designating an invalid thread handle
const ThreadHandle NULL_THREAD_HANDLE = ThreadHandle();

//! a handle value designating an invalid mutex handle
const MutexHandle NULL_MUTEX_HANDLE = MutexHandle();

//! a handle value designating an invalid semaphore handle
const SemHandle NULL_SEM_HANDLE = SemHandle();

//! thread priority
const int
	priorityMin = -1,
	priorityNormal = 0,
	priorityMax = 1;


//! init threads PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup threads PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullThreadHandle(const ThreadHandle &handle)
{
    return handle.isNull();
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullMutexHandle(const MutexHandle &handle)
{
    return handle.isNull();
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullSemHandle(const SemHandle &handle)
{
    return handle.isNull();
}


//! create a new thread
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\param proc address of thread starting function
\param pData application defined value (passed to proc)
\return error code (0 means no error)
*/

inline int createThread(ThreadHandle &handle, void (*proc)(void *), void *pData)
{
	assert(handle.valid == false);

	__StartThreadInfo *pInfo = new __StartThreadInfo;
	pInfo->proc = proc;
	pInfo->pData = pData;

	ThreadHandle h;
	if( ::pthread_create(&h.handle, NULL, &__threadProc, pInfo) != 0 )
	    return errGeneric;

	h.valid = true;
	handle = h;

	return errOk;
}


//! close a thread handle
/*!
\param handle thread handle
\return error code (0 means no error)
*/

inline int closeThread(ThreadHandle &handle)
{
	assert(handle.valid == true);

 	if(::pthread_detach(handle.handle) == 0)
	{
		handle.valid = false;
	    return errOk;
	}
	else
	    return errGeneric;
}

//! get current thread handle
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\return error code (0 means no error)
\note the handle returned is not a pseudohandle, and must be closed
	when no longer used. There is no guarantee that this handle is the same
	with that returned when thread was created.
*/

inline int getCurrentThread(ThreadHandle &handle)
{
    // my man page doesn't say anything about errs.
    // it just says pthread_self returns the calling thread's handle
    handle.handle = ::pthread_self();
    handle.valid = true;
    return errOk;
}


//! destroy a thread (terminate async)
/*!
\param handle thread handle
\return error code (0 means no error)
*/

inline int destroyThread(const ThreadHandle &handle)
{
	assert(handle.valid == true);
    return ::pthread_cancel(handle.handle) == 0 ? errOk : errGeneric;
}

//! wait for a thread to terminate
/*!
\param handle thread handle
\return error code (0 means no error)
*/

inline int joinThread(const ThreadHandle &handle)
{
	assert(handle.valid == true);

	if( ::pthread_join(handle.handle, NULL) == 0 )
		return errOk;
	else
		return errGeneric;
}


//! set thread priority
/*!
\param handle thread handle
\param priority new thread priority
\return error code (0 means no error)
*/

inline int setThreadPriority(const ThreadHandle &handle, int priority)
{
	assert(handle.valid == true);

	sched_param param;

	::memset(&param, 0, sizeof(param));

	switch(priority)
	{
	case priorityMin:
		param.sched_priority = ::sched_get_priority_min(SCHED_OTHER);
		break;

	case priorityNormal:
		param.sched_priority =
			(::sched_get_priority_min(SCHED_OTHER) +
			::sched_get_priority_max(SCHED_OTHER)) / 2;
		break;

	case priorityMax:
		param.sched_priority = ::sched_get_priority_max(SCHED_OTHER);
		break;

	default:
		return errGeneric;
	}

	if(::pthread_setschedparam(handle.handle, SCHED_OTHER, &param) != 0)
		return errGeneric;

	return errOk;
}


//! yield
/*!
\return error code (0 means no error)
*/

inline int yield()
{
	if( ::sched_yield() == 0)
		return errOk;

	return errGeneric;
}

//! suspends execution for a specified interval
/*!
\param miliseconds the interval duration
\return error code (0 means no error)
*/

inline int sleep(long miliseconds)
{
	timespec ts;
	ts.tv_sec = miliseconds / 1000;
	ts.tv_nsec = (miliseconds % 1000) * 1000000;
	::nanosleep(&ts, NULL);

	return errOk;
}


//! alloc new TLS
/*!
\param key will contain the new key
\return error code (0 means no error)
*/

inline int allocTLS(TLSKey &key)
{
	TLSKey k;

	if( ::pthread_key_create(&k, NULL) != 0)
		return errGeneric;

	key = k;
	return errOk;
}

//! free TLS
/*!
\param key TLS key
\return error code (0 means no error)
\note TLS are freed at the process termination
*/

inline int freeTLS(TLSKey key)
{
	return ::pthread_key_delete(key) == 0 ? errOk : errGeneric;
}


//! set TLS
/*!
\param key TLS key
\param value the value
\return error code (0 means no error)
*/

inline int setTLS(TLSKey key, void *value)
{
	return  ::pthread_setspecific(key, value) == 0 ? errOk : errGeneric;
}


//! get TLS
/*!
\param key TLS key
\param value will contain the value
\return error code (0 means no error)
*/

inline int getTLS(TLSKey key, void *&value)
{
	void *v = ::pthread_getspecific(key);
	if( v == NULL)
		return errGeneric;

	value = v;
	return errOk;
}


//! create a new mutex object
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\return error code (0 means no error)
\note apparently my system can't handle ptread_mutexattr_setkind_np()
so I'm just gonna create the mutex the default way. change the code if
necessary. I couldn't find a better libpthread to download.
*/

//
int createMutex(MutexHandle &handle);

//! close a mutex
/*!
\param handle indicate mutex to be closed
\return error code (0 means no error)
*/

inline int closeMutex(MutexHandle &handle)
{
	assert(handle.valid == true);

	if(::pthread_mutex_destroy(&handle.handle) == 0)
	{
		handle.valid = false;
		return errOk;
	}
	else
		return errGeneric;
}


//! lock a mutex
/*!
\param handle indicate mutex
\return error code (0 means no error)
\note recursive locks ok
*/

inline int lockMutex(MutexHandle &handle)
{
	assert(handle.valid == true);
	return ( ::pthread_mutex_lock(&handle.handle) == 0) ? errOk : errGeneric;
}


//! try to lock a mutex w/o blocking
/*!
\param handle indicate mutex
\param bLocked return true if lock succeded
\return error code (0 means no error)
\note recursive locks ok
*/
inline int tryLockMutex(MutexHandle &handle, bool &bLocked)
{
	assert(handle.valid == true);
	bLocked = ::pthread_mutex_trylock(&handle.handle) == 0;
	return errOk;
}

//! unlock a mutex
/*!
\param handle indicate mutex
\return error code (0 means no error)
*/
inline int unlockMutex(MutexHandle &handle)
{
	assert(handle.valid == true);
	return ::pthread_mutex_unlock(&handle.handle) == 0 ? errOk : errGeneric;
}


//! create a new semaphore object
/*!
\param handle will contain the handle if the operation succed,
	no modification otherwhise
\param count initial semaphore value
\return error code (0 means no error)
*/

inline int createSemaphore(SemHandle &handle, long count)
{
	assert(handle.valid == false);

	if( ::sem_init(&handle.handle, 0, count) == -1)
	    return errGeneric;

	handle.valid = true;
	return errOk;
}


//! close a semaphore
/*!
\param handle indicate semaphore to be closed
\return error code (0 means no error)
*/

inline int closeSemaphore(SemHandle &handle)
{
	assert(handle.valid == true);

	if(::sem_destroy(&handle.handle) == 0)
	{
		handle.valid = false;
		return errOk;
	}
	else
		return errGeneric;
}


//! wait a semaphore (lock)
/*!
\param handle indicate semaphore
\return error code (0 means no error)
*/

inline int waitSemaphore(SemHandle &handle)
{
	assert(handle.valid == true);
	return ( ::sem_wait(&handle.handle) == 0 ) ? errOk : errGeneric;
}

//! wait a semaphore w/o blocking (lock)
/*!
\param handle indicate semaphore
\param bLocked return true if lock succeded
\return error code (0 means no error)
*/

inline int tryWaitSemaphore(SemHandle &handle, bool &bLocked)
{
	assert(handle.valid == true);
	bLocked = (::sem_trywait(&handle.handle) == 0);
	return errOk;
}

//! post a semaphore (unlock)
/*!
\param handle indicate semaphore
\return error code (0 means no error)
*/

inline int postSemaphore(SemHandle &handle)
{
	return (::sem_post(&handle.handle) == 0) ? errOk : errGeneric;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace posixPAL::threads
} // namespace posixPAL

namespace pal = posixPAL;

} // namespace lfc


#endif	// __THREADS_POSIX_PAL_HPP__
