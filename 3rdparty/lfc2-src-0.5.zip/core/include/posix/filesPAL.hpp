
#ifndef __FILES_POSIX_PAL_HPP__
#define __FILES_POSIX_PAL_HPP__

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

namespace lfc
{
namespace posixPAL
{

//! posix files PAL
/*!
\todo needs testing
*/
namespace files
{

const int MAX_ERROR_CODE = 3;

enum ErrorCodes
{
	errOk,
	errGeneric,
	errNotSupported,
	errAlreadyExists,
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! posix file type
typedef int Handle;

//! a handle value designating an invalid handle
const Handle NULL_HANDLE = -1;

//! seek mode
const int
	seekSet		    = 0x0001,
	seekCurrent	    = 0x0002,
	seekEnd		    = 0x0004;

//! open mode
const int
	flAppend		= 0x0001,
	flRead			= 0x0002,
	flWrite			= 0x0004,
	flTruncate		= 0x0008,
	flOpenExisting	= 0x0010,
	flCreateNew		= 0x0020,
	flTemp			= 0x0040,
	flWriteThrough  = 0x0080;

//! share mode
const int
	shRead		    = 0x0001,
	shWrite		    = 0x0002;


//! init files PAL
/*!
\return error code (0 means no error)
*/
inline int init()
{
	return errOk;
}


//! cleanup files PAL
/*!
\return error code (0 means no error)
*/
inline int cleanup()
{
	return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullHandle(const Handle &handle)
{
    return handle == NULL_HANDLE;
}


//! open/create a file
/*!
\param handle will contain the handle if the operation succed, no modification otherwhise
\param name file name
\param flags open mode, see File::OpenMode
\param shareFlags sharing, see File::ShareMode
, 0 for no sharing
\return error code (0 means no error)
\bug flTemp not implemented
*/

inline int open(Handle &handle, const char *name, int flags, int shareFlags)
{
	int accessFlag = 0;

	if( (accessFlag & flRead) && (accessFlag & flWrite) )
	    accessFlag |= O_RDWR;
	else
	{
	    accessFlag |= (flags & flRead ? O_RDONLY : 0);
	    accessFlag |= (flags & flWrite ? O_WRONLY : 0);
	}

#if defined(__FreeBSD__)
	accessFlag |= (flags & flWriteThrough ? O_FSYNC : 0);
#else // linux, ...?
	accessFlag |= (flags & flWriteThrough ? O_SYNC : 0);
#endif

	accessFlag |= (flags & flAppend ? O_APPEND : 0);
	accessFlag |= O_CREAT;

	if(flags & flOpenExisting)
		accessFlag &= ~O_CREAT;
	else if(flags & flCreateNew)
		accessFlag |= O_EXCL;
	else if(flags & flTruncate)
		accessFlag |= O_TRUNC;

	// by default, when a file gets created, the owner and the owner's
	// group can read and write the file.
	int mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP;

	Handle h = ::open(name, accessFlag, mode);

	if(h == -1)
    {
		if(errno == EEXIST)
		    return errAlreadyExists;
		else
		    return errGeneric;
    }

	// begin share mode section
	struct flock fileLock;
	int tmpShFlag = 0;

	if( shareFlags & shRead || shareFlags & shWrite )
	{
	    tmpShFlag |= (shareFlags & shRead ? F_RDLCK : 0);
	    tmpShFlag |= (shareFlags & shWrite ? F_WRLCK : 0);
	}
	else
	    tmpShFlag |= F_UNLCK;

	fileLock.l_type = tmpShFlag;
	fileLock.l_whence = SEEK_SET;
	fileLock.l_start = 0;
	fileLock.l_len = 0;
	fileLock.l_pid = ::getpid();

	if( ::fcntl( h, F_SETLK, &fileLock) == -1)
	{
	    ::close(h);
	    return errGeneric;
	}

	// end share mode section

	handle = h;
	return errOk;
}

//! close a file
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/

inline int close(Handle handle)
{
	assert(handle != NULL_HANDLE);
	return ::close(handle) == 0 ? errOk : errGeneric;
}

//! moves the file pointer of an open file
/*!
\param handle a valid file handle
\param offset offset to move file pointer (see SeekMode)
\param mode indicate relative moving base
\param pos return new position
\return error code (0 means no error)
*/

inline int seek(Handle handle, long offset, int mode, long &pos)
{
	int tmpMode = 0;
	switch(mode)
	{
	case seekSet: tmpMode = SEEK_SET; break;
	case seekCurrent: tmpMode = SEEK_CUR; break;
	case seekEnd: tmpMode = SEEK_END; break;
	}

	long newPos = ::lseek(handle, offset, tmpMode);

	if( newPos != -1 )
	{
		pos = newPos;
		return errOk;
	}
	else
		return errGeneric;
}

//! set EOF to current position
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/

inline int setEof(Handle handle)
{
	off_t pos;


	if((pos = ::lseek(handle, 0, SEEK_CUR)) == -1)
	    return errGeneric;

	if( ::ftruncate(handle, pos) == -1)
	    return errGeneric;

	return errOk;
}

//! write data to a file
/*!
\param handle a valid file handle
\param buff pointer to the data to be written
\param count number of bytes to write
\param written return the actual number of bytes written
\return error code (0 means no error)
*/

inline int write(Handle handle, const void *buff, long count, long &written)
{
	long temp = ::write(handle, buff, count);

	if(temp != -1)
	{
		written = temp;
		return errOk;
	}
	else
		return errGeneric;
}

//! read data from a file
/*!
\param handle a valid file handle
\param buff pointer to the buffer that will receive the data
\param count number of bytes to read
\param written return the actual number of bytes read
\return error code (0 means no error)
*/

inline int read(Handle handle, void *buff, long count, long &read)
{
	long temp = ::read(handle, buff, count);

	if(temp != -1)
	{
		read = temp;
		return errOk;
	}
	else
		return errGeneric;
}


//! flush file buffers
/*!
\param handle a valid file handle
\return error code (0 means no error)
*/
inline int flush(Handle handle)
{
	return ::fsync(handle) == 0 ? errOk : errGeneric;
}


//! return the message coresponding to a return code
/*!
\param index message index (return code from other pal functions)
*/
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace posixPAL::files
} // namespace posixPAL

namespace pal = posixPAL;

} // namespace lfc


#endif	// __FILES_POSIX_PAL_HPP__


