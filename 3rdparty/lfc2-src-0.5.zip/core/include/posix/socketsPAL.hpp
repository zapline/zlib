
#ifndef __SOCKETS_POSIX_PAL_HPP__
#define __SOCKETS_POSIX_PAL_HPP__

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <fcntl.h>
#include <assert.h>

namespace lfc
{
namespace posixPAL
{

//! posix sockets PAL
namespace sockets
{

const int MAX_ERROR_CODE = 6;

enum ErrorCodes
{
	errOk,
	errGeneric,
	errInitError,
	errConnectionClosed,
	errUnbound,
	errNotListening,
	errBadAddress
};

extern const char *messagesTable[MAX_ERROR_CODE + 1];


//! the network protocol family categories
const int
    pfINET = AF_INET,
    pfUNIX = AF_UNIX, // UNIX protocols for local communication
    pfIPX = AF_IPX;

//! connection oriented and conectionless socket types
const int
    stSTREAM = SOCK_STREAM,
    stDGRAM = SOCK_DGRAM;

//! flags for use with send()/sendto()/recv()/recvfrom()
const int
    flagPEEK = MSG_PEEK,
    flagOOB = MSG_OOB;

//! posix socket type
typedef int Handle;

//! a handle value designating an invalid handle
const Handle NULL_HANDLE = -1;


//! initializes the environment.
/*!
\brief it _MUST_ be called _before_ any other sockets function.
\return error code ( 0 == no errors )
*/
inline int init()
{
    return errOk;

}


//! cleans up the environment.
/*!
\brief it _MUST_ be called after there's no more need for sockets
\return error code ( 0 == no errors )
*/
inline int cleanup()
{
    return errOk;
}


//! test a handle for invalid values
/*!
\return true if the handle is valid
*/
inline bool isNullHandle(const Handle &handle)
{
    return handle == NULL_HANDLE;
}


//! creates a socket
/*!
\param handle contains a valid socket handle if the operation succeeds
\param pf protocol family. see the ProtocolFamily enum for allowed
values.
\param type the socket type. see the SocketType enum for allowed values.
\return error code ( 0 == no errors )
*/
inline int open(Handle &handle, int pf, int type)
{
	Handle temp;
	if( ( temp = ::socket(pf, type, 0)) == NULL_HANDLE )
		return errGeneric;

	handle = temp;
	return errOk;
}

//! closes the socket.
/*!
\param handle a handle to the socket to close
\return error code ( 0 == no errors )
*/
inline int close(Handle handle)
{
	if( ::shutdown(handle, SHUT_RDWR) == NULL_HANDLE )
		return errGeneric;

	if( ::close(handle) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}

//! establish a connection with a peer.
/*!
\param handle a handle to the socket to connect
\param to a C-style string containing either a hostname or an IP
address
\param pf the protocol family to be used for the connection;
see the ProtocolFamily enum
\param port the peer port you wish to connect to
\return error code ( 0 == no errors )
*/
inline int connect(Handle handle, const char* to, int pf,
				   u_short port)
{
	sockaddr_in sin;
	hostent *hp = ::gethostbyname(to);

	if(hp == NULL)
	{
	    sin.sin_addr.s_addr = inet_addr(to);
	    if(sin.sin_addr.s_addr == INADDR_NONE)
			return errBadAddress;
	}
	else
		::memcpy(&sin.sin_addr, hp->h_addr, hp->h_length);

	sin.sin_family = pf;
	sin.sin_port = htons(port);

	if( ::connect(handle, (sockaddr *)&sin, sizeof sin) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}

//! sends data on a connected socket.
/*!
\param handle a handle to the socket to send
\param buffer pointer to the buffer containing the data to be sent
\param len number of bytes to send from the buffer
\param flags see the Flag enum. flagPEEK gets len bytes
into the buffer but doesn't remove them from the input queue.
\param bytesSent the number of bytes that send() managed to actually
send
\return error code ( 0 == no errors )
*/
inline int send(Handle handle, const char* buffer, long len, int flags,
				long &bytesSent)
{
	if( ( bytesSent = ::send(handle, buffer, len, flags)) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}


/*!
\brief sends data to a specific destination ( most likely to be used in
combination with connectionless protocols )
\param handle a handle to the socket to send
\param buffer pointer to the buffer containing the data to be sent
\param len number of bytes to send from the buffer
\param flags see the Flag enum. flagPEEK gets len bytes
into the buffer but doesn't remove them from the input queue.
\param to a C-style string containing either a hostname or an IP
address
\param pf the protocol family to be used;
see the ProtocolFamily enum
\param port the peer port you wish to connect to
\param bytesSent the number of bytes that sendto() managed to actually
send
\return error code ( 0 == no errors )
*/
inline int sendTo(Handle handle, const char* buffer, long len, int flags,
				const char* to, int pf, u_short port,
				long &bytesSent)
{
	sockaddr_in sin;
	hostent *hp = ::gethostbyname(to);

	if( hp == NULL )
		if( ( sin.sin_addr.s_addr = inet_addr(to) ) == INADDR_NONE )
			return errBadAddress;
		else
			::memcpy(&sin.sin_addr, hp->h_addr, hp->h_length);

	sin.sin_family = pf;
	sin.sin_port = htons(port);

	bytesSent = ::sendto(handle, buffer, len, flags, (sockaddr *)&sin,
						sizeof sin);

	if( bytesSent == NULL_HANDLE )
		return errGeneric;

	return errOk;
}


//! tries to receive data from a connected socket.
/*!
\param handle a handle to the socket to receive
\param buffer pointer to the buffer to hold the received data into
\param len number of bytes to receive into the buffer
\param flags see the Flag enum. flagPEEK gets len bytes
into the buffer but doesn't remove them from the input queue.
\return error code ( 0 == no errors )
*/
inline int recv(Handle handle, char* buffer, long len, int flags,
				long &bytesReceived)
{
	switch( bytesReceived = ::recv(handle, buffer, len, flags) )
	{
	case 0:
		return errConnectionClosed;

	case NULL_HANDLE:
		return errGeneric;

	default:
		return errOk;
	}
}

//! receives a datagram and stores the source address.
/*!
\param handle a handle to the socket to receive
\param buffer pointer to the buffer to hold the received data into
\param len number of bytes to receive into the buffer
\param flags see the Flag enum. flagPEEK gets len bytes
into the buffer but doesn't remove them from the input queue.
\param from a C-style string containing an IP address; filled after execution
\param pf the protocol family to be used;
see the ProtocolFamily enum
\param port the peer port you wish to connect to
\return error code ( 0 == no errors )
*/
inline int recvFrom(Handle handle, char* buffer, long len, int flags,
				char* from, int pf, u_short port,
				long &bytesReceived)
{
	sockaddr_in sin;

	unsigned int sinSize = sizeof sin;

	bytesReceived = ::recvfrom(handle, buffer, len, flags, (sockaddr *)&sin,
						&sinSize);

	switch( bytesReceived )
	{
	case 0:
		return errConnectionClosed;

	case NULL_HANDLE:
		return errGeneric;

	default:
		::strcpy(from, ::inet_ntoa(sin.sin_addr));
		return errOk;
	}
}

//! associates a local address with a socket
/*!
\param handle a handle to the socket to connect
\param pf the protocol family that the desired to be bound socket
should use
\param port the port to bind the socket represented by handle to
\return error code ( 0 == no errors )
*/
inline int bind(Handle handle, int pf, u_short port)
{
	sockaddr_in sin;

	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons(port);
	sin.sin_family = pf;

	if( ::bind(handle, (sockaddr *)&sin, sizeof sin) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}

//! puts the socket into listening state for incoming connections.
/*!
\param handle a handle to the socket to listen
\param backlog the maximum length to which the queue of pending
connections may grow
\return error code ( 0 == no errors )
*/
inline int listen(Handle handle, int backlog = SOMAXCONN)
{
	if( ::listen(handle, backlog) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}

//! accept a connection on a socket.
/*!
\param newHandle will contain a handle to a new socket if accept()
succeeds; won't be modified otherwise
\param handle the socket that accepts connections
\return error code ( 0 == no errors )
*/
inline int accept(Handle& newHandle, Handle handle)
{
	Handle temp;
	if( ( temp = ::accept(handle, NULL, NULL) ) == NULL_HANDLE )
		return errGeneric;

	newHandle = temp;
	return errOk;
}

//! control the mode of a socket
/*!
\param handle a handle to the socket.
\param blocking true, for blocking mode, false for non-blocking mode
\return error code ( 0 == no errors )
*/
inline int setBlocking(Handle handle, bool blocking)
{
	if( ::fcntl( handle, F_SETFL, blocking ? 0 : O_NONBLOCK ) == NULL_HANDLE )
		return errGeneric;

	return errOk;
}


/*!
\param service service name
\param port return the port asociated with service
\return error code ( 0 == no errors )
*/
inline int getServicePort(const char *service, u_short &port)
{
	servent *psent = ::getservbyname(service, NULL);
	if(psent == NULL)
		return errGeneric;
	port = ntohs(psent->s_port);
	return errOk;
}


//! flush socket buffers
/*!
\param handle an open socket handle
\return error code ( 0 == no errors )
\todo fix this!
*/
inline int flush(Handle handle)
{
	return errOk;//$ fix this
}


//! translates error codes to human readable error messages
inline const char *message(int index)
{
	assert(index >= 0 && index <= MAX_ERROR_CODE);
	return messagesTable[index];
}


} // namespace posixPAL::sockets
} // namespace posixPAL

namespace pal = posixPAL;

} // namespace lfc

#endif // __SOCKETS_POSIX_PAL_HPP__

