#!/usr/python
# -*- coding: utf-8 -*-

#
#	Вывод строки в лог.
#
#	@author Додонов А.А.
#

from base import *

log_stream = file.LoadModule( "log_stream" );

log_stream.LogStream_CreateObject( "default".encode( 'ascii' ) );

log_stream.tstReset( "default".encode( 'ascii' ) , ( conf.workspace_path + "./log.log" ).encode( 'ascii' ) , 1 );

log_stream.tstOutputString( "default".encode( 'ascii' ) , "str".encode( 'ascii' ) );

log_stream.tstRelease( "default".encode( 'ascii' ) );

if( file.LoadFile( conf.workspace_path + "./log.log" ).encode( 'ascii' ) == "str".encode( 'ascii' ) ):
	print( "TEST PASSED" );
else:
	print( file.LoadFile( conf.workspace_path + "./log.log" ) );
	print( "ERROR" );