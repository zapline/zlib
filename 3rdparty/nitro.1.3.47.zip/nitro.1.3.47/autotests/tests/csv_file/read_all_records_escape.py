#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс чтения всего файла в масив (с экранированием).
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "1.csv" , string_utilities.StrToBytes( 'aaaa\r\n\"bb""bb"' , 'utf-8' ) );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstReadAllRecords( "default".encode( 'ascii' ) , 1 );

if( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value == 'bb"bb' and csv_file.tstGetCount() == 1 ):
	print( "TEST PASSED" );
else:
	print( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value );
	print( "ERROR" );