#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс записи нескольких рекордов.
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "1.csv" , string_utilities.StrToBytes( "aaaa\r\nbbbb" , 'utf-8' ) );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstSetField( 0 , "cccc".encode( 'ascii' ) , 4 );

csv_file.tstPushFields();

csv_file.tstSetField( 0 , "dddd".encode( 'ascii' ) , 4 );

csv_file.tstPushFields();

csv_file.tstAppendAllRecords( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value == 'aaaa' and ctypes.c_char_p( csv_file.tstGetField( 2 ) ).value == 'bbbb' and ctypes.c_char_p( csv_file.tstGetField( 3 ) ).value == 'cccc' and ctypes.c_char_p( csv_file.tstGetField( 4 ) ).value == 'dddd' ):
	print( "TEST PASSED" );
else:
	print( csv_file.tstGetCount() );
	print( ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value );
	print( ctypes.c_char_p( csv_file.tstGetField( 2 ) ).value );
	print( ctypes.c_char_p( csv_file.tstGetField( 3 ) ).value );
	print( ctypes.c_char_p( csv_file.tstGetField( 4 ) ).value );
	print( "ERROR" );