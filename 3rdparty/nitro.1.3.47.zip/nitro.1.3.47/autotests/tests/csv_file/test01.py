#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс для файла с содержимым a.
#
#	@author Додонов А.А.
#

from base import *

import time

file.WriteFile( conf.workspace_path + "1.csv" , 'a' );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstReadRecord( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value == "a" and csv_file.tstGetCount() == 1 ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );