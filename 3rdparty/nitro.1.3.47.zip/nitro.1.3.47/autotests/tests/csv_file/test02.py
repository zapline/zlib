#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс для файла с содержимым a,b.
#
#	@author Додонов А.А.
#

from base import *

file.WriteFile( conf.workspace_path + "1.csv" , 'a,b' );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstReadRecord( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value == "a" and ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value == "b" and csv_file.tstGetCount() == 2 ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );