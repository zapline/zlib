#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс для файла с полями, которые не влезают в буффер и их приходится читать из файла.
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "1.csv" , string_utilities.StrToBytes( "aaaa\r\nbbbb" , 'utf-8' ) );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstSetReadBufferSize( 2 );

csv_file.tstReadRecord( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecord( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value == 'bbbb' and csv_file.tstGetCount() == 2 ):
	print( "TEST PASSED" );
else:
	print( ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value );
	print( "ERROR" );