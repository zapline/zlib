#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс для файла с содержимым "a""b",c.
#
#	@author Додонов А.А.
#

from base import *

file.WriteFile( conf.workspace_path + "1.csv" , '"a""b",c' );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstReadRecord( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value == 'a""b' and ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value == "c" and csv_file.tstGetCount() == 2 ):
	print( "TEST PASSED" );
else:
	print( ctypes.c_char_p( csv_file.tstGetField( 0 ) ).value );
	print( ctypes.c_char_p( csv_file.tstGetField( 1 ) ).value );
	print( csv_file.tstGetCount() );
	print( "ERROR" );