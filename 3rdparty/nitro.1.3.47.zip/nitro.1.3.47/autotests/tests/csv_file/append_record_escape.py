#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс записи поля в файл (с экранированием).
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "1.csv" , string_utilities.StrToBytes( "aaaa\r\nbbbb".encode( 'ascii' ) , 'utf-8' ) );

csv_file = file.LoadModule( "csv_file" );

csv_file.CSVFile_CreateObject( "default".encode( 'ascii' ) );

csv_file.tstOpenFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.csv" ).encode( 'ascii' ) );

csv_file.tstSetField( 0 , 'cc"cc'.encode( 'ascii' ) , 5 );

csv_file.tstAppendRecord( "default".encode( 'ascii' ) , 1 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

csv_file.tstReadRecordTpl( "default".encode( 'ascii' ) , 0 );

if( ctypes.c_char_p( csv_file.tstGetField( 3 ) ).value == 'cc""cc' ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );