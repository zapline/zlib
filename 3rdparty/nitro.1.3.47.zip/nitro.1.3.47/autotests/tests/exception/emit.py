#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда все поля нормально хранятся в классе. 
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

exception = file.LoadModule( "exception" );

exception.exception_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

exception.tstSet( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "message" , 'utf-8' ) , 12345 );

if( ctypes.c_char_p( exception.tstWhat( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value == "message" and exception.tstCode( string_utilities.StrToBytes( "default" , 'utf-8' ) ) == 12345 ):
	print( "TEST PASSED" );
else:
	print( "value : " + ctypes.c_char_p( exception.tstWhat( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value );
	print( "ERROR" );