#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс загрузки библиотеки.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

exception = file.LoadModule( "exception" );
dynamic_lib_manager = file.LoadModule( "dynamic_lib_manager" );

exception.exception_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );
dynamic_lib_manager.DynamicLibManager_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );
dynamic_lib_manager.tstManagerLoadLibrary( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "exception.dll" , 'utf-8' ) );

dynamic_lib_manager.tstCall( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "msg" , 'utf-8' ) , 12345 );

if( ctypes.c_char_p( exception.tstWhat( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value == "msg" and exception.tstCode( string_utilities.StrToBytes( "default" , 'utf-8' ) ) == 12345 ):
	print( "TEST PASSED" );
else:
	print( ctypes.c_char_p( exception.tstWhat( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value );
	print( exception.tstCode( string_utilities.StrToBytes( "default" , 'utf-8' ) ) );
	print( "ERROR" );