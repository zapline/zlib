#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс создание таймера.
#
#	@author Додонов А.А.
#

from base import *

timer = file.LoadModule( "timer" );

timer.tstCreateTimer();

time.sleep( 0.1 );