#!/usr/python
# -*- coding: utf-8 -*-

#
#	Тест заключается в том чтобы заблокировать созданный мьютекс, а потом из созданного потока попытаться заблокировать его второй раз, и если это удастся, то переменная Result будет установлена в некорректное значение 1.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

mutex_abstraction = file.LoadModule( "mutex_abstraction" );

mutex_abstraction.MutexAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

mutex_abstraction.tstCreateMutex( string_utilities.StrToBytes( "default" , 'utf-8' ) );

mutex_abstraction.CreateBlockedThread();

time.sleep( 1 );

if( mutex_abstraction.tstGetResult() == 0 ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );