#!/usr/python
# -*- coding: utf-8 -*-

import 	sys , time

sys.path.append( sys.path[ 0 ] + "/../../core" );

import file , string_utilities