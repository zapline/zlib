#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда очищаем буффер.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

binary_data = file.LoadModule( "binary_data" );

binary_data.BinaryData_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

binary_data.tstAppendData1( string_utilities.StrToBytes( "default" , 'utf-8' ) , "1234567890" );

binary_data.tstRelease( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( binary_data.tstGetBufferLength( string_utilities.StrToBytes( "default" , 'utf-8' ) ) == 0 ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );