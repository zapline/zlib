#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда добавляем произвольный буффер.
#
#	@author Додонов А.А.
#

from base import *

#binary_data = file.LoadModule( "binary_data" );

binary_data = ctypes.CDLL( "binary_data" );

'''binary_data.BinaryData_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

binary_data.tstAppendData2( string_utilities.StrToBytes( "default" , 'utf-8' ) , "1234\0" , len( "1234\0" ) );

if( binary_data.tstGetBufferLength( string_utilities.StrToBytes( "default" , 'utf-8' ) ) != len( "1234" ) ):
	print( "ERROR" );
	print( "buffer length : " + str( binary_data.tstGetBufferLength( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ) );
	print( "buffer content : " + ctypes.c_char_p( binary_data.tstGetBuffer( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value );
	
if( ctypes.c_char_p( binary_data.tstGetBuffer( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value != "1234" ):
		print( "ERROR" );
		print( "buffer length : " + str( binary_data.tstGetBufferLength( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ) );
		print( "buffer content : " + ctypes.c_char_p( binary_data.tstGetBuffer( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value );
		'''
print( "TEST PASSED" );