#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда устанавливаем конкретный байт.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

binary_data = file.LoadModule( "binary_data" );

binary_data.BinaryData_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

binary_data.tstAppendData2( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "12345\0" , 'utf-8' ) , 6 );

binary_data.tstSetByte( string_utilities.StrToBytes( "default" , 'utf-8' ) , 0 , ord( '6' ) );
binary_data.tstSetByte( string_utilities.StrToBytes( "default" , 'utf-8' ) , 1 , ord( '6' ) );
binary_data.tstSetByte( string_utilities.StrToBytes( "default" , 'utf-8' ) , 2 , ord( '6' ) );
binary_data.tstSetByte( string_utilities.StrToBytes( "default" , 'utf-8' ) , 3 , ord( '6' ) );
binary_data.tstSetByte( string_utilities.StrToBytes( "default" , 'utf-8' ) , 4 , ord( '6' ) );

if( ctypes.c_char_p( binary_data.tstGetBuffer( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value == "66666" ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );
	print( "buffer length : " + str( binary_data.tstGetBufferLength( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ) );
	print( "buffer content : " + ctypes.c_char_p( binary_data.tstGetBuffer( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value );