#!/usr/python
# -*- coding: utf-8 -*-

#
#	Дата последней модификации файла.
#
#	@author Додонов А.А.
#

from base import *

file_utilities = file.LoadModule( "file_utilities" );

file_utilities.tstForceCreateFile( ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) );

statinfo = os.stat( conf.workspace_path + "dir1/dir2/1.txt" );
Year = datetime.datetime.fromtimestamp( statinfo.st_mtime ).year;
Month = datetime.datetime.fromtimestamp( statinfo.st_mtime ).month;
Day = datetime.datetime.fromtimestamp( statinfo.st_mtime ).day;
Hour = datetime.datetime.fromtimestamp( statinfo.st_mtime ).hour;
Minute = datetime.datetime.fromtimestamp( statinfo.st_mtime ).minute;
Second = datetime.datetime.fromtimestamp( statinfo.st_mtime ).second;

if( ctypes.c_char_p( file_utilities.tstGetLastModified( ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) ) ).value == str( Year ) + str( Month - 1 ) + str( Day ) + str( Hour ) + str( Minute ) + str( Second ) ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );