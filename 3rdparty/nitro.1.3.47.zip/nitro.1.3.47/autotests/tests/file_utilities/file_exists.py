#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверка существования файла.
#
#	@author Додонов А.А.
#

from base import *

file_utilities = file.LoadModule( "file_utilities" );

file_utilities.tstForceCreateFile( ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) );

if( ctypes.c_byte( file_utilities.tstFileExists( ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) ) ).value == 0 ):
	print( "ERROR" );
else:
	print( "TEST PASSED" );