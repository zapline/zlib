#!/usr/python
# -*- coding: utf-8 -*-

#
#	Добавление строки в файл.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

file_utilities = file.LoadModule( "file_utilities" );

file_utilities.File_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_utilities.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_utilities.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "12345" , 'utf-8' ) );

file_utilities.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "67890" , 'utf-8' ) );

file_utilities.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( file.LoadFile( conf.workspace_path + "1.txt" ) == "1234567890" ):
	print( "TEST PASSED" );
else:
	print( "ERROR " + file.LoadFile( conf.workspace_path + "1.txt" ) );