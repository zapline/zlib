#!/usr/python
# -*- coding: utf-8 -*-

#
#	Принудительное создание файла.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

file_utilities = file.LoadModule( "file_utilities" );

file_utilities.File_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_utilities.tstForceCreateFile( ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) );

file_utilities.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "dir1/dir2/1.txt" ).encode( 'ascii' ) , 8 );

file_utilities.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "12345" , 'utf-8' ) );

file_utilities.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "67890" , 'utf-8' ) );

file_utilities.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( file.LoadFile( conf.workspace_path + "dir1/dir2/1.txt" ) == "1234567890" ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );