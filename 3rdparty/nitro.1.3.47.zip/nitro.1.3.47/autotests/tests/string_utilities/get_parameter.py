#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется тесткейс выборки параметра.
#
#	@author Додонов А.А.
#

from base import *

parsers = file.LoadModule( "string_utilities" );

Buffer1 = ctypes.c_char_p( string_utilities.StrToBytes( "111" , 'utf-8' ) );
Buffer2 = ctypes.c_char_p( string_utilities.StrToBytes( "222" , 'utf-8' ) );
Buffer3 = ctypes.c_char_p( string_utilities.StrToBytes( "333" , 'utf-8' ) );

parsers.tstGetCommandLineParameter( string_utilities.StrToBytes( "-a a" , 'utf-8' ) , string_utilities.StrToBytes( "-a" , 'utf-8' ) , "" , Buffer1 );
parsers.tstGetCommandLineParameter( string_utilities.StrToBytes( '-a "b"' , 'utf-8' ) , string_utilities.StrToBytes( "-a" , 'utf-8' ) , "" , Buffer2 );
parsers.tstGetCommandLineParameter( string_utilities.StrToBytes( '-a "b b"' , 'utf-8' ) , string_utilities.StrToBytes( "-a" , 'utf-8' ) , "" , Buffer3 );

if( Buffer1.value == 'a' and Buffer2.value == 'b' and Buffer3.value == 'b b' ):
	print( "TEST PASSED" );
else:
	print( Buffer1.value );
	print( Buffer2.value );
	print( Buffer3.value );
	print( "ERROR" );