#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется тесткейс существования параметра в командной строке.
#
#	@author Додонов А.А.
#

from base import *

parsers = file.LoadModule( "string_utilities" );

if( ctypes.c_byte( parsers.tstCommandLineParameterExists( string_utilities.StrToBytes( "-a -b" , 'utf-8' ) , string_utilities.StrToBytes( "-a" , 'utf-8' ) ) ).value != 0 and ctypes.c_byte( parsers.tstCommandLineParameterExists( string_utilities.StrToBytes( "-a -b" , 'utf-8' ) , string_utilities.StrToBytes( "-b" , 'utf-8' ) ) ).value != 0 ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );