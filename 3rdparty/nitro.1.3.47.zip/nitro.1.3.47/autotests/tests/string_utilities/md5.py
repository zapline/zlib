#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется функцию md5.
#
#	@author Додонов А.А.
#

from base import *

import hashlib
m = hashlib.md5();
m.update( "abc".encode( 'ascii' ) );
Hash1 = m.hexdigest();

encoders = file.LoadModule( "string_utilities" );

Hash2 = ctypes.c_char_p( string_utilities.StrToBytes( "#################################" , 'utf-8' ) );

encoders.tstmd5( "abc".encode( 'ascii' ) , 3 , Hash2 );

if( Hash2.value == Hash1 ):
	print( "TEST PASSED" );
else:
	print( Hash.value );
	print( hd );
	print( "ERROR" );