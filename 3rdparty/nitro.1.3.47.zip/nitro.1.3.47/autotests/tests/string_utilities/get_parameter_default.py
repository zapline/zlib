#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется тесткейс выборки параметра (по-умолчанию).
#
#	@author Додонов А.А.
#

from base import *

parsers = file.LoadModule( "string_utilities" );

Buffer = ctypes.c_char_p( string_utilities.StrToBytes( "111" , 'utf-8' ) );

parsers.tstGetCommandLineParameter( string_utilities.StrToBytes( "-a a" , 'utf-8' ) , string_utilities.StrToBytes( "-unexisting" , 'utf-8' ) , string_utilities.StrToBytes( "123\0" , 'utf-8' ) , Buffer );

if( Buffer.value == "123" ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );