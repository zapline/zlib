#!/usr/python
# -*- coding: utf-8 -*-

#
#	Принудительное создание директории.
#
#	@author Додонов А.А.
#

from base import *

#	создаем тестовые данные
directory_utilities = file.LoadModule( "directory_utilities" );

directory_utilities.tstForceCreateDirectory( ( conf.workspace_path + "dir1/dir2/dir3" ).encode( 'ascii' ) );

if( os.access( conf.workspace_path + "dir1" , os.F_OK ) and os.access( conf.workspace_path + "dir1/dir2" , os.F_OK ) and os.access( conf.workspace_path + "dir1/dir2/dir3" , os.F_OK ) ):
	print( "TEST PASSED" );
else:
	print( "dir1 : " + str( os.access( conf.workspace_path + "dir1" , os.F_OK ) ) );
	print( "dir2 : " + str( os.access( conf.workspace_path + "dir1/dir2" , os.F_OK ) ) );
	print( "dir3 : " + str( os.access( conf.workspace_path + "dir1/dir2/dir3" , os.F_OK ) ) );
	print( "ERROR" );