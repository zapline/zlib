#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем существование диреткории.
#
#	@author Додонов А.А.
#

from base import *

#	создаем тестовые данные
directory_utilities = file.LoadModule( "directory_utilities" );

os.mkdir( conf.workspace_path + "dir" );

if( ctypes.c_byte( directory_utilities.tstDirectoryExists( ( conf.workspace_path + "dir" ).encode( 'ascii' ) ) ).value ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );