#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем существование диреткории.
#
#	@author Додонов А.А.
#

from base import *

import	os.path

#	создаем тестовые данные
directory_utilities = file.LoadModule( "directory_utilities" );

print( os.path.exists( conf.workspace_path + "dir" ) );
print( ctypes.c_byte( directory_utilities.tstDirectoryExists( ( conf.workspace_path + "dir/" ).encode( 'ascii' ) ) ).value );

if( ctypes.c_byte( directory_utilities.tstDirectoryExists( ( conf.workspace_path + "dir" ).encode( 'ascii' ) ) ).value ):
	print( "ERROR" );
else:
	print( "TEST PASSED" );