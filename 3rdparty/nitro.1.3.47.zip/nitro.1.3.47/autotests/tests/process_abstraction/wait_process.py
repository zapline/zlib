#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем ожидание процесса.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

process_abstraction = file.LoadModule( "process_abstraction" );

process_abstraction.ProcessAbstraction_CreateObject( "default".encode( 'ascii' ) );

StartTime = time.time();

if( utilities.GetPlatform() == "Windows" or utilities.GetPlatform().find( 'CYGWIN' ) != -1 ):
	process_abstraction.tstCreateProcessUtil( "default".encode( 'ascii' ) , "python.exe".encode( 'ascii' ) , "./tests/process_abstraction/sleep.py".encode( 'ascii' ) );
else:
	process_abstraction.tstCreateProcessUtil( "default".encode( 'ascii' ) , "python".encode( 'ascii' ) , "./tests/process_abstraction/sleep.py" );
	
process_abstraction.tstWait( "default".encode( 'ascii' ) );
diff = time.time() - StartTime;
if( diff > 2.0 ):
	print( 'TEST PASSED' );
else:
	print( 'ERROR' );