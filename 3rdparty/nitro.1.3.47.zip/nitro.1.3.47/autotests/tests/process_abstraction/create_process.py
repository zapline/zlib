#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем создание процесса.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

process_abstraction = file.LoadModule( "process_abstraction" );

process_abstraction.ProcessAbstraction_CreateObject( "default".encode( 'ascii' ) );

if( utilities.GetPlatform() == "Windows" or utilities.GetPlatform().find( 'CYGWIN' ) != -1 ):
	process_abstraction.tstCreateProcessUtil( "default".encode( 'ascii' ) , "python.exe".encode( 'ascii' ) , "./tests/process_abstraction/test_passed.py".encode( 'ascii' ) );
else:
	process_abstraction.tstCreateProcessUtil( "default".encode( 'ascii' ) , "python".encode( 'ascii' ) , "./tests/process_abstraction/test_passed.py" );
	
time.sleep( 1 );