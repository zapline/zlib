#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем прерывание процесса.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

process_abstraction = file.LoadModule( "process_abstraction" );

process_abstraction.ProcessAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

StartTime = time.clock();

if( utilities.GetPlatform() == "Windows" or utilities.GetPlatform().find( 'CYGWIN' ) != -1 ):
	process_abstraction.tstCreateProcess( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "python.exe" , 'utf-8' ) , 0 );
else:
	process_abstraction.tstCreateProcess( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "python" , 'utf-8' ) , 0 );

try:
	process_abstraction.tstTerminateProcess( string_utilities.StrToBytes( "default" , 'utf-8' ) );
	
	print( 'TEST PASSED' );
except:
	print( 'ERROR' );