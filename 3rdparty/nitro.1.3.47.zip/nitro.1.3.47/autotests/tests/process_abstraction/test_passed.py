#!/usr/python
# -*- coding: utf-8 -*-

print( 'TEST PASSED' );