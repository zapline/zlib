#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда файл существует и открывается на запись с добавлением в конец. Файл не должен обрезаться
#
#	@author Додонов А.А.
#

from base import *

import		file , string_utilities

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "123456789" , 'utf-8' ) , 9 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

# к этому моменту файл уже существует
file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 + 16 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "987654321" , 'utf-8' ) , 9 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( file.LoadFile( conf.workspace_path + "1.txt" ) == "123456789987654321" ):
	print( "TEST PASSED" )
else:
	print( file.LoadFile( conf.workspace_path + "1.txt" ) );
	print( "<br>" );
	print( "ERROR" );