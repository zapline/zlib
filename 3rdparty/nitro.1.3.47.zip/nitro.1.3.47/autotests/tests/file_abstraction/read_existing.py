#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда файл существует и открывается на чтение. Файл должен открыться. 
#	Чтение содержимого файла должно корректно осуществляться.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "123456789" , 'utf-8' ) , 9 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

# к этому моменту файл уже существует
file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 4 );

Buffer = ctypes.c_char_p( string_utilities.StrToBytes( "#########" , 'utf-8' ) );

file_abstraction.tstRead( string_utilities.StrToBytes( "default" , 'utf-8' ) , Buffer , 9 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( Buffer.value == "123456789" ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );