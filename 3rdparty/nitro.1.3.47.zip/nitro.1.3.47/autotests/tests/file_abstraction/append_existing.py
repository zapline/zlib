#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда файл существует и открывается на добавление в конец. Файл должен открыться. 
#	Запись должна корректно осуществляться.
#
#	@author Додонов А.А.
#

from base import *

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( "default".encode( 'ascii' ) );

file_abstraction.tstOpen( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_abstraction.tstWrite( "default".encode( 'ascii' ) , "12345".encode( 'ascii' ) , 5 );

file_abstraction.tstClose( "default".encode( 'ascii' ) );

file_abstraction.tstOpen( "default".encode( 'ascii' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 16 + 8 );

file_abstraction.tstWrite( "default".encode( 'ascii' ) , "67890".encode( 'ascii' ) , 5 );

file_abstraction.tstClose( "default".encode( 'ascii' ) );

if( str( file.LoadFile( conf.workspace_path + "1.txt" ) ) == "1234567890" ):
	print( "TEST PASSED" );
else:
	print( "File content : " + str( file.LoadFile( conf.workspace_path + "1.txt" ) ) );
	print( "ERROR" );