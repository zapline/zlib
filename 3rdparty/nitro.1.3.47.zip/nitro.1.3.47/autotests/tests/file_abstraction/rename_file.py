#!/usr/python
# -*- coding: utf-8 -*-

#
#	Переименование файла.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "12345" , 'utf-8' ) , 5 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "67890" , 'utf-8' ) , 5 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstRenameFile( ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , ( conf.workspace_path + "2.txt" ).encode( 'ascii' ) );

if( file.LoadFile( conf.workspace_path + "2.txt" ) == "1234567890" ):
	print( "TEST PASSED" );
else:
	print( "1.txt : " + file.LoadFile( conf.workspace_path + "1.txt" ) )
	print( "2.txt : " + file.LoadFile( conf.workspace_path + "2.txt" ) )
	print( "ERROR" );