#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда файл не существует и открывается на добавление в конец. Файл должен открыться. 
#	Запись должна корректно осуществляться.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 + 16 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "12345" , 'utf-8' ) , 5 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

# к этому моменту файл уже существует и можно спокойно читать
file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 4 );

Buffer = ctypes.c_char_p( string_utilities.StrToBytes( "#####" , 'utf-8' ) );

file_abstraction.tstRead( string_utilities.StrToBytes( "default" , 'utf-8' ) , Buffer , 5 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( Buffer.value == "12345" ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );