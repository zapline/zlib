#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда файл не существует но открывается на запись. Файл должен создаться. И запись в 
#	файл должна корректно осуществляться.
#
#	@author Додонов А.А.
#

from base import *

import file

file_abstraction = file.LoadModule( "file_abstraction" );

file_abstraction.FileAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file_abstraction.tstOpen( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "1.txt" ).encode( 'ascii' ) , 8 );

file_abstraction.tstWrite( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "123456789" , 'utf-8' ) , 9 );

file_abstraction.tstClose( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( file.LoadFile( conf.workspace_path + "1.txt" ) == "123456789" ):
	print( "TEST PASSED" )
else:
	print( "ERROR" );