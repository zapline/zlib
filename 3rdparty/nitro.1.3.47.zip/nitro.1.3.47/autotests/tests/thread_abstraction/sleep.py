#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс для функции sleep.
#
#	@author Додонов А.А.
#

from base import *

import	time

thread_abstraction = file.LoadModule( "thread_abstraction" );

StartTime = time.time();

thread_abstraction.tstSleep( 2000 );

if( time.time() - StartTime >= 2.0 ):
	print( 'TEST PASSED' );
else:
	print( 'ERROR' );