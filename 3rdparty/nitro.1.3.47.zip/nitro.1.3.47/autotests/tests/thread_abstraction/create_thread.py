#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс создание потока.
#
#	@author Додонов А.А.
#

from base import *

thread_abstraction = file.LoadModule( "thread_abstraction" );

thread_abstraction.ThreadAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

thread_abstraction.tstCreateThread( 1 );