#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс прерывания потока.
#
#	@author Додонов А.А.
#

from base import *

thread_abstraction = file.LoadModule( "thread_abstraction" );

thread_abstraction.ThreadAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

thread_abstraction.tstCreateThread( 2 );

time.sleep( 0.1 );

thread_abstraction.tstTerminateThread( string_utilities.StrToBytes( "default" , 'utf-8' ) );