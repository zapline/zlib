#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется работа функции ResourceExists
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

dynamic_lib_loader = file.LoadModule( "dynamic_lib_loader" );

dynamic_lib_loader.DynamicLibLoader_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

dynamic_lib_loader.tstLoadLibrary( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.bin_modules_path + "dynamic_lib_loader.dll" ).encode( 'ascii' ) );

Value = dynamic_lib_loader.tstResourceExists( string_utilities.StrToBytes( "default" , 'utf-8' ) , '1234' );

if( Value != 0 ):
	print( Value );
	print( 'ERROR' );

Value = dynamic_lib_loader.tstResourceExists( string_utilities.StrToBytes( "default" , 'utf-8' ) , 'tstResourceExists' );

if( Value == 0 ):
	print( Value );
	print( 'ERROR' );

print( 'TEST PASSED' );