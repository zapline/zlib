#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяется загрузка динамической библиотеки и запуск функции из неё.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

dynamic_lib_loader = file.LoadModule( "dynamic_lib_loader" );

dynamic_lib_loader.DynamicLibLoader_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

dynamic_lib_loader.tstLoadLibrary( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.bin_modules_path + "dynamic_lib_loader.dll" ).encode( 'ascii' ) );

Value = dynamic_lib_loader.tstTestCase1( string_utilities.StrToBytes( "default" , 'utf-8' ) );

dynamic_lib_loader.tstRelease( string_utilities.StrToBytes( "default" , 'utf-8' ) );

if( Value == 12345 ):
	print( "TEST PASSED" );
else:
	print( Value );
	print( "ERROR" );