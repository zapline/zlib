#!/usr/python
# -*- coding: utf-8 -*-

#
#	Test case : zipping directory.
#
#	@author Dodonov A.A.
#

from base import *

import 	os , zipfile

zip_utilities = file.LoadModule( "zip_utilities" );

os.mkdir( conf.workspace_path + "dir" );
file.WriteFile( conf.workspace_path + "dir/file1.txt" , "111" );
file.WriteFile( conf.workspace_path + "dir/file2.txt" , "222" );

zip_utilities.tstArchiveDirectory( ( conf.workspace_path + "arc.zip" ).encode( 'ascii' ) , ( conf.workspace_path + "dir/" ).encode( 'ascii' ) );

Arc = zipfile.ZipFile( conf.workspace_path + "arc.zip" , 'r' );
if( len( Arc.namelist() ) == 2 ):
	print( "TEST PASSED" );
else:
	print( "ERROR : " );
	print( len( Arc.namelist() ) );