#!/usr/python
# -*- coding: utf-8 -*-

#
#	Test case : unzipping archive into directory.
#
#	@author Dodonov A.A.
#

from base import *

import 	os , zipfile

zip_utilities = file.LoadModule( "zip_utilities" );

Arc = zipfile.ZipFile( conf.workspace_path + "arc.zip" , 'w' );
Arc.writestr( "file1.txt" , "111" );
Arc.writestr( "file2.txt" , "222" );
Arc.close();

zip_utilities.tstExtractFiles( ( conf.workspace_path + "arc.zip" ).encode( 'ascii' ) , ( conf.workspace_path + "dir/" ).encode( 'ascii' ) );

if( os.access( conf.workspace_path + "dir/file1.txt" , os.F_OK ) and os.access( conf.workspace_path + "dir/file2.txt" , os.F_OK ) ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );