#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем созранение ini файла.
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "./1.ini" , string_utilities.StrToBytes( "[section]\r\nkey=123" , 'utf-8' ) );

ini_file = file.LoadModule( "ini_file" );

ini_file.INIFile_CreateObject( "default".encode( 'ascii' ) );

ini_file.tstLoadINIFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "./1.ini" ).encode( 'ascii' ) );

Buffer = ctypes.c_char_p( "\0\0\0\0" );

ini_file.tstSetString( "default".encode( 'ascii' ) , "section".encode( 'ascii' ) , "key".encode( 'ascii' ) , "456\0".encode( 'ascii' ) )

ini_file.tstSaveINIFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "./1.ini" ).encode( 'ascii' ) );

ini_file.tstLoadINIFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "./1.ini" ).encode( 'ascii' ) );

if( ctypes.c_char_p( ini_file.tstGetString( "default".encode( 'ascii' ) , "section".encode( 'ascii' ) , "key".encode( 'ascii' ) , Buffer , "444\0".encode( 'ascii' ) ) ).value == '456' ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );