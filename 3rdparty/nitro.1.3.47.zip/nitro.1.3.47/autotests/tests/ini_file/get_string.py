#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем чтение строкового значения из ini файла.
#
#	@author Додонов А.А.
#

from base import *

file.WriteBinaryFile( conf.workspace_path + "./1.ini" , string_utilities.StrToBytes( "[section]\r\nkey=123" , 'utf-8' ) );

ini_file = file.LoadModule( "ini_file" );

ini_file.INIFile_CreateObject( "default".encode( 'ascii' ) );

ini_file.tstLoadINIFile( "default".encode( 'ascii' ) , ( conf.workspace_path + "./1.ini" ).encode( 'ascii' ) );

Buffer = ctypes.c_char_p( "\0\0\0\0" );

if( ctypes.c_char_p( ini_file.tstGetString( "default".encode( 'ascii' ) , "section".encode( 'ascii' ) , "key".encode( 'ascii' ) , Buffer , "444\0".encode( 'ascii' ) ) ).value == '123' ):
	print( "TEST PASSED" );
else:
	print( Buffer.value );
	print( "ERROR" );