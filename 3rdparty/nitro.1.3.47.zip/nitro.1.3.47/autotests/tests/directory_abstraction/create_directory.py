#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда бежим по директории и находим сначала файл file, а потом директорию dir.
#
#	@author Додонов А.А.
#

from base import *

import 		string_utilities

#	создаем тестовые данные
directory_abstraction = file.LoadModule( "directory_abstraction" );

directory_abstraction.tstCreateDirectory( ( conf.workspace_path + "dir/" ).encode( 'ascii' ) );

if( os.access( conf.workspace_path + "dir" , os.F_OK ) ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );