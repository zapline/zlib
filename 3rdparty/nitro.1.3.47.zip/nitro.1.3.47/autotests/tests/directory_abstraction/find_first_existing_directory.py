#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда директория существует и мы находим её.
#
#	@author Додонов А.А.
#

from base import *

import 		time , string_utilities

#	создаем тестовые данные
directory_abstraction = file.LoadModule( "directory_abstraction" );

directory_abstraction.DirectoryAbstraction_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

#	создаем директорию, чьё существование будем проверять
os.mkdir( conf.workspace_path + "test_dir" );

#	запускаем тестовый стенд и проверяем результат, с которым стенд отработал
if( directory_abstraction.tstFindFirst( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "test_dir" ).encode( 'ascii' ) ) == 0 ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );