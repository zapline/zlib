#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда бежим по директории и находим сначала файл file, а потом директорию dir.
#
#	@author Додонов А.А.
#

from base import *

import		string_utilities

#	создаем тестовые данные
directory_abstraction = file.LoadModule( "directory_abstraction" );

directory_abstraction.DirectoryAbstraction_CreateObject( "default".encode( 'ascii' ) );

os.mkdir( conf.workspace_path + "get_name" );

#	создаем директорию
os.mkdir( conf.workspace_path + "get_name/dir" );

#	создаем файл
FStream = open( conf.workspace_path + "get_name/file" , "wb" );
FStream.close();

print( conf.workspace_path );

#	запускаем тестовый стенд и проверяем результат, с которым стенд отработал
if( directory_abstraction.tstFindFirst( "default".encode( 'ascii' ) , ( conf.workspace_path + "get_name/" ).encode( 'ascii' ) ) == 1 ):
	print( "ERROR (28)" );
	sys.exit( 1 );

Counter = 0;
	
while directory_abstraction.tstFindNext( "default".encode( 'ascii' ) ) == 0:
	EntityName = ctypes.c_char_p( directory_abstraction.tstGetName( "default".encode( 'ascii' ) ) ).value;
	print( EntityName );
	if( ( EntityName == '.' or EntityName == '..' ) and directory_abstraction.tstIsDots( "default".encode( 'ascii' ) ) ):
		Counter = Counter + 1;
		continue;
	if( EntityName == 'file' and directory_abstraction.tstIsFile( "default".encode( 'ascii' ) ) ):
		Counter = Counter + 1;
		continue;
	if( EntityName == 'dir' and directory_abstraction.tstIsDirectory( "default".encode( 'ascii' ) ) ):
		Counter = Counter + 1;
		continue;
		
	Counter = Counter + 1;
	print( EntityName );

if( Counter == 3 ):
	print( "TEST PASSED" );
else:
	print( Counter );
	print( "ERROR" );