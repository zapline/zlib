#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс, когда шаблон грузится из файла.
#
#	@author Додонов А.А.
#

from base import *

template_engine = file.LoadModule( "template_engine" );

template_engine.TemplateEngine_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file.WriteBinaryFile( conf.workspace_path + "template.tpl" , string_utilities.StrToBytes( "{var}\0" , 'utf-8' ) );

template_engine.tstLoadTemplateFromFile( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "template.tpl" ).encode( 'ascii' ) );

#print( file.LoadFile( conf.workspace_path + "template.tpl" ) );

Buffer = ctypes.c_char_p( template_engine.tstGetTemplate( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value;

if( Buffer == '{var}' ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );