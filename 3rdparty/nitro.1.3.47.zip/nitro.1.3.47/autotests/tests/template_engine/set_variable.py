#!/usr/python
# -*- coding: utf-8 -*-

#
#	Проверяем тесткейс установки значения переменной в шаблоне.
#
#	@author Додонов А.А.
#

from base import *

template_engine = file.LoadModule( "template_engine" );

template_engine.TemplateEngine_CreateObject( string_utilities.StrToBytes( "default" , 'utf-8' ) );

file.WriteBinaryFile( ( conf.workspace_path + "template.tpl" ).encode( 'ascii' ) , string_utilities.StrToBytes( "{var}\0" , 'utf-8' ) );

template_engine.tstLoadTemplateFromFile( string_utilities.StrToBytes( "default" , 'utf-8' ) , ( conf.workspace_path + "template.tpl" ).encode( 'ascii' ) );

template_engine.tstSetVariable( string_utilities.StrToBytes( "default" , 'utf-8' ) , string_utilities.StrToBytes( "var" , 'utf-8' ) , string_utilities.StrToBytes( "val" , 'utf-8' ) );

Buffer = ctypes.c_char_p( template_engine.tstGetTemplate( string_utilities.StrToBytes( "default" , 'utf-8' ) ) ).value;

if( Buffer == "val" ):
	print( "TEST PASSED" );
else:
	print( "ERROR" );