#!/usr/python
# -*- coding: utf-8 -*-

autotesting_start_time = "Time of the autotesting start";
file = "File";
result="Result";
tester="Tester";
testers_email="Tester's email";
total_statistics="Basic statistics"
total_tests="Total tests count";
total_error_tests="Total tests count, finished with error";
total_success_tests="Total tests count, successfully finished";
per_tester_statistics="Statistics for each tester";
tester_error="Count of tests finished with error";
tester_success="Count of tests finished successfully";
autotesting_start_time_label="Time when the autotesting was started : "
autotesting_end_time_label="Time when the autotesting was finished : "
description="Description"
autotesting_time_label="Total testing time : "
execution_time="Execution&nbsp;time"
avg_execution_time="Average&nbsp;execution&nbsp;time"
testing_mail_subject="Testing log (no reply)"