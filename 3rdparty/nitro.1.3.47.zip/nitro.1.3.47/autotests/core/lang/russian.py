#!/usr/python
# -*- coding: utf-8 -*-

autotesting_start_time = "Старт автотестирования";
file = "Файл";
result="Результат";
tester="Тестировщик";
testers_email="Email&nbsp;тестировшика";
total_statistics="Общая статистика по тестированию"
total_tests="Всего тестов";
total_error_tests="Общее количество тестов, завершенных с ошибкой";
total_success_tests="Общее количество тестов, завершенных успешно";
per_tester_statistics="Статистика по тестировщикам";
tester_error="Количество тестов, завершенных с ошибкой";
tester_success="Количество тестов, завершенных успешно";
autotesting_start_time_label="Время начала тестирования : "
autotesting_end_time_label="Время окончания тестирования : "
description="Описание"
autotesting_time_label="Общее время тестирования : "
execution_time="Время&nbsp;выполнения"
avg_execution_time="Среднее&nbsp;время&nbsp;выполнения"
testing_mail_subject="Лог тестирования (no reply)"