<?php

	if( @$_POST[ 'action' ] == 'get_sub_test_count' )
	{
		print( 2 );
		exit( 0 );
	}

	if( @$_POST[ 'action' ] == 'run_sub_test' )
	{
		if( @$_POST[ 'test_id' ] == 0 )
		{
			print( 'TEST PASSED' );
			exit( 0 );
		}
		if( @$_POST[ 'test_id' ] == 1 )
		{
			print( 'ERROR OCCURED' );
			exit( 0 );
		}
	}
	if( @$_POST[ 'action' ] == 'get_sub_test_name' )
	{
		if( @$_POST[ 'test_id' ] == 0 )
		{
			print( 'test#1' );
			exit( 0 );
		}
		if( @$_POST[ 'test_id' ] == 1 )
		{
			print( 'test#2' );
			exit( 0 );
		}
	}
	print( 'Invalid request parameters' );

?>