#ifndef		__MAIN_FRAME_CPP__
#define		__MAIN_FRAME_CPP__

#include	<utilities/mvc/mvc_core.h>

#include	<wx/wx.h>
#include	<wx/image.h>
#include	<wx/treectrl.h>
#include	<wx/wfstream.h>

#include	"common_frame.h"

class						CommonFrame: public wxFrame
{
public:
	
	CommonFrame( wxWindow * Parent , const wxString & Title , const wxPoint & Position , const wxSize & Size , const wxString & IconPath , const wxString & ClientViewComponent );

	void						OnQuit( wxCommandEvent & Event );
	
	void						OnClose( wxCloseEvent & Event );

	DECLARE_EVENT_TABLE()
};

enum
{
	ID_Quit = 1
};

CommonFrame::CommonFrame( wxWindow * Parent , const wxString & Title , 
						  const wxPoint & Position , const wxSize & Size , 
						  const wxString & IconPath , const wxString & ClientViewComponent ) : wxFrame( Parent , -1 , Title , Position , Size )
{
	try
	{
		wxInitAllImageHandlers();

		wxMenu *MenuFile = new wxMenu;
		MenuFile->Append( ID_Quit, "�����" );
		
		wxMenuBar *MenuBar = new wxMenuBar;
		MenuBar->Append( MenuFile, "����" );
		
		SetMenuBar( MenuBar );

		if( ClientViewComponent != "" )
		{
			wxBoxSizer * MainSizer( new wxBoxSizer( wxVERTICAL ) );

			MainSizer->Add( ( wxPanel * )nitro::GetMainMVCObject()->GetView( ClientViewComponent.c_str() )->GetGUI( NULL , ( wxWindow * )this ) , 1 , wxEXPAND | wxALL , 0 );

			SetSizer( MainSizer );

			MainSizer->SetSizeHints( this );
		}

		CreateStatusBar();

		SetStatusText( "Welcome to Report Builder" );

		Centre();

		// ������������� ������
		if( IconPath != "" )
		{
			wxFileStream			FileStream( IconPath );
			wxImage					Image( FileStream );
			wxBitmap				Bitmap( Image );
			wxIcon					Icon;
			Icon.CopyFromBitmap( Bitmap );
			SetIcon( Icon );
		}

		Show( TRUE );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "CommonFrame::CommonFrame( wxWindow * Parent , const wxString & Title , const wxPoint & Position , const wxSize & Size , const wxString & IconPath ) : wxFrame( Parent , -1 , Title , Position , Size )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "CommonFrame::CommonFrame( wxWindow * Parent , const wxString & Title , const wxPoint & Position , const wxSize & Size , const wxString & IconPath ) : wxFrame( Parent , -1 , Title , Position , Size )::An error occured" , 1 ) );
	}
}

void						CommonFrame::OnQuit( wxCommandEvent & WXUNUSED( Event ) )
{
	nitro::GetMainMVCObject()->ExecuteCommand( "close_app" );
}

void						CommonFrame::OnClose( wxCloseEvent & WXUNUSED( Event ) )
{
	nitro::GetMainMVCObject()->ExecuteCommand( "close_app" );
}

BEGIN_EVENT_TABLE( CommonFrame , wxFrame )
	EVT_MENU( ID_Quit , CommonFrame::OnQuit )
	EVT_CLOSE( CommonFrame::OnClose )
END_EVENT_TABLE()

CommonFrameView::CommonFrameView( const nitro::XMLTag & ManifestPart )
{
	try
	{
		Title = "";
		IconPath = "";
		ClientViewComponentName = "";
		Panel = NULL;

		if( ManifestPart.AttributeExists( "title" ) )
		{
			Title = ManifestPart.GetAttribute_string( "title" );
		}

		if( ManifestPart.AttributeExists( "icon_path" ) )
		{
			IconPath = ManifestPart.GetAttribute_string( "icon_path" );
		}

		if( ManifestPart.AttributeExists( "client_view_component_name" ) )
		{
			ClientViewComponentName = ManifestPart.GetAttribute_string( "client_view_component_name" );
		}
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "CommonFrameView::CommonFrameView( const nitro::XMLTag & ManifestPart )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "CommonFrameView::CommonFrameView( const nitro::XMLTag & ManifestPart )::An error occured" , 1 ) );
	}
}

/* virtual */ void *		CommonFrameView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )
{
	try
	{
		Frame = ( void * )( wxWindow * )new CommonFrame( ( wxWindow * ) Parent , Title , wxPoint( 0 , 0 ) , wxSize( 400 , 400 ) , IconPath , ClientViewComponentName );
		return( Frame );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "CommonFrameView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "CommonFrameView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )::An error occured" , 1 ) );
	}
}

/* virtual */ bool			CommonFrameView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )
{
	try
	{
		if( Penel != NULL )
		{
		}
		else
		{
			return( true );
		}
		return( true );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "CommonFrameView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "CommonFrameView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )::An error occured" , 1 ) );
	}
}

/* virtual */ CommonFrameView::~CommonFrameView()
{
}

#endif
