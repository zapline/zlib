#include	<string>

#include	<windows.h>

#include	<utilities/exception.h>
#include	<utilities/mvc/mvc.h>

int WINAPI WinMain( HINSTANCE hInstance , HINSTANCE hPrevInstance , LPSTR lpCmdLine , int nCmdShow )
{
	try
	{
		nitro::GetMainMVCObject()->Create();
		return( nitro::GetMainMVCObject()->Entry( MAIN_FUNC_VALUES_LIST ) );
	}
	catch( nitro::exception e )
	{
		MessageBox( 0 , e.what() , "Error" , MB_OK | MB_ICONSTOP );
	}
	catch( ... )
	{
		MessageBox( 0 , "Exception was caught" , "Error" , MB_OK | MB_ICONSTOP );
	}

	return( 0 );
}
