#ifndef		__MAIN_FRAME_CPP__
#define		__MAIN_FRAME_CPP__

#include	<utilities/mvc/mvc_core.h>

#include	<wx/wx.h>
#include	<wx/image.h>
#include	<wx/notebook.h>
#include	<wx/wfstream.h>

#include	"tabbed_panel.h"

class						TabbedPanel: public wxPanel
{
public:
	
	TabbedPanel( wxWindow * Parent , std::vector< std::string > & Views , std::vector< std::string > & TabTitles );

	virtual ~TabbedPanel();

private:

	wxNotebook *				TabControl;
};

TabbedPanel::TabbedPanel( wxWindow * Parent , std::vector< std::string > & Views , std::vector< std::string > & TabTitles ) : wxPanel( Parent )
{
	try
	{
		wxBoxSizer * MainSizer( new wxBoxSizer( wxVERTICAL ) );

		TabControl = new wxNotebook( this , -1 , wxDefaultPosition , wxDefaultSize , wxNB_TOP  );

		for( std::size_t i( 0 ) ; i < Views.size() ; i++ )
		{
			TabControl->AddPage( ( wxWindow * )nitro::GetMainMVCObject()->GetView( Views[ i ].c_str() )->GetGUI( NULL , ( void * )TabControl ) , TabTitles[ i ] );
		}

		MainSizer->Add( TabControl , 1 , wxEXPAND | wxALL , 0 );

		SetSizer( MainSizer );

		MainSizer->SetSizeHints( this );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "TabbedPanel::TabbedPanel( wxWindow * Parent , std::string & Views ) : wxPanel( Parent )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "TabbedPanel::TabbedPanel( wxWindow * Parent , std::string & Views ) : wxPanel( Parent )::An error occured" , 1 ) );
	}
}

/* virtual */ TabbedPanel::~TabbedPanel()
{
	delete TabControl;
}

TabbedPanelView::TabbedPanelView( const nitro::XMLTag & ManifestPart )
{
	try
	{
		Panel = NULL;
		if( ManifestPart.TagExists( "tabs" ) )
		{
			for( std::size_t i( 0 ) ; i < ManifestPart[ "tabs" ].CountOfChildTags() ; i++ )
			{
				if( ManifestPart[ "tabs" ][ i ].Name == "tab" )
				{
					Views.push_back( std::string( ManifestPart[ "tabs" ][ i ].GetAttribute_string( "component" ) ) );
					TabTitles.push_back( std::string( ManifestPart[ "tabs" ][ i ].GetAttribute_string( "tab_title" ) ) );
				}
			}
		}
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "TabbedPanelView::TabbedPanelView( const nitro::XMLTag & ManifestPart )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "TabbedPanelView::TabbedPanelView( const nitro::XMLTag & ManifestPart )::An error occured" , 1 ) );
	}
}

/* virtual */ void *		TabbedPanelView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )
{
	try
	{
		Panel = ( void * )( wxWindow * )new TabbedPanel( ( wxWindow * ) Parent , Views , TabTitles );
		return( Panel );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "TabbedPanelView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "TabbedPanelView::GetGUI( const char * ViewName /* = NULL */ , void * Parent /* = NULL */ )::An error occured" , 1 ) );
	}
}

/* virtual */ bool			TabbedPanelView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )
{
	try
	{
		if( Penel != NULL )
		{
		}
		else
		{
			return( true );
		}
		return( true );
	}
	catch( nitro::exception e )
	{
		throw( nitro::exception( std::string( "TabbedPanelView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )::" ) + e.what() , e.code() ) );
	}
	catch( ... )
	{
		throw( nitro::exception( "TabbedPanelView::ExecuteCommand( const char * Command , const void * Param1 /* = NULL */ , const void * Param2 /* = NULL */ )::An error occured" , 1 ) );
	}
}

/* virtual */ TabbedPanelView::~TabbedPanelView()
{
	//delete ( wxWindow * )Panel;
}

#endif