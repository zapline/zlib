/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ControlPanelI.hpp

    Comment:                interface of Control Panel Applet

    Interface Name:         Windows::UserInterface::IControlPanel

    Version:                5.0

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/10/22-2004/10/23 (1.0.1)
                            2004/11/06-2004/11/06 (1.0.2)
                            2004/12/05-2004/12/05 (1.0.3)
                            2005/01/08-2005/01/09 (1.0.4)
                            2005/04/23-2005/04/23 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/17-2010/01/17 (4.0)
                            2011/09/08-2011/09/08 (5.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef CONTROL_PANEL_APPLET_INTERFACE_HPP
#define CONTROL_PANEL_APPLET_INTERFACE_HPP

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#define MAX_CPL_ID_NAME_LENGTH 31
#endif

namespace Windows
{
namespace UserInterface
{

//The declaration of IControlPanel
class IControlPanel
{
protected:
    inline IControlPanel(void){};
    inline ~IControlPanel(void){};
public:
    virtual bool Init(void)=0;
    virtual void Exit(void)=0;
    virtual int GetAppletCount(void)const=0;
    #if !(defined _WIN32_WCE)
    virtual void GetAppletInfo(int a_nApplet, CPLINFO* a_pInfo)const=0;
    #endif
    virtual void GetDynamicAppletInfo(int a_nApplet, NEWCPLINFO* a_pInfo)const=0;
    #if (defined _WIN32_WCE)
    virtual void GetAppletIdName(int a_nApplet, LPTSTR a_szIdName)const=0;
    #endif
    virtual void StopApplet(int a_nApplet, void* a_pParameter)=0;
    virtual bool StartApplet(HWND a_hWindow, int a_nApplet, void* a_pParameter)=0;
    #if !(defined _WIN32_WCE)
    virtual bool StartApplet(HWND a_hWindow, int a_nApplet, LPCTSTR a_szParameter)=0;
    #endif
private:
    IControlPanel(const IControlPanel& a_rControlPanel);
    const IControlPanel& operator=(const IControlPanel& a_rControlPanel);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ControlPanelI.hpp

\*_________________________________________________________*/
