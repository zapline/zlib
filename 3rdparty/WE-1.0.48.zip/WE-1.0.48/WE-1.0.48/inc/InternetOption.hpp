/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              InternetOption.hpp

    Comment:                encapsulation of Internet API

    Type Name:              Windows::Internet::EOption

    Version:                3.1

    Build:                  21

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2002/12/26-2003/01/24 (1.0)
                            2004/05/09-2004/05/20 (1.1.14)
                            2004/09/23-2004/09/23 (1.1.15)
                            2004/11/06-2004/11/06 (1.1.16)
                            2005/05/04-2005/05/04 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/24-2010/01/24 (3.1)

    Notice:
    Copyright (C) 2010, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef INTERNET_OPTION_HPP
#define INTERNET_OPTION_HPP

//The definition of compatibility
#if !defined(INTERNET_OPTION_FROM_CACHE_TIMEOUT)
#define INTERNET_OPTION_FROM_CACHE_TIMEOUT                63
#define INTERNET_OPTION_BYPASS_EDITED_ENTRY               64
#define INTERNET_OPTION_CODEPAGE                          68
#define INTERNET_OPTION_CACHE_TIMESTAMPS                  69
#define INTERNET_OPTION_DISABLE_AUTODIAL                  70
#define INTERNET_OPTION_MAX_CONNS_PER_SERVER              73
#define INTERNET_OPTION_MAX_CONNS_PER_1_0_SERVER          74
#define INTERNET_OPTION_PER_CONNECTION_OPTION             75
#define INTERNET_OPTION_DIGEST_AUTH_UNLOAD                76
#define INTERNET_OPTION_IGNORE_OFFLINE                    77
#define INTERNET_OPTION_IDENTITY                          78
#define INTERNET_OPTION_REMOVE_IDENTITY                   79
#define INTERNET_OPTION_ALTER_IDENTITY                    80
#define INTERNET_OPTION_SUPPRESS_BEHAVIOR                 81
#define INTERNET_OPTION_AUTODIAL_MODE                     82
#define INTERNET_OPTION_AUTODIAL_CONNECTION               83
#define INTERNET_OPTION_CLIENT_CERT_CONTEXT               84
#define INTERNET_OPTION_AUTH_FLAGS                        85
#define INTERNET_OPTION_COOKIES_3RD_PARTY                 86
#define INTERNET_OPTION_DISABLE_PASSPORT_AUTH             87
#define INTERNET_OPTION_SEND_UTF8_SERVERNAME_TO_PROXY     88
#define INTERNET_OPTION_EXEMPT_CONNECTION_LIMIT           89
#define INTERNET_OPTION_ENABLE_PASSPORT_AUTH              90
#define INTERNET_OPTION_HIBERNATE_INACTIVE_WORKER_THREADS 91
#define INTERNET_OPTION_ACTIVATE_WORKER_THREADS           92
#define INTERNET_OPTION_RESTORE_WORKER_THREAD_DEFAULTS    93
#define INTERNET_OPTION_SOCKET_SEND_BUFFER_LENGTH         94
#define INTERNET_OPTION_PROXY_SETTINGS_CHANGED            95
#endif

namespace Windows
{
namespace Internet
{

//The definition of EOption
enum EOption
{
    eOptionCallback = INTERNET_OPTION_CALLBACK, //1
    eOptionConnectTimeout = INTERNET_OPTION_CONNECT_TIMEOUT, //2
    eOptionConnectRetries = INTERNET_OPTION_CONNECT_RETRIES, //3
    eOptionConnectBackOff = INTERNET_OPTION_CONNECT_BACKOFF, //4
    eOptionSendTimeout = INTERNET_OPTION_SEND_TIMEOUT, //5
    eOptionControlSendTimeout = INTERNET_OPTION_CONTROL_SEND_TIMEOUT, //5
    eOptionReceiveTimeout = INTERNET_OPTION_RECEIVE_TIMEOUT, //6
    eOptionControlReceiveTimeout = INTERNET_OPTION_CONTROL_RECEIVE_TIMEOUT, //6
    eOptionDataSendTimeout = INTERNET_OPTION_DATA_SEND_TIMEOUT, //7
    eOptionDataReceiveTimeout = INTERNET_OPTION_DATA_RECEIVE_TIMEOUT, //8
    eOptionHandleType = INTERNET_OPTION_HANDLE_TYPE, //9
    //10
    eOptionListenTimeout = INTERNET_OPTION_LISTEN_TIMEOUT, //11
    eOptionReadBufferSize = INTERNET_OPTION_READ_BUFFER_SIZE, //12
    eOptionWriteBufferSize = INTERNET_OPTION_WRITE_BUFFER_SIZE, //13
    //14
    eOptionAsynchronousID = INTERNET_OPTION_ASYNC_ID, //15
    eOptionAsynchronousPriority = INTERNET_OPTION_ASYNC_PRIORITY, //16
    //17
    //18
    //19
    //20
    eOptionParentHandle = INTERNET_OPTION_PARENT_HANDLE, //21
    eOptionKeepConnection = INTERNET_OPTION_KEEP_CONNECTION, //22
    eOptionRequestFlags = INTERNET_OPTION_REQUEST_FLAGS, //23
    eOptionExtendedError = INTERNET_OPTION_EXTENDED_ERROR, //24
    //25
    eOptionOfflineMode = INTERNET_OPTION_OFFLINE_MODE, //26
    eOptionCacheStreamHandle = INTERNET_OPTION_CACHE_STREAM_HANDLE, //27
    eOptionUserName = INTERNET_OPTION_USERNAME, //28
    eOptionPassword = INTERNET_OPTION_PASSWORD, //29
    eOptionAsynchronous = INTERNET_OPTION_ASYNC, //30
    eOptionSecurityFlags = INTERNET_OPTION_SECURITY_FLAGS, //31
    eOptionSecurityCertificateStruct = INTERNET_OPTION_SECURITY_CERTIFICATE_STRUCT, //32
    eOptionDataFileName = INTERNET_OPTION_DATAFILE_NAME, //33
    eOptionUrl = INTERNET_OPTION_URL, //34
    eOptionSecurityCertificate = INTERNET_OPTION_SECURITY_CERTIFICATE, //35
    eOptionSecurityKeyBitness = INTERNET_OPTION_SECURITY_KEY_BITNESS, //36
    eOptionRefresh = INTERNET_OPTION_REFRESH, //37
    eOptionProxy = INTERNET_OPTION_PROXY, //38
    eOptionSettingsChanged = INTERNET_OPTION_SETTINGS_CHANGED, //39
    eOptionVersion = INTERNET_OPTION_VERSION, //40
    eOptionUserAgent = INTERNET_OPTION_USER_AGENT, //41
    eOptionEndBrowserSession = INTERNET_OPTION_END_BROWSER_SESSION, //42
    eOptionProxyUserName = INTERNET_OPTION_PROXY_USERNAME, //43
    eOptionProxyPassword = INTERNET_OPTION_PROXY_PASSWORD, //44
    eOptionContextValue = INTERNET_OPTION_CONTEXT_VALUE, //45
    eOptionConnectLimit = INTERNET_OPTION_CONNECT_LIMIT, //46
    eOptionSecuritySelectClientCert = INTERNET_OPTION_SECURITY_SELECT_CLIENT_CERT, //47
    eOptionPolicy = INTERNET_OPTION_POLICY, //48
    eOptionDisconnectedTimeout = INTERNET_OPTION_DISCONNECTED_TIMEOUT, //49
    eOptionConnectedState = INTERNET_OPTION_CONNECTED_STATE, //50
    eOptionIdleState = INTERNET_OPTION_IDLE_STATE, //51
    eOptionOfflineSemantics = INTERNET_OPTION_OFFLINE_SEMANTICS, //52
    eOptionSecondaryCacheKey = INTERNET_OPTION_SECONDARY_CACHE_KEY, //53
    eOptionCallbackFilter = INTERNET_OPTION_CALLBACK_FILTER, //54
    eOptionConnectTime = INTERNET_OPTION_CONNECT_TIME, //55
    eOptionSendThroughput = INTERNET_OPTION_SEND_THROUGHPUT, //56
    eOptionReceiveThroughput = INTERNET_OPTION_RECEIVE_THROUGHPUT, //57
    eOptionRequestPriority = INTERNET_OPTION_REQUEST_PRIORITY, //58
    eOptionHttpVersion = INTERNET_OPTION_HTTP_VERSION, //59
    eOptionResetUrlCacheSession = INTERNET_OPTION_RESET_URLCACHE_SESSION, //60
    //61
    eOptionErrorMask = INTERNET_OPTION_ERROR_MASK, //62
    eOptionFromCacheTimeout = INTERNET_OPTION_FROM_CACHE_TIMEOUT, //63
    eOptionBypassEditedEntry = INTERNET_OPTION_BYPASS_EDITED_ENTRY, //64
    //65
    //66
    //67
    eOptionCodepage = INTERNET_OPTION_CODEPAGE, //68
    eOptionCacheTimeStamps = INTERNET_OPTION_CACHE_TIMESTAMPS, //69
    eOptionDisableAutodial = INTERNET_OPTION_DISABLE_AUTODIAL, //70
    //71
    //72
    eOptionMaxConnectionsPerServer = INTERNET_OPTION_MAX_CONNS_PER_SERVER, //73
    eOptionMaxConnectionsPer10Server = INTERNET_OPTION_MAX_CONNS_PER_1_0_SERVER, //74
    eOptionPerConnectionOption = INTERNET_OPTION_PER_CONNECTION_OPTION, //75
    eOptionDigestAuthenticationUnload = INTERNET_OPTION_DIGEST_AUTH_UNLOAD, //76
    eOptionIgnoreOffline = INTERNET_OPTION_IGNORE_OFFLINE, //77
    eOptionIdentity = INTERNET_OPTION_IDENTITY, //78
    eOptionRemoveIdentity = INTERNET_OPTION_REMOVE_IDENTITY, //79
    eOptionAlterIdentity = INTERNET_OPTION_ALTER_IDENTITY, //80
    eOptionSuppressBehavior = INTERNET_OPTION_SUPPRESS_BEHAVIOR, //81
    eOptionAutodialMode = INTERNET_OPTION_AUTODIAL_MODE, //82
    eOptionAutodialConnection = INTERNET_OPTION_AUTODIAL_CONNECTION, //83
    eOptionClientCertContext = INTERNET_OPTION_CLIENT_CERT_CONTEXT, //84
    eOptionAuthFlags = INTERNET_OPTION_AUTH_FLAGS, //85
    eOptionCookiesThirdParty = INTERNET_OPTION_COOKIES_3RD_PARTY, //86
    eOptionDisablePassportAuthentication = INTERNET_OPTION_DISABLE_PASSPORT_AUTH, //87
    eOptionSendUtf8ServerNameToProxy = INTERNET_OPTION_SEND_UTF8_SERVERNAME_TO_PROXY, //88
    eOptionExemptConnectionLimit = INTERNET_OPTION_EXEMPT_CONNECTION_LIMIT, //89
    eOptionEnablePassportAuthentication = INTERNET_OPTION_ENABLE_PASSPORT_AUTH, //90
    eOptionHibernateInactiveWorkerThreads = INTERNET_OPTION_HIBERNATE_INACTIVE_WORKER_THREADS, //91
    eOptionActivateWorkerThreads = INTERNET_OPTION_ACTIVATE_WORKER_THREADS, //92
    eOptionRestoreWorkerThreadDefaults = INTERNET_OPTION_RESTORE_WORKER_THREAD_DEFAULTS, //93
    eOptionSocketSendBufferLength = INTERNET_OPTION_SOCKET_SEND_BUFFER_LENGTH, //94
    eOptionProxySettingsChanged = INTERNET_OPTION_PROXY_SETTINGS_CHANGED, //95
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of InternetOption.hpp

\*_________________________________________________________*/
