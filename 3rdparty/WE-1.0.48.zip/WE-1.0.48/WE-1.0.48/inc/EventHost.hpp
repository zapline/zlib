/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              EventHost.hpp

    Comment:                encapsulation of Event

    Class Name:             Windows::Base::Synchronization::CEventHost

    Version:                4.0

    Build:                  12

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/06/09-2004/06/09 (1.0)
                            2004/09/23-2004/09/23 (1.1)
                            2005/04/23-2005/04/23 (1.2)
                            2005/07/31-2005/07/31 (2.0)
                            2005/08/06-2005/08/06 (3.0)
                            2005/09/24-2005/09/24 (3.1)
                            2010/01/09-2010/01/09 (3.2)
                            2010/01/29-2010/01/29 (3.3)
                            2011/09/20-2011/09/20 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef EVENT_HOST_HPP
#define EVENT_HOST_HPP

#include <welink.h>

namespace Windows
{
namespace Base
{
namespace Synchronization
{

//The declaration of CEventHost
class CEventHost
{
public:
    CEventHost(void);
    ~CEventHost(void);
    bool Create(LPCTSTR a_szName, bool a_bSignaled=false);
    void SetSignaled(void);
    void SetNonsignaled(void);
    operator HANDLE(void)const;
private:
    HANDLE m_hEvent;
private:
    CEventHost(const CEventHost& a_rEvent);
    const CEventHost& operator=(const CEventHost& a_rEvent);
};

}
}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of EventHost.hpp

\*_________________________________________________________*/
