/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Registry.hpp

    Comment:                encapsulation of Registry

    Module Name:            Windows::Base::Registry

    Version:                2.1

    Build:                  48

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/06/24-1999/10/18 (0.5)
                            2003/01/15-2003/02/13 (0.8)
                            2003/03/24-2003/04/02 (0.9)
                            2004/04/27-2004/04/29 (1.0.35)
                            2004/09/22-2004/09/23 (1.0.36)
                            2004/11/14-2004/11/14 (1.0.37)
                            2005/01/08-2005/01/08 (1.0.38)
                            2005/05/04-2005/05/04 (1.1)
                            2005/09/25-2005/09/25 (1.2.40)
                            2006/04/02-2006/04/02 (1.2.41)
                            2010/01/07-2010/01/07 (1.3)
                            2010/01/29-2010/01/31 (1.4)
                            2011/09/27-2011/09/27 (2.0)
                            2011/11/16-2011/11/16 (2.1)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef REGISTRY_HPP
#define REGISTRY_HPP

#include <RegistryKey.hpp>
#include <welink.h>

namespace Windows
{
namespace Base
{
namespace Registry
{

//The declaration of global functions
bool GetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, LPTSTR a_szValue, DWORD a_dwBufferSize);
bool GetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, DWORD& a_rdwValue);
bool GetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, QWORD& a_rqwValue);
bool GetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, bool& a_rbValue);
bool SetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, LPCTSTR a_szValue);
bool SetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, DWORD a_dwValue);
bool SetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, QWORD a_qwValue);
bool SetValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName, bool a_bValue);
bool DeleteValue(ERegistryKey a_eRootKey, LPCTSTR a_szKey, LPCTSTR a_szValueName);

}
}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Registry.hpp

\*_________________________________________________________*/
