/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ComboBox.hpp

    Comment:                encapsulation for Combo Box Control

    Class Name:             Windows::UserInterface::CComboBox

    Version:                1.4

    Build:                  8

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/05/06-2005/05/06 (1.0)
                            2005/09/25-2005/09/25 (1.1)
                            2010/01/17-2010/01/17 (1.2)
                            2010/01/30-2010/01/31 (1.3)
                            2011/10/07-2011/10/07 (1.4)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef COMBO_BOX_HPP
#define COMBO_BOX_HPP

#include <Control.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define CBS_OWNERDRAWVARIABLE 0x0020L
#define CB_DIR 0x0145
#endif
#if !(defined CB_GETCOMBOBOXINFO)
#define CB_GETCOMBOBOXINFO 0x0164
#endif

//The definition of global functions of Combo Box
#if (defined ComboBox_LimitText)
#undef ComboBox_LimitText
#endif
#if (defined ComboBox_GetEditSel)
#undef ComboBox_GetEditSel
#endif
#if (defined ComboBox_ResetContent)
#undef ComboBox_ResetContent
#endif
#if (defined ComboBox_ShowDropdown)
#undef ComboBox_ShowDropdown
#endif
#if (defined ComboBox_GetDroppedControlRect)
#undef ComboBox_GetDroppedControlRect
#endif
#if (defined ComboBox_GetItemHeight)
#undef ComboBox_GetItemHeight
#endif
#if (defined ComboBox_GetExtendedUI)
#undef ComboBox_GetExtendedUI
#endif
//#define ComboBox_Enable(a_hComboBox,a_bEnable) ((BOOL)EnableWindow((HWND)(a_hComboBox),(BOOL)(a_bEnable)))
//#define ComboBox_GetTextLength(a_hComboBox) ((int)GetWindowTextLength((HWND)(a_hComboBox)))
//#define ComboBox_GetText(a_hComboBox,a_szTextBuffer,a_nBufferSize) ((int)GetWindowText((HWND)(a_hComboBox),(LPTSTR)(a_szTextBuffer),(int)(a_nBufferSize)))
//#define ComboBox_SetText(a_hComboBox,a_szText) ((BOOL)SetWindowText((HWND)(a_hComboBox),(LPCTSTR)(a_szText)))
#define ComboBox_LimitText(a_hComboBox,a_nMaxText) ((void)SendMessage((HWND)(a_hComboBox),CB_LIMITTEXT,(WPARAM)(int)(a_nMaxText),(LPARAM)0))
#define ComboBox_GetEditSel(a_hComboBox,a_pdwStart,a_pdwEnd) ((void)SendMessage((HWND)(a_hComboBox),CB_GETEDITSEL,(WPARAM)(DWORD*)(a_pdwStart),(LPARAM)(DWORD*)(a_pdwEnd)))
//#define ComboBox_SetEditSel(a_hComboBox,a_nStart,a_nEnd) ((int)SendMessage((HWND)(a_hComboBox),CB_SETEDITSEL,(WPARAM)0,MAKELPARAM((WORD)(int)(a_nStart),(WORD)(int)(a_nEnd))))
//#define ComboBox_GetCount(a_hComboBox) ((int)SendMessage((HWND)(a_hComboBox),CB_GETCOUNT,(WPARAM)0,(LPARAM)0))
#define ComboBox_ResetContent(a_hComboBox) ((void)SendMessage((HWND)(a_hComboBox),CB_RESETCONTENT,(WPARAM)0,(LPARAM)0))
//#define ComboBox_AddString(a_hComboBox,a_szText) ((int)SendMessage((HWND)(a_hComboBox),CB_ADDSTRING,(WPARAM)0,(LPARAM)(LPCTSTR)(a_szText)))
//#define ComboBox_InsertString(a_hComboBox,a_nIndex,a_szText) ((int)SendMessage((HWND)(a_hComboBox),CB_INSERTSTRING,(WPARAM)(int)(a_nIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ComboBox_DeleteString(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_DELETESTRING,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_AddItemData(a_hComboBox,a_nData) ((int)SendMessage((HWND)(a_hComboBox),CB_ADDSTRING,(WPARAM)0,(LPARAM)(LONG_PTR)(a_nData)))
//#define ComboBox_InsertItemData(a_hComboBox,a_nIndex,a_nData) ((int)SendMessage((HWND)(a_hComboBox),CB_INSERTSTRING,(WPARAM)(int)(a_nIndex),(LPARAM)(LONG_PTR)(a_nData)))
#define ComboBox_DeleteItem(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_DELETESTRING,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_GetLBTextLen(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_GETLBTEXTLEN,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_GetLBText(a_hComboBox,a_nIndex,a_szTextBuffer) ((int)SendMessage((HWND)(a_hComboBox),CB_GETLBTEXT,(WPARAM)(int)(a_nIndex),(LPARAM)(LPTSTR)(a_szTextBuffer)))
//#define ComboBox_GetItemData(a_hComboBox,a_nIndex) ((LONG_PTR)SendMessage((HWND)(a_hComboBox),CB_GETITEMDATA,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_SetItemData(a_hComboBox,a_nIndex,a_nData) ((int)SendMessage((HWND)(a_hComboBox),CB_SETITEMDATA,(WPARAM)(int)(a_nIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ComboBox_FindString(a_hComboBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hComboBox),CB_FINDSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ComboBox_FindItemData(a_hComboBox,a_nLastIndex,a_nData) ((int)SendMessage((HWND)(a_hComboBox),CB_FINDSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ComboBox_FindStringExact(a_hComboBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hComboBox),CB_FINDSTRINGEXACT,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ComboBox_GetCurSel(a_hComboBox) ((int)SendMessage((HWND)(a_hComboBox),CB_GETCURSEL,(WPARAM)0,(LPARAM)0))
//#define ComboBox_SetCurSel(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_SETCURSEL,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_SelectString(a_hComboBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hComboBox),CB_SELECTSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ComboBox_SelectItemData(a_hComboBox,a_nLastIndex,a_nData) ((int)SendMessage((HWND)(a_hComboBox),CB_SELECTSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ComboBox_Dir(a_hComboBox,a_nAttribute,a_szFileName) ((int)SendMessage((HWND)(a_hComboBox),CB_DIR,(WPARAM)(UINT)(a_nAttribute),(LPARAM)(LPCTSTR)(a_szFileName)))
#define ComboBox_ShowDropdown(a_hComboBox,a_bShow) ((void)SendMessage((HWND)(a_hComboBox),CB_SHOWDROPDOWN,(WPARAM)(BOOL)(a_bShow),(LPARAM)0))
//#define ComboBox_GetDroppedState(a_hComboBox) ((BOOL)SendMessage((HWND)(a_hComboBox),CB_GETDROPPEDSTATE,(WPARAM)0,(LPARAM)0))
#define ComboBox_GetDroppedControlRect(a_hComboBox,a_pRectangle) ((BOOL)SendMessage((HWND)(a_hComboBox),CB_GETDROPPEDCONTROLRECT,(WPARAM)0,(LPARAM)(LPRECT)(a_pRectangle)))
#define ComboBox_GetItemHeight(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_GETITEMHEIGHT,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ComboBox_SetItemHeight(a_hComboBox,a_nIndex,a_nHeight) ((int)SendMessage((HWND)(a_hComboBox),CB_SETITEMHEIGHT,(WPARAM)(int)(a_nIndex),(LPARAM)(int)a_nHeight))
#define ComboBox_GetExtendedUI(a_hComboBox) ((BOOL)SendMessage((HWND)(a_hComboBox),CB_GETEXTENDEDUI,(WPARAM)0,(LPARAM)0))
//#define ComboBox_SetExtendedUI(a_hComboBox,a_bExtended) ((int)SendMessage((HWND)(a_hComboBox),CB_SETEXTENDEDUI,(WPARAM)(BOOL)(a_bExtended),(LPARAM)0))
#define ComboBox_GetLocale(a_hComboBox) ((DWORD)SendMessage((HWND)(a_hComboBox),CB_GETLOCALE,(WPARAM)0,(LPARAM)0))
#define ComboBox_SetLocale(a_hComboBox,a_dwLocaleID) ((DWORD)SendMessage((HWND)(a_hComboBox),CB_SETLOCALE,(WPARAM)(DWORD)(a_dwLocaleID),(LPARAM)0))
#define ComboBox_GetTopIndex(a_hComboBox) ((int)SendMessage((HWND)(a_hComboBox),CB_GETTOPINDEX,(WPARAM)0,(LPARAM)0))
#define ComboBox_SetTopIndex(a_hComboBox,a_nIndex) ((int)SendMessage((HWND)(a_hComboBox),CB_SETTOPINDEX,(WPARAM)(int)(a_nIndex),(LPARAM)0))
#define ComboBox_GetHorizontalExtent(a_hComboBox) ((int)SendMessage((HWND)(a_hComboBox),CB_GETHORIZONTALEXTENT,(WPARAM)0,(LPARAM)0))
#define ComboBox_SetHorizontalExtent(a_hComboBox,a_nExtent) ((void)SendMessage((HWND)(a_hComboBox),CB_SETHORIZONTALEXTENT,(WPARAM)(int)(a_nExtent),(LPARAM)0))
#define ComboBox_GetDroppedWidth(a_hComboBox) ((int)SendMessage((HWND)(a_hComboBox),CB_GETDROPPEDWIDTH,(WPARAM)0,(LPARAM)0))
#define ComboBox_SetDroppedWidth(a_hComboBox,a_nWidth) ((int)SendMessage((HWND)(a_hComboBox),CB_SETDROPPEDWIDTH,(WPARAM)(int)(a_nWidth),(LPARAM)0))
#define ComboBox_InitStorage(a_hComboBox,a_nItemCount,a_nTextSize) ((int)SendMessage((HWND)(a_hComboBox),CB_INITSTORAGE,(WPARAM)(int)(a_nItemCount),(LPARAM)(int)(a_nTextSize)))
#define ComboBox_GetInfo(a_hComboBox,a_pComboBoxInfo) ((BOOL)SendMessage((HWND)(a_hComboBox),CB_GETCOMBOBOXINFO,(WPARAM)0,(LPARAM)(COMBOBOXINFO*)(a_pComboBoxInfo)))

namespace Windows
{
namespace UserInterface
{

//The declaration of CComboBox
class CComboBox:
    public CControl
{
public:
    CComboBox(void);
    ~CComboBox(void);
    void LimitText(int a_nMaxText);
    void GetEditSelect(int& a_rnStart, int& a_rnEnd);
    void SetEditSelect(int a_nStart, int a_nEnd);
    int GetCount(void);
    void ResetContent(void);
    int AddString(LPCTSTR a_szText);
    bool InsertString(int a_nIndex, LPCTSTR a_szText);
    void DeleteString(int a_nIndex);
    int AddItemData(LONG_PTR a_nData);
    bool InsertItemData(int a_nIndex, LONG_PTR a_nData);
    void DeleteItem(int a_nIndex);
    int GetTextLength(int a_nIndex);
    void GetText(int a_nIndex, LPTSTR a_szTextBuffer);
    LONG_PTR GetItemData(int a_nIndex);
    void SetItemData(int a_nIndex, LONG_PTR a_nData);
    int FindString(LPCTSTR a_szText);
    int FindString(int a_nLastIndex, LPCTSTR a_szText);
    int FindItemData(LONG_PTR a_nData);
    int FindItemData(int a_nLastIndex, LONG_PTR a_nData);
    int FindStringExact(LPCTSTR a_szText);
    int FindStringExact(int a_nLastIndex, LPCTSTR a_szText);
    int GetCurrentSelect(void);
    void SetCurrentSelect(int a_nIndex);
    void SelectNone(void);
    bool SelectString(LPCTSTR a_szText);
    bool SelectString(int a_nLastIndex, LPCTSTR a_szText);
    bool SelectItemData(LONG_PTR a_nData);
    bool SelectItemData(int a_nLastIndex, LONG_PTR a_nData);
    int Dir(UINT a_nAttribute, LPCTSTR a_szFileName);
    void ShowDropdown(bool a_bShow);
    bool GetDroppedState(void);
    void GetDroppedControlRectangle(LPRECT a_pRectangle);
    int GetItemHeight(void);
    int GetItemHeight(int a_nIndex);
    void SetItemHeight(int a_nHeight);
    void SetItemHeight(int a_nIndex, int a_nHeight);
    int GetSelectionFieldHeight(void);
    void SetSelectionFieldHeight(int a_nHeight);
    bool GetExtendedUI(void);
    void SetExtendedUI(bool a_bExtended);
    DWORD GetLocale(void);
    DWORD SetLocale(DWORD a_dwLocaleID);
    int GetTopIndex(void);
    void SetTopIndex(int a_nIndex);
    int GetHorizontalExtent(void);
    void SetHorizontalExtent(int a_nExtent);
    int GetDroppedWidth(void);
    void SetDroppedWidth(int a_nWidth);
    bool InitStorage(int a_nItemCount, int a_nTextSize);
    void GetInfo(COMBOBOXINFO* a_pComboBoxInfo);
private:
    CComboBox(const CComboBox& a_rComboBox);
    const CComboBox& operator=(const CComboBox& a_rComboBox);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ComboBox.hpp

\*_________________________________________________________*/
