/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Edit.hpp

    Comment:                encapsulation for Edit Control

    Class Name:             Windows::UserInterface::CEdit

    Version:                2.6

    Build:                  12

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/05/24-2004/05/27 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2005/01/08-2005/01/10 (2.0)
                            2005/04/24-2005/04/24 (2.1)
                            2005/05/28-2005/05/28 (2.2)
                            2005/09/25-2005/09/25 (2.3)
                            2010/01/16-2010/01/16 (2.4)
                            2010/01/30-2010/01/30 (2.5)
                            2011/10/06-2011/10/07 (2.6)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef EDIT_HPP
#define EDIT_HPP

#include <Control.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define EM_SETHANDLE        0x00BC
#define EM_GETHANDLE        0x00BD
#define EM_SETWORDBREAKPROC 0x00D0
#define EM_GETWORDBREAKPROC 0x00D1
#define EM_GETTHUMB         0x00BE
#define EM_SETIMESTATUS     0x00D8
#define EM_GETIMESTATUS     0x00D9
#define Edit_GetHandle(a_hEdit) ((HLOCAL)SendMessage((HWND)(a_hEdit),EM_GETHANDLE,(WPARAM)0,(LPARAM)0))
#define Edit_SetHandle(a_hEdit,a_hMemory) ((void)SendMessage((HWND)(a_hEdit),EM_SETHANDLE,(WPARAM)(HLOCAL)(a_hMemory),(LPARAM)0))
#define Edit_GetWordBreakProc(a_hEdit) ((EDITWORDBREAKPROC)SendMessage((HWND)(a_hEdit),EM_GETWORDBREAKPROC,(WPARAM)0,(LPARAM)0))
#define Edit_SetWordBreakProc(a_hEdit,a_fnWordBreakProcedure) ((void)SendMessage((HWND)(a_hEdit),EM_SETWORDBREAKPROC,(WPARAM)0,(LPARAM)(EDITWORDBREAKPROC)(a_fnWordBreakProcedure)))
typedef int (CALLBACK* EDITWORDBREAKPROC)(LPTSTR a_szText, int a_nIndex, int a_nLength, int a_nCode);
#endif

//The definition of global functions of Edit
#if (defined Edit_GetSel)
#undef Edit_GetSel
#endif
#if (defined Edit_ReplaceSel)
#undef Edit_ReplaceSel
#endif
#if (defined Edit_ScrollCaret)
#undef Edit_ScrollCaret
#endif
#if (defined Edit_SetTabStops)
#undef Edit_SetTabStops
#endif
//#define Edit_Enable(a_hEdit,a_bEnable) ((BOOL)EnableWindow((HWND)(a_hEdit),(BOOL)(a_bEnable)))
//#define Edit_GetTextLength(a_hEdit) ((int)GetWindowTextLength((HWND)(a_hEdit)))
//#define Edit_GetText(a_hEdit,a_szText,a_nBufferSize) ((int)GetWindowText((HWND)(a_hEdit),(LPTSTR)(a_szText),(int)(a_nBufferSize)))
//#define Edit_SetText(a_hEdit,a_szText) ((BOOL)SetWindowText((HWND)(a_hEdit),(LPCTSTR)(a_szText)))
//#define Edit_LimitText(a_hEdit,a_nMaxText) ((void)SendMessage((HWND)(a_hEdit),EM_LIMITTEXT,(WPARAM)(int)(a_nMaxText),(LPARAM)0))
#define Edit_GetLimitText(a_hEdit) ((int)SendMessage((HWND)(a_hEdit),EM_GETLIMITTEXT,(WPARAM)0,(LPARAM)0))
#define Edit_SetLimitText(a_hEdit,a_nMaxText) ((void)SendMessage((HWND)(a_hEdit),EM_SETLIMITTEXT,(WPARAM)(int)(a_nMaxText),(LPARAM)0))
//#define Edit_GetLineCount(a_hEdit) ((int)SendMessage((HWND)(a_hEdit),EM_GETLINECOUNT,(WPARAM)0,(LPARAM)0))
//#define Edit_GetLine(a_hEdit,a_nLine,a_szText,a_nBufferSize) (*(WORD*)(LPTSTR)(a_szText)=(WORD)(int)(a_nBufferSize)),(int)SendMessage((HWND)(a_hEdit),EM_GETLINE,(WPARAM)(int)(a_nLine),(LPARAM)(LPTSTR)(a_szText)))
//#define Edit_GetRect(a_hEdit,a_pRectangle) ((void)SendMessage((HWND)(a_hEdit),EM_GETRECT,(WPARAM)0,(LPARAM)(LPRECT)(a_pRectangle)))
//#define Edit_SetRect(a_hEdit,a_pRectangle) ((void)SendMessage((HWND)(a_hEdit),EM_SETRECT,(WPARAM)0,(LPARAM)(LPCRECT)(a_pRectangle)))
//#define Edit_SetRectNoPaint(a_hEdit,a_pRectangle) ((void)SendMessage((HWND)(a_hEdit),EM_SETRECTNP,(WPARAM)0,(LPARAM)(LPCRECT)(a_pRectangle)))
#define Edit_GetSel(a_hEdit,a_pdwStart,a_pdwEnd) ((void)SendMessage((HWND)(a_hEdit),EM_GETSEL,(WPARAM)(DWORD*)(a_pdwStart),(LPARAM)(DWORD*)(a_pdwEnd)))
//#define Edit_SetSel(a_hEdit,a_dwStart,a_dwEnd) ((void)SendMessage((HWND)(a_hEdit),EM_SETSEL,(WPARAM)(DWORD)(a_dwStart),(LPARAM)(DWORD)(a_dwEnd)))
#define Edit_ReplaceSel(a_hEdit,a_szReplace) ((void)SendMessage((HWND)(a_hEdit),EM_REPLACESEL,(WPARAM)(BOOL)TRUE,(LPARAM)(LPCTSTR)(a_szReplace)))
//#define Edit_GetModify(a_hEdit) ((BOOL)SendMessage((HWND)(a_hEdit),EM_GETMODIFY,(WPARAM)0,(LPARAM)0))
//#define Edit_SetModify(a_hEdit,a_bModified) ((void)SendMessage((HWND)(a_hEdit),EM_SETMODIFY,(WPARAM)(BOOL)(a_bModified),(LPARAM)0))
#define Edit_ScrollCaret(a_hEdit) ((void)SendMessage((HWND)(a_hEdit),EM_SCROLLCARET,(WPARAM)0,(LPARAM)0))
//#define Edit_Scroll(a_hEdit,a_nLines,a_nChars) ((void)SendMessage((HWND)(a_hEdit),EM_LINESCROLL,(WPARAM)(int)(a_nChars),(LPARAM)(int)(a_nLines)))
//#define Edit_Scroll(a_hEdit,a_nAction) ((BOOL)SendMessage((HWND)(a_hEdit),EM_SCROLL,(WPARAM)(UINT)(a_nAction),(LPARAM)0))
//#define Edit_LineIndex(a_hEdit,a_nLine) ((int)SendMessage((HWND)(a_hEdit),EM_LINEINDEX,(WPARAM)(int)(a_nLine),(LPARAM)0))
#define Edit_CharFromLine(a_hEdit,a_nLine) Edit_LineIndex(a_hEdit,a_nLine)
//#define Edit_LineFromChar(a_hEdit,a_nChar) ((int)SendMessage((HWND)(a_hEdit),EM_LINEFROMCHAR,(WPARAM)(int)(a_nChar),(LPARAM)0))
//#define Edit_LineLength(a_hEdit,a_nChar) ((int)SendMessage((HWND)(a_hEdit),EM_LINELENGTH,(WPARAM)(int)(a_nChar),(LPARAM)0))
//#define Edit_CanUndo(a_hEdit) ((BOOL)SendMessage((HWND)(a_hEdit),EM_CANUNDO,(WPARAM)0,(LPARAM)0))
//#define Edit_Undo(a_hEdit) ((BOOL)SendMessage((HWND)(a_hEdit),EM_UNDO,(WPARAM)0,(LPARAM)0))
//#define Edit_EmptyUndoBuffer(a_hEdit) ((void)SendMessage((HWND)(a_hEdit),EM_EMPTYUNDOBUFFER,(WPARAM)0,(LPARAM)0))
#define Edit_SetTabStops(a_hEdit,a_pnTabStops,a_nCount) ((BOOL)SendMessage((HWND)(a_hEdit),EM_SETTABSTOPS,(WPARAM)(int)(a_nCount),(LPARAM)(const unsigned int*)(a_pnTabStops)))
//#define Edit_FmtLines(a_hEdit,a_bAddEOL) ((BOOL)SendMessage((HWND)(a_hEdit),EM_FMTLINES,(WPARAM)(BOOL)(a_bAddEOL),(LPARAM)0))
//#define Edit_GetPasswordChar(a_hEdit) ((TCHAR)SendMessage((HWND)(a_hEdit),EM_GETPASSWORDCHAR,(WPARAM)0,(LPARAM)0))
//#define Edit_SetPasswordChar(a_hEdit,a_cChar) ((void)SendMessage((HWND)(a_hEdit),EM_SETPASSWORDCHAR,(WPARAM)(TCHAR)(a_cChar),(LPARAM)0))
//#define Edit_GetHandle(a_hEdit) ((HLOCAL)SendMessage((HWND)(a_hEdit),EM_GETHANDLE,(WPARAM)0,(LPARAM)0))
//#define Edit_SetHandle(a_hEdit,a_hMemory) ((void)SendMessage((HWND)(a_hEdit),EM_SETHANDLE,(WPARAM)(HLOCAL)(a_hMemory),(LPARAM)0))
//#define Edit_GetFirstVisibleLine(a_hEdit) ((int)SendMessage((HWND)(a_hEdit),EM_GETFIRSTVISIBLELINE,(WPARAM)0,(LPARAM)0))
//#define Edit_SetReadOnly(a_hEdit,a_bReadOnly) ((BOOL)SendMessage((HWND)(a_hEdit),EM_SETREADONLY,(WPARAM)(BOOL)(a_bReadOnly),(LPARAM)0))
//#define Edit_GetWordBreakProc(a_hEdit) ((EDITWORDBREAKPROC)SendMessage((HWND)(a_hEdit),EM_GETWORDBREAKPROC,(WPARAM)0,(LPARAM)0))
//#define Edit_SetWordBreakProc(a_hEdit,a_fnWordBreakProcedure) ((void)SendMessage((HWND)(a_hEdit),EM_SETWORDBREAKPROC,(WPARAM)0,(LPARAM)(EDITWORDBREAKPROC)(a_fnWordBreakProcedure)))
#define Edit_GetThumb(a_hEdit) ((int)SendMessage((HWND)(a_hEdit),EM_GETTHUMB,(WPARAM)0,(LPARAM)0))
#define Edit_GetMargins(a_hEdit) ((DWORD)SendMessage((HWND)(a_hEdit),EM_GETMARGINS,(WPARAM)0,(LPARAM)0))
#define Edit_SetMargins(a_hEdit,a_nLeft,a_nRight) ((void)SendMessage((HWND)(a_hEdit),EM_SETMARGINS,(WPARAM)(EC_LEFTMARGIN|EC_RIGHTMARGIN),MAKELPARAM((WORD)(int)(a_nLeft),(WORD)(int)(a_nRight))))
#define Edit_PositionFromChar(a_hEdit,a_nChar) ((DWORD)SendMessage((HWND)(a_hEdit),EM_POSFROMCHAR,(WPARAM)(int)(a_nChar),(LPARAM)0))
#define Edit_CharFromPosition(a_hEdit,a_nXPosition,a_nYPosition) ((int)LOWORD((DWORD)SendMessage((HWND)(a_hEdit),EM_CHARFROMPOS,(WPARAM)0,MAKELPARAM((WORD)(int)(a_nXPosition),(WORD)(int)(a_nYPosition)))))
#define Edit_GetImeStatus(a_hEdit,a_nType) ((DWORD)SendMessage((HWND)(a_hEdit),EM_GETIMESTATUS,(WPARAM)(UINT)(a_nType),(LPARAM)0))
#define Edit_SetImeStatus(a_hEdit,a_nType,a_dwStatus) ((DWORD)SendMessage((HWND)(a_hEdit),EM_SETIMESTATUS,(WPARAM)(UINT)(a_nType),(LPARAM)(DWORD)(a_dwStatus)))

namespace Windows
{
namespace UserInterface
{

//The declaration of CEdit
class CEdit:
    public CControl
{
public:
    CEdit(void);
    ~CEdit(void);
    void LimitText(int a_nMaxText);
    int GetLimitText(void);
    void SetLimitText(int a_nMaxText);
    int GetLineCount(void);
    void GetLine(int a_nLine, LPTSTR a_szText, int a_nBufferSize);
    void GetRectangle(LPRECT a_pRectangle);
    void SetRectangle(void);
    void SetRectangle(LPCRECT a_pRectangle);
    void SetRectangleNoPaint(void);
    void SetRectangleNoPaint(LPCRECT a_pRectangle);
    void GetSelect(int& a_rnStart, int& a_rnEnd);
    void SetSelect(int a_nStart, int a_nEnd);
    void ReplaceSelect(LPCTSTR a_szReplace);
    bool GetModify(void);
    void SetModify(bool a_bModified);
    void ScrollCaret(void);
    void Scroll(int a_nLines, int a_nChars);
    int LineIndex(int a_nLine);
    int CharFromLine(int a_nLine);
    int LineFromChar(int a_nChar);
    int LineLength(int a_nChar);
    bool CanUndo(void);
    void Undo(void);
    void EmptyUndoBuffer(void);
    void SetTabStops(void);
    void SetTabStops(unsigned int a_nTabStop);
    void SetTabStops(const unsigned int* a_pnTabStops, int a_nCount);
    void FormatLines(bool a_bAddEOL);
    TCHAR GetPasswordChar(void);
    void SetPasswordChar(TCHAR a_cChar);
    HLOCAL GetHandle(void);
    void SetHandle(HLOCAL a_hMemory);
    int GetFirstVisibleLine(void);
    void SetReadOnly(bool a_bReadOnly);
    EDITWORDBREAKPROC GetWordBreakProcedure(void);
    void SetWordBreakProcedure(EDITWORDBREAKPROC a_fnWordBreakProcedure);
    int GetThumb(void);
    void GetMargins(int& a_rnLeft, int& a_rnRight);
    void SetMargins(int a_nLeft, int a_nRight);
    void PositionFromChar(int a_nChar, int& a_rnXPosition, int& a_rnYPosition);
    int CharFromPosition(int a_nXPosition, int a_nYPosition);
    DWORD GetImeStatus(UINT a_nType);
    DWORD SetImeStatus(UINT a_nType, DWORD a_dwStatus);
private:
    CEdit(const CEdit& a_rEdit);
    const CEdit& operator=(const CEdit& a_rEdit);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Edit.hpp

\*_________________________________________________________*/
