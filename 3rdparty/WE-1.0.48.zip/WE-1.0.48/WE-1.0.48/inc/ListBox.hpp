/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ListBox.hpp

    Comment:                encapsulation for List Box Control

    Class Name:             Windows::UserInterface::CListBox

    Version:                1.5

    Build:                  9

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/04/23-2005/04/24 (1.0)
                            2005/05/28-2005/05/28 (1.1)
                            2005/09/25-2005/09/25 (1.2)
                            2010/01/17-2010/01/17 (1.3)
                            2010/01/30-2010/01/31 (1.4)
                            2011/10/06-2011/10/07 (1.5)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef LIST_BOX_HPP
#define LIST_BOX_HPP

#include <Control.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define LBS_OWNERDRAWVARIABLE 0x0020L
#define LB_DIR      0x018D
#define LB_ADDFILE  0x0196
#define LB_SETCOUNT 0x01A7
#endif
#if !(defined LB_GETLISTBOXINFO)
#define LB_GETLISTBOXINFO 0x01B2
#endif

//The definition of global functions of List Box
#if (defined ListBox_ResetContent)
#undef ListBox_ResetContent
#endif
#if (defined ListBox_GetText)
#undef ListBox_GetText
#endif
#if (defined ListBox_SetTabStops)
#undef ListBox_SetTabStops
#endif
#if (defined ListBox_SetItemHeight)
#undef ListBox_SetItemHeight
#endif
//#define ListBox_Enable(a_hListBox,a_bEnable) ((BOOL)EnableWindow((HWND)(a_hListBox),(BOOL)(a_bEnable)))
//#define ListBox_GetCount(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETCOUNT,(WPARAM)0,(LPARAM)0))
#define ListBox_SetCount(a_hListBox,a_nItemCount) ((int)SendMessage((HWND)(a_hListBox),LB_SETCOUNT,(WPARAM)(int)(a_nItemCount),(LPARAM)0))
#define ListBox_ResetContent(a_hListBox) ((void)SendMessage((HWND)(a_hListBox),LB_RESETCONTENT,(WPARAM)0,(LPARAM)0))
//#define ListBox_AddString(a_hListBox,a_szText) ((int)SendMessage((HWND)(a_hListBox),LB_ADDSTRING,(WPARAM)0,(LPARAM)(LPCTSTR)(a_szText)))
//#define ListBox_InsertString(a_hListBox,a_nIndex,a_szText) ((int)SendMessage((HWND)(a_hListBox),LB_INSERTSTRING,(WPARAM)(int)(a_nIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ListBox_DeleteString(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_DELETESTRING,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_AddItemData(a_hListBox,a_nData) ((int)SendMessage((HWND)(a_hListBox),LB_ADDSTRING,(WPARAM)0,(LPARAM)(LONG_PTR)(a_nData)))
//#define ListBox_InsertItemData(a_hListBox,a_nIndex,a_nData) ((int)SendMessage((HWND)(a_hListBox),LB_INSERTSTRING,(WPARAM)(int)(a_nIndex),(LPARAM)(LONG_PTR)(a_nData)))
#define ListBox_DeleteItem(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_DELETESTRING,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_GetTextLen(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_GETTEXTLEN,(WPARAM)(int)(a_nIndex),(LPARAM)0))
#define ListBox_GetText(a_hListBox,a_nIndex,a_szTextBuffer) ((int)SendMessage((HWND)(a_hListBox),LB_GETTEXT,(WPARAM)(int)(a_nIndex),(LPARAM)(LPTSTR)(a_szTextBuffer)))
//#define ListBox_GetItemData(a_hListBox,a_nIndex) ((LONG_PTR)SendMessage((HWND)(a_hListBox),LB_GETITEMDATA,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_SetItemData(a_hListBox,a_nIndex,a_nData) ((int)SendMessage((HWND)(a_hListBox),LB_SETITEMDATA,(WPARAM)(int)(a_nIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ListBox_FindString(a_hListBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hListBox),LB_FINDSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ListBox_FindItemData(a_hListBox,a_nLastIndex,a_nData) ((int)SendMessage((HWND)(a_hListBox),LB_FINDSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ListBox_FindStringExact(a_hListBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hListBox),LB_FINDSTRINGEXACT,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ListBox_GetSelCount(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETSELCOUNT,(WPARAM)0,(LPARAM)0))
//#define ListBox_GetSelItems(a_hListBox,a_nBufferSize,a_pnItems) ((int)SendMessage((HWND)(a_hListBox),LB_GETSELITEMS,(WPARAM)(int)(a_nBufferSize),(LPARAM)(int*)(a_pnItems)))
//#define ListBox_GetSel(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_GETSEL,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_SetSel(a_hListBox,a_bSelect,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_SETSEL,(WPARAM)(BOOL)(a_bSelect),(LPARAM)(int)(a_nIndex)))
//#define ListBox_SelItemRange(a_hListBox,a_bSelect,a_nFirst,a_nLast) ((int)SendMessage((HWND)(a_hListBox),LB_SELITEMRANGE,(WPARAM)(BOOL)(a_bSelect),MAKELPARAM((WORD)(int)(a_nFirst),(WORD)(int)(a_nLast))))
#define ListBox_SelItemRangeEx(a_hListBox,a_nFirst,a_nLast) ((int)SendMessage((HWND)(a_hListBox),LB_SELITEMRANGEEX,(WPARAM)(int)(a_nFirst),(LPARAM)(int)(a_nLast)))
//#define ListBox_GetCurSel(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETCURSEL,(WPARAM)0,(LPARAM)0))
//#define ListBox_SetCurSel(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_SETCURSEL,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_SelectString(a_hListBox,a_nLastIndex,a_szText) ((int)SendMessage((HWND)(a_hListBox),LB_SELECTSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LPCTSTR)(a_szText)))
//#define ListBox_SelectItemData(a_hListBox,a_nLastIndex,a_nData) ((int)SendMessage((HWND)(a_hListBox),LB_SELECTSTRING,(WPARAM)(int)(a_nLastIndex),(LPARAM)(LONG_PTR)(a_nData)))
//#define ListBox_GetTopIndex(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETTOPINDEX,(WPARAM)0,(LPARAM)0))
//#define ListBox_SetTopIndex(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_SETTOPINDEX,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_SetColumnWidth(a_hListBox,a_nColumnWidth) ((void)SendMessage((HWND)(a_hListBox),LB_SETCOLUMNWIDTH,(WPARAM)(int)(a_nColumnWidth),(LPARAM)0))
//#define ListBox_GetHorizontalExtent(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETHORIZONTALEXTENT,(WPARAM)0,(LPARAM)0))
//#define ListBox_SetHorizontalExtent(a_hListBox,a_nExtent) ((void)SendMessage((HWND)(a_hListBox),LB_SETHORIZONTALEXTENT,(WPARAM)(int)(a_nExtent),(LPARAM)0))
#define ListBox_SetTabStops(a_hListBox,a_pnTabStops,a_nCount) ((BOOL)SendMessage((HWND)(a_hListBox),LB_SETTABSTOPS,(WPARAM)(int)(a_nCount),(LPARAM)(const int*)(a_pnTabStops)))
//#define ListBox_GetItemRect(a_hListBox,a_nIndex,a_pRectangle) ((int)SendMessage((HWND)(a_hListBox),LB_GETITEMRECT,(WPARAM)(int)(a_nIndex),(LPARAM)(LPRECT)(a_pRectangle)))
//#define ListBox_GetCaretIndex(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETCARETINDEX,(WPARAM)0,(LPARAM)0))
//#define ListBox_SetCaretIndex(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_SETCARETINDEX,(WPARAM)(int)(a_nIndex),(LPARAM)0))
//#define ListBox_GetItemHeight(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_GETITEMHEIGHT,(WPARAM)(int)(a_nIndex),(LPARAM)0))
#define ListBox_SetItemHeight(a_hListBox,a_nIndex,a_nHeight) ((int)SendMessage((HWND)(a_hListBox),LB_SETITEMHEIGHT,(WPARAM)(int)(a_nIndex),(LPARAM)(int)(a_nHeight)))
//#define ListBox_Dir(a_hListBox,a_nAttribute,a_szFileName) ((int)SendMessage((HWND)(a_hListBox),LB_DIR,(WPARAM)(UINT)(a_nAttribute),(LPARAM)(LPCTSTR)(a_szFileName)))
#define ListBox_AddFile(a_hListBox,a_szFileName) ((int)SendMessage((HWND)(a_hListBox),LB_ADDFILE,(WPARAM)0,(LPARAM)(LPCTSTR)(a_szFileName)))
#define ListBox_GetAnchorIndex(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETANCHORINDEX,(WPARAM)0,(LPARAM)0))
#define ListBox_SetAnchorIndex(a_hListBox,a_nIndex) ((int)SendMessage((HWND)(a_hListBox),LB_SETANCHORINDEX,(WPARAM)(int)(a_nIndex),(LPARAM)0))
#define ListBox_GetLocale(a_hListBox) ((DWORD)SendMessage((HWND)(a_hListBox),LB_GETLOCALE,(WPARAM)0,(LPARAM)0))
#define ListBox_SetLocale(a_hListBox,a_dwLocaleID) ((DWORD)SendMessage((HWND)(a_hListBox),LB_SETLOCALE,(WPARAM)(DWORD)(a_dwLocaleID),(LPARAM)0))
#define ListBox_InitStorage(a_hListBox,a_nItemCount,a_nTextSize) ((int)SendMessage((HWND)(a_hListBox),LB_INITSTORAGE,(WPARAM)(int)(a_nItemCount),(LPARAM)(int)(a_nTextSize)))
#define ListBox_ItemFromPoint(a_hListBox,a_nXPosition,a_nYPosition) ((DWORD)SendMessage((HWND)(a_hListBox),LB_ITEMFROMPOINT,(WPARAM)0,MAKELPARAM((WORD)(int)(a_nXPosition),(WORD)(int)(a_nYPosition))))
#define ListBox_GetInfo(a_hListBox) ((int)SendMessage((HWND)(a_hListBox),LB_GETLISTBOXINFO,(WPARAM)0,(LPARAM)0))

namespace Windows
{
namespace UserInterface
{

//The declaration of CListBox
class CListBox:
    public CControl
{
public:
    CListBox(void);
    ~CListBox(void);
    int GetCount(void);
    bool SetCount(int a_nItemCount);
    void ResetContent(void);
    int AddString(LPCTSTR a_szText);
    bool InsertString(int a_nIndex, LPCTSTR a_szText);
    void DeleteString(int a_nIndex);
    int AddItemData(LONG_PTR a_nData);
    bool InsertItemData(int a_nIndex, LONG_PTR a_nData);
    void DeleteItem(int a_nIndex);
    int GetTextLength(int a_nIndex);
    void GetText(int a_nIndex, LPTSTR a_szTextBuffer);
    LONG_PTR GetItemData(int a_nIndex);
    void SetItemData(int a_nIndex, LONG_PTR a_nData);
    int FindString(LPCTSTR a_szText);
    int FindString(int a_nLastIndex, LPCTSTR a_szText);
    int FindItemData(LONG_PTR a_nData);
    int FindItemData(int a_nLastIndex, LONG_PTR a_nData);
    int FindStringExact(LPCTSTR a_szText);
    int FindStringExact(int a_nLastIndex, LPCTSTR a_szText);
    int GetSelectCount(void);
    int GetSelectItems(int a_nBufferSize, int* a_pnItems);
    bool GetSelect(int a_nIndex);
    void SetSelect(bool a_bSelect);
    void SetSelect(bool a_bSelect, int a_nIndex);
    void SetSelect(bool a_bSelect, int a_nFirst, int a_nLast);
    int GetCurrentSelect(void);
    void SetCurrentSelect(int a_nIndex);
    void SelectNone(void);
    bool SelectString(LPCTSTR a_szText);
    bool SelectString(int a_nLastIndex, LPCTSTR a_szText);
    bool SelectItemData(LONG_PTR a_nData);
    bool SelectItemData(int a_nLastIndex, LONG_PTR a_nData);
    int GetTopIndex(void);
    void SetTopIndex(int a_nIndex);
    void SetColumnWidth(int a_nColumnWidth);
    int GetHorizontalExtent(void);
    void SetHorizontalExtent(int a_nExtent);
    bool SetTabStops(void);
    bool SetTabStops(int a_nTabStop);
    bool SetTabStops(const int* a_pnTabStops, int a_nCount);
    void GetItemRectangle(int a_nIndex, LPRECT a_pRectangle);
    int GetCaretIndex(void);
    void SetCaretIndex(int a_nIndex);
    int GetItemHeight(void);
    int GetItemHeight(int a_nIndex);
    void SetItemHeight(int a_nHeight);
    void SetItemHeight(int a_nIndex, int a_nHeight);
    int Dir(UINT a_nAttribute, LPCTSTR a_szFileName);
    int AddFile(LPCTSTR a_szFileName);
    int GetAnchorIndex(void);
    void SetAnchorIndex(int a_nIndex);
    DWORD GetLocale(void);
    DWORD SetLocale(DWORD a_dwLocaleID);
    bool InitStorage(int a_nItemCount, int a_nTextSize);
    int ItemFromPoint(int a_nXPosition, int a_nYPosition);
    int GetInfo(void);
private:
    CListBox(const CListBox& a_rListBox);
    const CListBox& operator=(const CListBox& a_rListBox);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ListBox.hpp

\*_________________________________________________________*/
