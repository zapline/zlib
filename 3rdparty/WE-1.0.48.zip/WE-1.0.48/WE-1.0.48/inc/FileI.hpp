/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              FileI.hpp

    Comment:                interface of File I/O

    Interface Name:         Windows::Base::IFile

    Version:                4.0

    Build:                  38

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/02-2003/04/26 (1.0)
                            2004/04/10-2004/05/25 (1.1.29)
                            2004/09/22-2004/09/23 (1.1.30)
                            2005/05/04-2005/05/04 (2.0.31)
                            2005/09/10-2005/09/10 (2.0.32)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/05-2010/01/11 (3.1)
                            2011/08/18-2011/08/18 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef FILE_INTERFACE_HPP
#define FILE_INTERFACE_HPP

namespace Windows
{
namespace Base
{

//The definition of EMoveMethod
enum EMoveMethod
{
    eFileBegin = FILE_BEGIN, //0
    eFileCurrent = FILE_CURRENT, //1
    eFileEnd = FILE_END, //2
};

//The declaration of IFile
class IFile
{
protected:
    inline IFile(void){};
    inline ~IFile(void){};
public:
    virtual void Close(void)=0;
    virtual bool Seek(LONGLONG a_nDistance, EMoveMethod a_eMoveMethod)const=0;
    virtual bool Seek(ULONGLONG a_nPosition)const=0;
    virtual bool SeekToBegin(void)const=0;
    virtual bool SeekToEnd(void)const=0;
    virtual bool Read(void* a_pBuffer, DWORD a_dwNumberOfBytesToRead, DWORD& a_rdwNumberOfBytesRead)const=0;
    virtual bool Write(const void* a_pBuffer, DWORD a_dwNumberOfBytesToWrite, DWORD& a_rdwNumberOfBytesWritten)const=0;
    virtual ULONGLONG GetLength(void)const=0;
    virtual bool SetLength(ULONGLONG a_nLength)const=0;
    virtual bool GetTime(FILETIME* a_pCreationTime, FILETIME* a_pLastAccessTime, FILETIME* a_pLastWriteTime)const=0;
    virtual bool SetTime(const FILETIME* a_pCreationTime, const FILETIME* a_pLastAccessTime, const FILETIME* a_pLastWriteTime)const=0;
    virtual operator HANDLE(void)const=0;
private:
    IFile(const IFile& a_rFile);
    const IFile& operator=(const IFile& a_rFile);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of FileI.hpp

\*_________________________________________________________*/
