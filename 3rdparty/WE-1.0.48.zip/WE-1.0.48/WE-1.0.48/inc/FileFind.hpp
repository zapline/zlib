/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              FileFind.hpp

    Comment:                encapsulation of Find File

    Class Name:             Windows::Base::CFileFind

    Version:                2.4

    Build:                  35

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/06/09-1999/11/02 (0.5)
                            2003/01/02-2003/04/26 (1.0)
                            2004/04/10-2004/05/25 (1.1.29)
                            2004/09/22-2004/09/23 (1.1.30)
                            2005/05/04-2005/05/04 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2010/01/06-2010/01/06 (2.2)
                            2010/01/29-2010/01/29 (2.3)
                            2011/09/28-2011/09/28 (2.4)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef FILE_FIND_HPP
#define FILE_FIND_HPP

#include <welink.h>

namespace Windows
{
namespace Base
{

//The declaration of CFileFind
class CFileFind:
    public WIN32_FIND_DATA
{
public:
    explicit CFileFind(LPCTSTR a_szFileName);
    ~CFileFind(void);
    void Next(void);
    operator bool(void)const;
    bool IsFile(void)const;
    bool IsFolder(void)const;
protected:
    HANDLE m_hFind;
    bool m_bFind;
private:
    CFileFind(const CFileFind& a_rFind);
    const CFileFind& operator=(const CFileFind& a_rFind);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of FileFind.hpp

\*_________________________________________________________*/
