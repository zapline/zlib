/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ComArray.hpp

    Comment:                encapsulation of COM Safe Array

    Class Name:             Windows::Component::CArray

    Version:                5.1

    Build:                  19

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/12-2003/01/13 (1.0)
                            2004/03/21-2004/04/24 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2004/11/07-2004/11/07 (1.1.5)
                            2005/01/08-2005/01/08 (1.1.6)
                            2005/05/01-2005/05/03 (2.0)
                            2005/06/12-2005/06/12 (2.1)
                            2005/08/28-2005/08/28 (3.0)
                            2005/09/23-2005/09/23 (3.1)
                            2010/01/22-2010/01/23 (4.0)
                            2010/01/30-2010/02/01 (4.1)
                            2010/04/25-2010/04/25 (5.0)
                            2011/07/18-2011/07/18 (5.1)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef COM_ARRAY_HPP
#define COM_ARRAY_HPP

#include <wedef.h>
#include <we_pragma.h>

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#undef VARIANT_TRUE
#define VARIANT_TRUE ((VARIANT_BOOL)-1)
#endif

namespace Windows
{
namespace Component
{

//The declaration of CArray
template<unsigned int t_nDimension>
class CArray
{
public:
    typedef SAFEARRAYBOUND CBound[t_nDimension];
    typedef long CIndices[t_nDimension];
public:
    inline CArray(void);
    inline CArray(SAFEARRAY* a_pArray);
    inline ~CArray(void);
    inline operator SAFEARRAY*(void)const;
    inline SAFEARRAY** operator&(void);
    inline void AttachFromReturn(SAFEARRAY* a_pArray);
    inline SAFEARRAY* DetachToReturn(void);
    inline bool Create(VARTYPE a_eType, const CBound* a_pBound);
    inline void GetElement(const CIndices* a_pIndices, BSTR* a_pszValue);
    inline void GetElement(const CIndices* a_pIndices, VARIANT* a_pValue);
    inline void GetElement(const CIndices* a_pIndices, IUnknown** a_ppInterface);
    inline void GetElement(const CIndices* a_pIndices, IDispatch** a_ppInterface);
    inline void GetElement(const CIndices* a_pIndices, bool& a_rbValue);
    inline void GetElement(const CIndices* a_pIndices, char& a_rcValue);
    inline void GetElement(const CIndices* a_pIndices, unsigned char& a_rcValue);
    inline void GetElement(const CIndices* a_pIndices, short& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, unsigned short& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, int& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, unsigned int& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, long& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, unsigned long& a_rnValue);
    inline void GetElement(const CIndices* a_pIndices, float& a_rfValue);
    inline void GetElement(const CIndices* a_pIndices, double& a_rfValue);
    inline void SetElement(const CIndices* a_pIndices, BSTR a_szValue);
    inline void SetElement(const CIndices* a_pIndices, VARIANT a_Value);
    inline void SetElement(const CIndices* a_pIndices, IUnknown* a_pInterface);
    inline void SetElement(const CIndices* a_pIndices, IDispatch* a_pInterface);
    inline void SetElement(const CIndices* a_pIndices, bool a_bValue);
    inline void SetElement(const CIndices* a_pIndices, char a_cValue);
    inline void SetElement(const CIndices* a_pIndices, unsigned char a_cValue);
    inline void SetElement(const CIndices* a_pIndices, short a_nValue);
    inline void SetElement(const CIndices* a_pIndices, unsigned short a_nValue);
    inline void SetElement(const CIndices* a_pIndices, int a_nValue);
    inline void SetElement(const CIndices* a_pIndices, unsigned int a_nValue);
    inline void SetElement(const CIndices* a_pIndices, long a_nValue);
    inline void SetElement(const CIndices* a_pIndices, unsigned long a_nValue);
    inline void SetElement(const CIndices* a_pIndices, float a_fValue);
    inline void SetElement(const CIndices* a_pIndices, double a_fValue);
private:
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
    VARTYPE m_eType;
#endif
    CBound m_Bound;
#endif
    SAFEARRAY* m_pArray;
private:
    inline bool GetElement(const CIndices* a_pIndices, void* a_pValue, unsigned int a_nBufferSize);
    inline bool SetElement(const CIndices* a_pIndices, void* a_pValue);
public:
    CArray(const CArray<t_nDimension>& a_rArray); //do not call this function
private:
    const CArray<t_nDimension>& operator=(const CArray<t_nDimension>& a_rArray);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The definition of CArray
template<unsigned int t_nDimension>
inline CArray<t_nDimension>::CArray(void):
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
    m_eType(VT_EMPTY),
#endif
    //m_Bound(),
#endif
    m_pArray((SAFEARRAY*)NULL)
{
    return;
}

template<unsigned int t_nDimension>
inline CArray<t_nDimension>::CArray(SAFEARRAY* a_pArray):
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
    m_eType(VT_EMPTY),
#endif
    //m_Bound(),
#endif
    m_pArray((SAFEARRAY*)NULL)
{
    if( a_pArray!=(SAFEARRAY*)NULL )
    {
        ASSERT( ::SafeArrayGetDim(a_pArray)==t_nDimension );
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
        VERIFY( ::SafeArrayGetVartype(a_pArray,&m_eType)==S_OK );
        ASSERT( m_eType==VT_INT || m_eType==VT_I1 || m_eType==VT_I2 || m_eType==VT_I4 ||
            m_eType==VT_UINT || m_eType==VT_UI1 || m_eType==VT_UI2 || m_eType==VT_UI4 ||
            m_eType==VT_R4 || m_eType==VT_R8 || m_eType==VT_BOOL ||
            m_eType==VT_BSTR || m_eType==VT_VARIANT ||
            m_eType==VT_UNKNOWN || m_eType==VT_DISPATCH ||
            m_eType==VT_CY || m_eType==VT_DATE || m_eType==VT_DECIMAL || m_eType==VT_ERROR ||
            m_eType==VT_RECORD );
#endif
        for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
        {
            long nLowerBound = 0;
            long nUpperBound = 0;
            VERIFY( ::SafeArrayGetLBound(a_pArray,nDimension+1,&nLowerBound)==S_OK );
            VERIFY( ::SafeArrayGetUBound(a_pArray,nDimension+1,&nUpperBound)==S_OK );
            ASSERT( nUpperBound>=nLowerBound );
            nUpperBound++;
            m_Bound[nDimension].cElements = nUpperBound-nLowerBound;
            m_Bound[nDimension].lLbound = nLowerBound;
        }
#endif
        HRESULT hResult = ::SafeArrayCopy(a_pArray,&m_pArray);
        ASSERT( hResult!=E_INVALIDARG );
        if( hResult==S_OK )
        {
            ASSERT( m_pArray!=(SAFEARRAY*)NULL );
        }
        else
        {
            ASSERT( hResult==E_OUTOFMEMORY );
            ASSERT( m_pArray==(SAFEARRAY*)NULL );
            RETAIL_MESSAGE(TRUE,(TEXT("\nERROR: Windows::Component::CArray::CArray() - ::SafeArrayCopy() fail! HRESULT=0x%08lX\n\n"),(ULONG)hResult));
        }
        __UNREFERENCED_PARAMETER(hResult);
    }
    return;
}

template<unsigned int t_nDimension>
inline CArray<t_nDimension>::~CArray(void)
{
    if( m_pArray!=(SAFEARRAY*)NULL )
    {
        VERIFY( ::SafeArrayDestroy(m_pArray)==S_OK );
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
        m_eType = VT_EMPTY;
#endif
        for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
        {
            m_Bound[nDimension].cElements = 0;
            m_Bound[nDimension].lLbound = 0;
        }
        m_pArray = (SAFEARRAY*)NULL;
#endif
    }
    return;
}

template<unsigned int t_nDimension>
inline CArray<t_nDimension>::operator SAFEARRAY*(void)const
{
    return m_pArray;
}

template<unsigned int t_nDimension>
inline SAFEARRAY** CArray<t_nDimension>::operator&(void)
{
    ASSERT( m_pArray==(SAFEARRAY*)NULL );
    return &m_pArray;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::AttachFromReturn(SAFEARRAY* a_pArray)
{
    ASSERT( m_pArray==(SAFEARRAY*)NULL );
    if( a_pArray!=(SAFEARRAY*)NULL )
    {
        ASSERT( ::SafeArrayGetDim(a_pArray)==t_nDimension );
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
        VERIFY( ::SafeArrayGetVartype(a_pArray,&m_eType)==S_OK );
        ASSERT( m_eType==VT_INT || m_eType==VT_I1 || m_eType==VT_I2 || m_eType==VT_I4 ||
            m_eType==VT_UINT || m_eType==VT_UI1 || m_eType==VT_UI2 || m_eType==VT_UI4 ||
            m_eType==VT_R4 || m_eType==VT_R8 || m_eType==VT_BOOL ||
            m_eType==VT_BSTR || m_eType==VT_VARIANT ||
            m_eType==VT_UNKNOWN || m_eType==VT_DISPATCH ||
            m_eType==VT_CY || m_eType==VT_DATE || m_eType==VT_DECIMAL || m_eType==VT_ERROR ||
            m_eType==VT_RECORD );
#endif
        for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
        {
            long nLowerBound = 0;
            long nUpperBound = 0;
            VERIFY( ::SafeArrayGetLBound(a_pArray,nDimension+1,&nLowerBound)==S_OK );
            VERIFY( ::SafeArrayGetUBound(a_pArray,nDimension+1,&nUpperBound)==S_OK );
            ASSERT( nUpperBound>=nLowerBound );
            nUpperBound++;
            m_Bound[nDimension].cElements = nUpperBound-nLowerBound;
            m_Bound[nDimension].lLbound = nLowerBound;
        }
#endif
    }
    m_pArray = a_pArray;
    return;
}

template<unsigned int t_nDimension>
inline SAFEARRAY* CArray<t_nDimension>::DetachToReturn(void)
{
    SAFEARRAY* pArray = m_pArray;
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
    m_eType = VT_EMPTY;
#endif
    for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
    {
        m_Bound[nDimension].cElements = 0;
        m_Bound[nDimension].lLbound = 0;
    }
#endif
    m_pArray = (SAFEARRAY*)NULL;
    return pArray;
}

template<unsigned int t_nDimension>
inline bool CArray<t_nDimension>::Create(VARTYPE a_eType, const CBound* a_pBound)
{
    ASSERT( a_eType==VT_INT || a_eType==VT_I1 || a_eType==VT_I2 || a_eType==VT_I4 ||
        a_eType==VT_UINT || a_eType==VT_UI1 || a_eType==VT_UI2 || a_eType==VT_UI4 ||
        a_eType==VT_R4 || a_eType==VT_R8 || a_eType==VT_BOOL ||
        a_eType==VT_BSTR || a_eType==VT_VARIANT ||
        a_eType==VT_UNKNOWN || a_eType==VT_DISPATCH ||
        a_eType==VT_CY || a_eType==VT_DATE || a_eType==VT_DECIMAL || a_eType==VT_ERROR ||
        a_eType==VT_RECORD );
    ASSERT( a_pBound!=(const CBound*)NULL );
    ASSERT( m_pArray==(SAFEARRAY*)NULL );
#if (defined _DEBUG)
#if !(defined _WIN32_WCE)
    m_eType = a_eType;
#endif
    for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
    {
        ASSERT( (*a_pBound)[nDimension].cElements>0 );
        m_Bound[nDimension].cElements = (*a_pBound)[nDimension].cElements;
        m_Bound[nDimension].lLbound = (*a_pBound)[nDimension].lLbound;
    }
#endif
    m_pArray = ::SafeArrayCreate(a_eType,t_nDimension,const_cast<SAFEARRAYBOUND*>(*a_pBound));
    return m_pArray!=(SAFEARRAY*)NULL;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, BSTR* a_pszValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( a_pszValue!=(BSTR*)NULL );
    ASSERT( *a_pszValue==(BSTR)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_BSTR );
#endif
    VERIFY( GetElement(a_pIndices,(void*)a_pszValue,sizeof(*a_pszValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, VARIANT* a_pValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( a_pValue!=(VARIANT*)NULL );
    ASSERT( a_pValue->vt==VT_EMPTY );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_VARIANT );
#endif
    VERIFY( GetElement(a_pIndices,(void*)a_pValue,sizeof(*a_pValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, IUnknown** a_ppInterface)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( a_ppInterface!=(IUnknown**)NULL );
    ASSERT( *a_ppInterface==(IUnknown*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UNKNOWN );
#endif
    VERIFY( GetElement(a_pIndices,(void*)a_ppInterface,sizeof(*a_ppInterface)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, IDispatch** a_ppInterface)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( a_ppInterface!=(IDispatch**)NULL );
    ASSERT( *a_ppInterface==(IDispatch*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_DISPATCH );
#endif
    VERIFY( GetElement(a_pIndices,(void*)a_ppInterface,sizeof(*a_ppInterface)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, bool& a_rbValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rbValue!=(bool*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_BOOL );
#endif
    VARIANT_BOOL bValue = VARIANT_FALSE;
    VERIFY( GetElement(a_pIndices,(void*)&bValue,sizeof(bValue)) );
    ASSERT( bValue==VARIANT_TRUE || bValue==VARIANT_FALSE );
    a_rbValue = (bValue==VARIANT_TRUE);
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, char& a_rcValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rcValue!=(char*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I1 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rcValue,sizeof(a_rcValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, unsigned char& a_rcValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rcValue!=(unsigned char*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI1 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rcValue,sizeof(a_rcValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, short& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(short*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I2 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, unsigned short& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(unsigned short*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI2 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, int& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(int*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_INT );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, unsigned int& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(unsigned int*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UINT );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, long& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(long*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I4 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, unsigned long& a_rnValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rnValue!=(unsigned long*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI4 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rnValue,sizeof(a_rnValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, float& a_rfValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rfValue!=(float*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_R4 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rfValue,sizeof(a_rfValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, double& a_rfValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( &a_rfValue!=(double*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_R8 );
#endif
    VERIFY( GetElement(a_pIndices,(void*)&a_rfValue,sizeof(a_rfValue)) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, BSTR a_szValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_BSTR );
#endif
    VERIFY( SetElement(a_pIndices,(void*)a_szValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, VARIANT a_Value)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_VARIANT );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_Value) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, IUnknown* a_pInterface)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UNKNOWN );
#endif
    VERIFY( SetElement(a_pIndices,(void*)a_pInterface) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, IDispatch* a_pInterface)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_DISPATCH );
#endif
    VERIFY( SetElement(a_pIndices,(void*)a_pInterface) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, bool a_bValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_BOOL );
#endif
    VARIANT_BOOL bValue = a_bValue ? VARIANT_TRUE : VARIANT_FALSE;
    VERIFY( SetElement(a_pIndices,(void*)&bValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, char a_cValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I1 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_cValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, unsigned char a_cValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI1 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_cValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, short a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I2 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, unsigned short a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI2 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, int a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_INT );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, unsigned int a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UINT );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, long a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_I4 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, unsigned long a_nValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_UI4 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_nValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, float a_fValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_R4 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_fValue) );
    return;
}

template<unsigned int t_nDimension>
inline void CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, double a_fValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if !(defined _WIN32_WCE)
    ASSERT( m_eType==VT_R8 );
#endif
    VERIFY( SetElement(a_pIndices,(void*)&a_fValue) );
    return;
}

template<unsigned int t_nDimension>
inline bool CArray<t_nDimension>::GetElement(const CIndices* a_pIndices, void* a_pValue, unsigned int a_nBufferSize)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( a_pValue!=(void*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
    ASSERT( a_nBufferSize==::SafeArrayGetElemsize(m_pArray) );
#if (defined _DEBUG)
    for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
    {
        long nIndex = (*a_pIndices)[nDimension];
        long nLowerBound = m_Bound[nDimension].lLbound;
        long nUpperBound = nLowerBound+m_Bound[nDimension].cElements;
        ASSERT( nIndex>=nLowerBound );
        ASSERT( nIndex<nUpperBound );
    }
#endif
    HRESULT hResult = ::SafeArrayGetElement(m_pArray,const_cast<long*>(*a_pIndices),a_pValue);
    ASSERT( hResult!=DISP_E_BADINDEX );
    ASSERT( hResult!=E_INVALIDARG );
    if( hResult!=S_OK )
    {
        ASSERT( hResult==E_OUTOFMEMORY );
        RETAIL_MESSAGE(TRUE,(TEXT("\nERROR: Windows::Component::CArray::GetElement() - ::SafeArrayGetElement() fail! HRESULT=0x%08lX\n\n"),(ULONG)hResult));
    }
    __UNREFERENCED_PARAMETER(a_nBufferSize);
    return hResult==S_OK;
}

template<unsigned int t_nDimension>
inline bool CArray<t_nDimension>::SetElement(const CIndices* a_pIndices, void* a_pValue)
{
    ASSERT( a_pIndices!=(const CIndices*)NULL );
    ASSERT( m_pArray!=(SAFEARRAY*)NULL );
#if (defined _DEBUG)
    for(unsigned int nDimension=0; nDimension<t_nDimension; nDimension++)
    {
        long nIndex = (*a_pIndices)[nDimension];
        long nLowerBound = m_Bound[nDimension].lLbound;
        long nUpperBound = nLowerBound+m_Bound[nDimension].cElements;
        ASSERT( nIndex>=nLowerBound );
        ASSERT( nIndex<nUpperBound );
    }
#endif
    HRESULT hResult = ::SafeArrayPutElement(m_pArray,const_cast<long*>(*a_pIndices),a_pValue);
    ASSERT( hResult!=DISP_E_BADINDEX );
    ASSERT( hResult!=E_INVALIDARG );
    if( hResult!=S_OK )
    {
        ASSERT( hResult==E_OUTOFMEMORY );
        RETAIL_MESSAGE(TRUE,(TEXT("\nERROR: Windows::Component::CArray::SetElement() - ::SafeArrayPutElement() fail! HRESULT=0x%08lX\n\n"),(ULONG)hResult));
    }
    return hResult==S_OK;
}

}
}

#include <we_pragma_2.h>
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ComArray.hpp

\*_________________________________________________________*/
