/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              CriticalSection.hpp

    Comment:                encapsulation of Critical Section object

    Class Name:             Windows::Base::Synchronization::CCriticalSection
                            Windows::Base::Synchronization::CAutoLock
                            Windows::Base::Synchronization::CAutoUnlock

    Version:                3.3

    Build:                  11

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/06/09-2004/06/09 (1.0)
                            2004/09/23-2004/09/23 (1.1)
                            2005/04/23-2005/04/23 (1.2)
                            2005/07/31-2005/07/31 (2.0)
                            2005/09/24-2005/09/24 (3.0)
                            2010/01/09-2010/01/09 (3.1)
                            2010/02/01-2010/02/01 (3.2)
                            2011/11/16-2011/11/16 (3.3)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef CRITICAL_SECTION_HPP
#define CRITICAL_SECTION_HPP

#include <we_pragma.h>

namespace Windows
{
namespace Base
{
namespace Synchronization
{

//The declaration of CCriticalSection
class CCriticalSection:
    CRITICAL_SECTION
{
public:
    inline CCriticalSection(void);
    inline ~CCriticalSection(void);
    inline void Enter(void);
    inline void Leave(void);
private:
    CCriticalSection(const CCriticalSection& a_rCriticalSection);
    const CCriticalSection& operator=(const CCriticalSection& a_rCriticalSection);
};

//The declaration of CAutoLock
class CAutoLock
{
public:
    inline explicit CAutoLock(CCriticalSection& a_rCriticalSection);
    inline ~CAutoLock(void);
private:
    CCriticalSection& m_rCriticalSection;
private:
    CAutoLock(const CAutoLock& a_rAuto);
    const CAutoLock& operator=(const CAutoLock& a_rAuto);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The declaration of CAutoUnlock
class CAutoUnlock
{
public:
    inline explicit CAutoUnlock(CCriticalSection& a_rCriticalSection);
    inline ~CAutoUnlock(void);
private:
    CCriticalSection& m_rCriticalSection;
private:
    CAutoUnlock(const CAutoUnlock& a_rAuto);
    const CAutoUnlock& operator=(const CAutoUnlock& a_rAuto);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The definition of CCriticalSection
inline CCriticalSection::CCriticalSection(void)
{
    ::InitializeCriticalSection(static_cast<CRITICAL_SECTION*>(this));
    return;
}

inline CCriticalSection::~CCriticalSection(void)
{
    ::DeleteCriticalSection(static_cast<CRITICAL_SECTION*>(this));
    return;
}

inline void CCriticalSection::Enter(void)
{
    ::EnterCriticalSection(static_cast<CRITICAL_SECTION*>(this));
    return;
}

inline void CCriticalSection::Leave(void)
{
    ::LeaveCriticalSection(static_cast<CRITICAL_SECTION*>(this));
    return;
}

//The definition of CAutoLock
inline CAutoLock::CAutoLock(CCriticalSection& a_rCriticalSection):
    m_rCriticalSection(a_rCriticalSection)
{
    ASSERT( &m_rCriticalSection!=(CCriticalSection*)NULL );
    m_rCriticalSection.Enter();
    return;
}

inline CAutoLock::~CAutoLock(void)
{
    m_rCriticalSection.Leave();
    return;
}

//The definition of CAutoUnlock
inline CAutoUnlock::CAutoUnlock(CCriticalSection& a_rCriticalSection):
    m_rCriticalSection(a_rCriticalSection)
{
    ASSERT( &m_rCriticalSection!=(CCriticalSection*)NULL );
    m_rCriticalSection.Leave();
    return;
}

inline CAutoUnlock::~CAutoUnlock(void)
{
    m_rCriticalSection.Enter();
    return;
}

}
}
}

#include <we_pragma_2.h>
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of CriticalSection.hpp

\*_________________________________________________________*/
