/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              SubclassWindow.hpp

    Comment:                encapsulation of Subclass Window

    Class Name:             Windows::UserInterface::CSubclassWindow

    Version:                1.7

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/11/20-2004/11/20 (1.0.1)
                            2005/01/08-2005/01/08 (1.0.2)
                            2005/05/04-2005/05/04 (1.1)
                            2005/05/28-2005/05/28 (1.2)
                            2005/06/19-2005/06/19 (1.3)
                            2005/09/25-2005/09/25 (1.4)
                            2010/01/16-2010/01/16 (1.5)
                            2010/01/30-2010/01/30 (1.6)
                            2011/10/04-2011/10/04 (1.7)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef SUBCLASS_WINDOW_HPP
#define SUBCLASS_WINDOW_HPP

#include <Window.hpp>
#include <welink.h>

namespace Windows
{
namespace UserInterface
{

//The declaration of CSubclassWindow
class CSubclassWindow:
    public CWindow
{
public:
    CSubclassWindow(void);
    ~CSubclassWindow(void);
    void Attach(HWND a_hWindow);
    void Detach(void);
protected:
    WNDPROC m_fnOriginalWindowProcedure;
protected:
    virtual LRESULT WindowProcedure(UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
private:
    virtual void OnAttach(void);
    virtual void OnDetach(void);
    static LRESULT CALLBACK WindowProcedure(HWND a_hWindow, UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    using CWindow::Create;
    using CWindow::Destroy;
    using CWindow::Attach;
    using CWindow::Detach;
    CSubclassWindow(const CSubclassWindow& a_rWindow);
    const CSubclassWindow& operator=(const CSubclassWindow& a_rWindow);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of SubclassWindow.hpp

\*_________________________________________________________*/
