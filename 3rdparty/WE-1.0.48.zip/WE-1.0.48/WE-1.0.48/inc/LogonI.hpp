/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              LogonI.hpp

    Comment:                interface of Winlogon GINA

    Interface Name:         Windows::Security::ILogonGina
                            Windows::Security::ILogon

    Version:                3.0

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/12/25-2004/12/26 (1.0.1)
                            2004/12/29-2004/12/29 (1.0.2)
                            2005/01/09-2005/01/09 (1.0.3)
                            2005/05/04-2005/05/07 (1.1)
                            2005/07/31-2005/07/31 (1.2)
                            2005/09/25-2005/09/25 (1.3)
                            2008/06/21-2008/06/21 (2.0)
                            2010/01/25-2010/01/25 (3.0)

    Notice:
    Copyright (C) 2010, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef LOGON_INTERFACE_HPP
#define LOGON_INTERFACE_HPP

typedef WLX_DISPATCH_VERSION_1_4 WLX_DISPATCH;
typedef WLX_PROFILE_V2_0 WLX_PROFILE;
typedef PWLX_PROFILE_V2_0 PWLX_PROFILE;
typedef WLX_CONSOLESWITCH_CREDENTIALS_INFO_V1_0 WLX_CONSOLESWITCH_CREDENTIALS_INFO;

namespace Windows
{
namespace Security
{

class ILogon;

//The declaration of ILogonGina
class ILogonGina
{
protected:
    inline ILogonGina(void){};
    inline ~ILogonGina(void){};
public:
    virtual bool Negotiate(DWORD a_dwWinlogonVersion, DWORD* a_pdwLogonVersion)=0;
    virtual ILogon* Initialize(LPCWSTR a_szWindowStation, HANDLE a_hWinlogon, const WLX_DISPATCH* a_pWinlogonFunctionTable)=0;
private:
    ILogonGina(const ILogonGina& a_rLogonGina);
    const ILogonGina& operator=(const ILogonGina& a_rLogonGina);
};

//The declaration of ILogon
class ILogon
{
protected:
    inline ILogon(void){};
    inline ~ILogon(void){};
public:
    virtual bool DisplayStatusMessage(HDESK a_hDesktop, DWORD a_dwOptions, LPCWSTR a_szTitle, LPCWSTR a_szMessage)=0;
    virtual bool RemoveStatusMessage(void)=0;
    virtual void DisplaySASNotice(void)=0;
    virtual void DisplayLockedNotice(void)=0;
    virtual int LoggedOutSAS(DWORD a_dwSasType, LUID& a_rAuthenticationId, SID& a_rLogonSid, DWORD& a_rdwOptions, HANDLE& a_rhToken, WLX_MPR_NOTIFY_INFO& a_rNetworkProviderNotifyInfo, PWLX_PROFILE& a_rpProfile)=0;
    virtual int LoggedOnSAS(DWORD a_dwSasType)=0;
    virtual int LockedSAS(DWORD a_dwSasType)=0;
    virtual bool ActivateUserShell(LPCWSTR a_szDesktopName, LPCWSTR a_szNetworkProviderLogonScript, void* a_pEnvironment)=0;
    virtual bool StartApplication(LPCWSTR a_szDesktopName, LPCWSTR a_szCommandLine, void* a_pEnvironment)=0;
    virtual void Logoff(void)=0;
    virtual void Shutdown(DWORD a_dwShutdownType)=0;
    virtual bool IsLockOK(void)=0;
    virtual bool IsLogoffOK(void)=0;
    virtual bool ScreenSaverNotify(bool a_bSecure, bool& a_rbLock)=0;
    virtual bool GetConsoleSwitchCredentials(WLX_CONSOLESWITCH_CREDENTIALS_INFO& a_rInfo)=0;
    virtual bool GetStatusMessage(DWORD& a_rdwOptions, LPWSTR a_szMessage, DWORD a_dwBufferSize)=0;
    virtual bool NetworkProviderLoad(WLX_MPR_NOTIFY_INFO& a_rNetworkProviderNotifyInfo)=0;
    virtual void DisconnectNotify(void)=0;
    virtual void ReconnectNotify(void)=0;
private:
    ILogon(const ILogon& a_rLogon);
    const ILogon& operator=(const ILogon& a_rLogon);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of LogonI.hpp

\*_________________________________________________________*/
