/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Language.hpp

    Comment:                encapsulation of Language

    Type Name:              Windows::International::EPrimaryLanguage
                            Windows::International::ESublanguage
                            Windows::International::ELanguageID
                            Windows::International::ESortOrder

    Version:                1.4

    Build:                  6

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/11/28-2004/11/28 (0.5)
                            2005/05/04-2005/05/05 (1.0)
                            2010/01/18-2010/01/19 (1.1)
                            2010/02/02-2010/02/02 (1.2)
                            2011/10/26-2011/10/26 (1.3)
                            2011/11/19-2011/11/19 (1.4)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
/*
Notes

1. undocumented LANG_*
    LANG_SUTU       0x30
    LANG_TSONGA     0x31
    LANG_VENDA      0x33
    LANG_YIDDISH    0x3d
    LANG_BURMESE    0x55
    LANG_CHEROKEE   0x5c
    LANG_EDO        0x66
    LANG_FULFULDE   0x67
    LANG_IBIBIO     0x69
    LANG_KANURI     0x71
    LANG_OROMO      0x72
    LANG_GUARANI    0x74
    LANG_HAWAIIAN   0x75
    LANG_LATIN      0x76
    LANG_SOMALI     0x77
    LANG_PAPIAMENTU 0x79

2. missing/undefined LANG_*
    0x7b, 0x7d, 0x89, 0x8a, 0x8b

3. missing/undefined SUBLANG_*
    SUBLANG_ENGLISH_0x0e
    SUBLANG_ENGLISH_0x0f
    SUBLANG_TAMAZIGHT_0x01
    SUBLANG_KASHMIRI_0x01
    SUBLANG_TIGRIGNA_0x01

4. missing/undefined SORT_*
    SORT_JAPANESE_0x2
    SORT_JAPANESE_0x3
*/

#ifndef LANGUAGE_HPP
#define LANGUAGE_HPP

//The definition of LANG_*
#if !(defined LANG_PERSIAN)
#define LANG_PERSIAN       LANG_FARSI
#endif
#define LANG_ROMANSH       0x17
#define LANG_BOSNIAN       0x1a
#define LANG_TAJIK         0x28
#define LANG_UPPER_SORBIAN 0x2e
#define LANG_LOWER_SORBIAN 0x2e
#define LANG_SUTU          0x30
#define LANG_TSONGA        0x31
#define LANG_TSWANA        0x32
#define LANG_VENDA         0x33
#define LANG_XHOSA         0x34
#define LANG_ZULU          0x35
#define LANG_MALTESE       0x3a
#define LANG_SAMI          0x3b
#define LANG_IRISH         0x3c
#define LANG_YIDDISH       0x3d
#if !(defined LANG_KYRGYZ)
#define LANG_KYRGYZ        0x40
#endif
#define LANG_TURKMEN       0x42
#if !(defined LANG_MONGOLIAN)
#define LANG_MONGOLIAN     0x50
#endif
#define LANG_TIBETAN       0x51
#define LANG_WELSH         0x52
#define LANG_KHMER         0x53
#define LANG_LAO           0x54
#define LANG_BURMESE       0x55
#if !(defined LANG_GALICIAN)
#define LANG_GALICIAN      0x56
#endif
#if !(defined LANG_SYRIAC)
#define LANG_SYRIAC        0x5a
#endif
#define LANG_SINHALESE     0x5b
#define LANG_CHEROKEE      0x5c
#define LANG_INUKTITUT     0x5d
#define LANG_AMHARIC       0x5e
#define LANG_TAMAZIGHT     0x5f
#define LANG_FRISIAN       0x62
#define LANG_PASHTO        0x63
#define LANG_FILIPINO      0x64
#if !(defined LANG_DIVEHI)
#define LANG_DIVEHI        0x65
#endif
#define LANG_EDO           0x66
#define LANG_FULFULDE      0x67
#define LANG_HAUSA         0x68
#define LANG_IBIBIO        0x69
#define LANG_YORUBA        0x6a
#define LANG_QUECHUA       0x6b
#define LANG_SOTHO         0x6c
#define LANG_BASHKIR       0x6d
#define LANG_LUXEMBOURGISH 0x6e
#define LANG_GREENLANDIC   0x6f
#define LANG_IGBO          0x70
#define LANG_KANURI        0x71
#define LANG_OROMO         0x72
#define LANG_TIGRIGNA      0x73
#define LANG_GUARANI       0x74
#define LANG_HAWAIIAN      0x75
#define LANG_LATIN         0x76
#define LANG_SOMALI        0x77
#define LANG_YI            0x78
#define LANG_PAPIAMENTU    0x79
#define LANG_MAPUDUNGUN    0x7a
#define LANG_MOHAWK        0x7c
#define LANG_BRETON        0x7e
#define LANG_UIGHUR        0x80
#define LANG_MAORI         0x81
#define LANG_OCCITAN       0x82
#define LANG_CORSICAN      0x83
#define LANG_ALSATIAN      0x84
#define LANG_YAKUT         0x85
#define LANG_KICHE         0x86
#define LANG_KINYARWANDA   0x87
#define LANG_WOLOF         0x88
#define LANG_DARI          0x8c

//The definition of SUBLANG_*
#if !(defined SUBLANG_BULGARIAN_BULGARIA)
#define SUBLANG_BULGARIAN_BULGARIA                  SUBLANG_DEFAULT
#define SUBLANG_CATALAN_CATALAN                     SUBLANG_DEFAULT
#define SUBLANG_CZECH_CZECH_REPUBLIC                SUBLANG_DEFAULT
#define SUBLANG_DANISH_DENMARK                      SUBLANG_DEFAULT
#define SUBLANG_GREEK_GREECE                        SUBLANG_DEFAULT
#define SUBLANG_FINNISH_FINLAND                     SUBLANG_DEFAULT
#define SUBLANG_HEBREW_ISRAEL                       SUBLANG_DEFAULT
#define SUBLANG_HUNGARIAN_HUNGARY                   SUBLANG_DEFAULT
#define SUBLANG_ICELANDIC_ICELAND                   SUBLANG_DEFAULT
#define SUBLANG_JAPANESE_JAPAN                      SUBLANG_DEFAULT
#define SUBLANG_POLISH_POLAND                       SUBLANG_DEFAULT
#define SUBLANG_ROMANSH_SWITZERLAND                 SUBLANG_DEFAULT
#define SUBLANG_ROMANIAN_ROMANIA                    SUBLANG_DEFAULT
#define SUBLANG_RUSSIAN_RUSSIA                      SUBLANG_DEFAULT
#define SUBLANG_CROATIAN_CROATIA                    SUBLANG_DEFAULT
#define SUBLANG_SERBIAN_CROATIA                     SUBLANG_DEFAULT
#define SUBLANG_SLOVAK_SLOVAKIA                     SUBLANG_DEFAULT
#define SUBLANG_ALBANIAN_ALBANIA                    SUBLANG_DEFAULT
#define SUBLANG_THAI_THAILAND                       SUBLANG_DEFAULT
#define SUBLANG_TURKISH_TURKEY                      SUBLANG_DEFAULT
#define SUBLANG_INDONESIAN_INDONESIA                SUBLANG_DEFAULT
#define SUBLANG_UKRAINIAN_UKRAINE                   SUBLANG_DEFAULT
#define SUBLANG_BELARUSIAN_BELARUS                  SUBLANG_DEFAULT
#define SUBLANG_SLOVENIAN_SLOVENIA                  SUBLANG_DEFAULT
#define SUBLANG_ESTONIAN_ESTONIA                    SUBLANG_DEFAULT
#define SUBLANG_LATVIAN_LATVIA                      SUBLANG_DEFAULT
#define SUBLANG_TAJIK_TAJIKISTAN                    SUBLANG_DEFAULT
#define SUBLANG_PERSIAN_IRAN                        SUBLANG_DEFAULT
#define SUBLANG_VIETNAMESE_VIETNAM                  SUBLANG_DEFAULT
#define SUBLANG_ARMENIAN_ARMENIA                    SUBLANG_DEFAULT
#define SUBLANG_BASQUE_BASQUE                       SUBLANG_DEFAULT
#define SUBLANG_MACEDONIAN_MACEDONIA                SUBLANG_DEFAULT
#define SUBLANG_TSWANA_SOUTH_AFRICA                 SUBLANG_DEFAULT
#define SUBLANG_XHOSA_SOUTH_AFRICA                  SUBLANG_DEFAULT
#define SUBLANG_ZULU_SOUTH_AFRICA                   SUBLANG_DEFAULT
#define SUBLANG_AFRIKAANS_SOUTH_AFRICA              SUBLANG_DEFAULT
#define SUBLANG_GEORGIAN_GEORGIA                    SUBLANG_DEFAULT
#define SUBLANG_FAEROESE_FAROE_ISLANDS              SUBLANG_DEFAULT
#define SUBLANG_HINDI_INDIA                         SUBLANG_DEFAULT
#define SUBLANG_MALTESE_MALTA                       SUBLANG_DEFAULT
#define SUBLANG_KAZAK_KAZAKHSTAN                    SUBLANG_DEFAULT
#define SUBLANG_KYRGYZ_KYRGYZSTAN                   SUBLANG_DEFAULT
#define SUBLANG_TURKMEN_TURKMENISTAN                SUBLANG_DEFAULT
#define SUBLANG_TATAR_RUSSIA                        SUBLANG_DEFAULT
#define SUBLANG_BENGALI_INDIA                       SUBLANG_DEFAULT
#define SUBLANG_PUNJABI_INDIA                       SUBLANG_DEFAULT
#define SUBLANG_GUJARATI_INDIA                      SUBLANG_DEFAULT
#define SUBLANG_ORIYA_INDIA                         SUBLANG_DEFAULT
#define SUBLANG_TAMIL_INDIA                         SUBLANG_DEFAULT
#define SUBLANG_TELUGU_INDIA                        SUBLANG_DEFAULT
#define SUBLANG_KANNADA_INDIA                       SUBLANG_DEFAULT
#define SUBLANG_MALAYALAM_INDIA                     SUBLANG_DEFAULT
#define SUBLANG_ASSAMESE_INDIA                      SUBLANG_DEFAULT
#define SUBLANG_MARATHI_INDIA                       SUBLANG_DEFAULT
#define SUBLANG_SANSKRIT_INDIA                      SUBLANG_DEFAULT
#define SUBLANG_MONGOLIAN_CYRILLIC_MONGOLIA         SUBLANG_DEFAULT
#define SUBLANG_TIBETAN_PRC                         SUBLANG_DEFAULT
#define SUBLANG_WELSH_UNITED_KINGDOM                SUBLANG_DEFAULT
#define SUBLANG_KHMER_CAMBODIA                      SUBLANG_DEFAULT
#define SUBLANG_LAO_LAO                             SUBLANG_DEFAULT
#define SUBLANG_GALICIAN_GALICIAN                   SUBLANG_DEFAULT
#define SUBLANG_KONKANI_INDIA                       SUBLANG_DEFAULT
#define SUBLANG_SINDHI_PAKISTAN                     SUBLANG_DEFAULT
#define SUBLANG_SINHALESE_SRI_LANKA                 SUBLANG_DEFAULT
#define SUBLANG_INUKTITUT_CANADA                    SUBLANG_DEFAULT
#define SUBLANG_AMHARIC_ETHIOPIA                    SUBLANG_DEFAULT
#define SUBLANG_NEPALI_NEPAL                        SUBLANG_DEFAULT
#define SUBLANG_FRISIAN_NETHERLANDS                 SUBLANG_DEFAULT
#define SUBLANG_PASHTO_AFGHANISTAN                  SUBLANG_DEFAULT
#define SUBLANG_FILIPINO_PHILIPPINES                SUBLANG_DEFAULT
#define SUBLANG_DIVEHI_MALDIVES                     SUBLANG_DEFAULT
#define SUBLANG_HAUSA_NIGERIA_LATIN                 SUBLANG_DEFAULT
#define SUBLANG_YORUBA_NIGERIA                      SUBLANG_DEFAULT
#define SUBLANG_QUECHUA_BOLIVIA                     SUBLANG_DEFAULT
#define SUBLANG_SOTHO_NORTHERN_SOUTH_AFRICA         SUBLANG_DEFAULT
#define SUBLANG_BASHKIR_RUSSIA                      SUBLANG_DEFAULT
#define SUBLANG_LUXEMBOURGISH_LUXEMBOURG            SUBLANG_DEFAULT
#define SUBLANG_GREENLANDIC_GREENLAND               SUBLANG_DEFAULT
#define SUBLANG_IGBO_NIGERIA                        SUBLANG_DEFAULT
#define SUBLANG_YI_PRC                              SUBLANG_DEFAULT
#define SUBLANG_MAPUDUNGUN_CHILE                    SUBLANG_DEFAULT
#define SUBLANG_MOHAWK_MOHAWK                       SUBLANG_DEFAULT
#define SUBLANG_BRETON_FRANCE                       SUBLANG_DEFAULT
#define SUBLANG_UIGHUR_PRC                          SUBLANG_DEFAULT
#define SUBLANG_MAORI_NEW_ZEALAND                   SUBLANG_DEFAULT
#define SUBLANG_OCCITAN_FRANCE                      SUBLANG_DEFAULT
#define SUBLANG_CORSICAN_FRANCE                     SUBLANG_DEFAULT
#define SUBLANG_ALSATIAN_FRANCE                     SUBLANG_DEFAULT
#define SUBLANG_YAKUT_RUSSIA                        SUBLANG_DEFAULT
#define SUBLANG_KICHE_GUATEMALA                     SUBLANG_DEFAULT
#define SUBLANG_KINYARWANDA_RWANDA                  SUBLANG_DEFAULT
#define SUBLANG_WOLOF_SENEGAL                       SUBLANG_DEFAULT
#define SUBLANG_DARI_AFGHANISTAN                    SUBLANG_DEFAULT
#endif
#define SUBLANG_CUSTOM_DEFAULT                      0x03
#define SUBLANG_CUSTOM_UNSPECIFIED                  0x04
#define SUBLANG_UI_CUSTOM_DEFAULT                   0x05
#define SUBLANG_ENGLISH_IRELAND                     SUBLANG_ENGLISH_EIRE
#define SUBLANG_ENGLISH_INDIA                       0x10
#define SUBLANG_ENGLISH_MALAYSIA                    0x11
#define SUBLANG_ENGLISH_SINGAPORE                   0x12
#define SUBLANG_SPANISH_US                          0x15
#define SUBLANG_KOREAN_JOHAB                        0x02
#define SUBLANG_PORTUGUESE_PORTUGAL                 SUBLANG_PORTUGUESE
#define SUBLANG_CROATIAN_BOSNIA_HERZEGOVINA_LATIN   0x04
#define SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_LATIN    0x06
#define SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_CYRILLIC 0x07
#define SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_LATIN    0x05
#define SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_CYRILLIC 0x08
#define SUBLANG_SWEDISH_SWEDEN                      SUBLANG_SWEDISH
#define SUBLANG_LITHUANIAN_LITHUANIA                SUBLANG_LITHUANIAN
#define SUBLANG_LITHUANIAN_CLASSIC                  0x02
#define SUBLANG_FARSI_IRAN                          SUBLANG_DEFAULT
#define SUBLANG_UPPER_SORBIAN_GERMANY               0x01
#define SUBLANG_LOWER_SORBIAN_GERMANY               0x02
#define SUBLANG_SAMI_NORTHERN_NORWAY                0x01
#define SUBLANG_SAMI_NORTHERN_SWEDEN                0x02
#define SUBLANG_SAMI_NORTHERN_FINLAND               0x03
#define SUBLANG_SAMI_LULE_NORWAY                    0x04
#define SUBLANG_SAMI_LULE_SWEDEN                    0x05
#define SUBLANG_SAMI_SOUTHERN_NORWAY                0x06
#define SUBLANG_SAMI_SOUTHERN_SWEDEN                0x07
#define SUBLANG_SAMI_SKOLT_FINLAND                  0x08
#define SUBLANG_SAMI_INARI_FINLAND                  0x09
#define SUBLANG_IRISH_IRELAND                       0x02
#define SUBLANG_SWAHILI                             SUBLANG_DEFAULT
#define SUBLANG_BENGALI_BANGLADESH                  0x02
#define SUBLANG_MONGOLIAN_PRC                       0x02
#define SUBLANG_SINDHI_AFGHANISTAN                  0x02
#define SUBLANG_SYRIAC                              SUBLANG_DEFAULT
#define SUBLANG_INUKTITUT_CANADA_LATIN              0x02
#define SUBLANG_TAMAZIGHT_ALGERIA_LATIN             0x02
#define SUBLANG_KASHMIRI_SASIA                      0x02
#define SUBLANG_QUECHUA_ECUADOR                     0x02
#define SUBLANG_QUECHUA_PERU                        0x03
#define SUBLANG_TIGRIGNA_ERITREA                    0x02

//The definition of SORT_*
#define SORT_INVARIANT_MATH         0x1
#define SORT_CHINESE_RADICALSTROKE  0x4
#define SORT_JAPANESE_RADICALSTROKE 0x4

#if !(defined RC_INVOKED)

namespace Windows
{
namespace International
{

//The definition of EPrimaryLanguage
enum EPrimaryLanguage
{
    eNeutral       = LANG_NEUTRAL,       //0x00
    eArabic        = LANG_ARABIC,        //0x01
    eBulgarian     = LANG_BULGARIAN,     //0x02
    eCatalan       = LANG_CATALAN,       //0x03
    eChinese       = LANG_CHINESE,       //0x04
    eCzech         = LANG_CZECH,         //0x05
    eDanish        = LANG_DANISH,        //0x06
    eGerman        = LANG_GERMAN,        //0x07
    eGreek         = LANG_GREEK,         //0x08
    eEnglish       = LANG_ENGLISH,       //0x09
    eSpanish       = LANG_SPANISH,       //0x0a
    eFinnish       = LANG_FINNISH,       //0x0b
    eFrench        = LANG_FRENCH,        //0x0c
    eHebrew        = LANG_HEBREW,        //0x0d
    eHungarian     = LANG_HUNGARIAN,     //0x0e
    eIcelandic     = LANG_ICELANDIC,     //0x0f
    eItalian       = LANG_ITALIAN,       //0x10
    eJapanese      = LANG_JAPANESE,      //0x11
    eKorean        = LANG_KOREAN,        //0x12
    eDutch         = LANG_DUTCH,         //0x13
    eNorwegian     = LANG_NORWEGIAN,     //0x14
    ePolish        = LANG_POLISH,        //0x15
    ePortuguese    = LANG_PORTUGUESE,    //0x16
    eRomansh       = LANG_ROMANSH,       //0x17
    eRomanian      = LANG_ROMANIAN,      //0x18
    eRussian       = LANG_RUSSIAN,       //0x19
    eCroatian      = LANG_CROATIAN,      //0x1a
    eSerbian       = LANG_SERBIAN,       //0x1a
    eBosnian       = LANG_BOSNIAN,       //0x1a
    eSlovak        = LANG_SLOVAK,        //0x1b
    eAlbanian      = LANG_ALBANIAN,      //0x1c
    eSwedish       = LANG_SWEDISH,       //0x1d
    eThai          = LANG_THAI,          //0x1e
    eTurkish       = LANG_TURKISH,       //0x1f
    eUrdu          = LANG_URDU,          //0x20
    eIndonesian    = LANG_INDONESIAN,    //0x21
    eUkrainian     = LANG_UKRAINIAN,     //0x22
    eBelarusian    = LANG_BELARUSIAN,    //0x23
    eSlovenian     = LANG_SLOVENIAN,     //0x24
    eEstonian      = LANG_ESTONIAN,      //0x25
    eLatvian       = LANG_LATVIAN,       //0x26
    eLithuanian    = LANG_LITHUANIAN,    //0x27
    eTajik         = LANG_TAJIK,         //0x28
    ePersian       = LANG_PERSIAN,       //0x29
    eFarsi         = LANG_FARSI,         //0x29
    eVietnamese    = LANG_VIETNAMESE,    //0x2a
    eArmenian      = LANG_ARMENIAN,      //0x2b
    eAzeri         = LANG_AZERI,         //0x2c
    eBasque        = LANG_BASQUE,        //0x2d
    eUpperSorbian  = LANG_UPPER_SORBIAN, //0x2e
    eLowerSorbian  = LANG_LOWER_SORBIAN, //0x2e
    eMacedonian    = LANG_MACEDONIAN,    //0x2f
    eSutu          = LANG_SUTU,          //0x30
    eXitsonga      = LANG_TSONGA,        //0x31
    eTsonga        = LANG_TSONGA,        //0x31
    eSetswana      = LANG_TSWANA,        //0x32
    eTswana        = LANG_TSWANA,        //0x32
    eLuvenda       = LANG_VENDA,         //0x33
    eTshivenda     = LANG_VENDA,         //0x33
    eVenda         = LANG_VENDA,         //0x33
    eIsiXhosa      = LANG_XHOSA,         //0x34
    eXhosa         = LANG_XHOSA,         //0x34
    eIsiZulu       = LANG_ZULU,          //0x35
    eZulu          = LANG_ZULU,          //0x35
    eAfrikaans     = LANG_AFRIKAANS,     //0x36
    eGeorgian      = LANG_GEORGIAN,      //0x37
    eFaeroese      = LANG_FAEROESE,      //0x38
    eHindi         = LANG_HINDI,         //0x39
    eMaltese       = LANG_MALTESE,       //0x3a
    eSami          = LANG_SAMI,          //0x3b
    eIrish         = LANG_IRISH,         //0x3c
    eYiddish       = LANG_YIDDISH,       //0x3d
    eMalay         = LANG_MALAY,         //0x3e
    eKazak         = LANG_KAZAK,         //0x3f
    eKyrgyz        = LANG_KYRGYZ,        //0x40
    eSwahili       = LANG_SWAHILI,       //0x41
    eTurkmen       = LANG_TURKMEN,       //0x42
    eUzbek         = LANG_UZBEK,         //0x43
    eTatar         = LANG_TATAR,         //0x44
    eBengali       = LANG_BENGALI,       //0x45
    ePunjabi       = LANG_PUNJABI,       //0x46
    eGujarati      = LANG_GUJARATI,      //0x47
    eOriya         = LANG_ORIYA,         //0x48
    eTamil         = LANG_TAMIL,         //0x49
    eTelugu        = LANG_TELUGU,        //0x4a
    eKannada       = LANG_KANNADA,       //0x4b
    eMalayalam     = LANG_MALAYALAM,     //0x4c
    eAssamese      = LANG_ASSAMESE,      //0x4d
    eMarathi       = LANG_MARATHI,       //0x4e
    eSanskrit      = LANG_SANSKRIT,      //0x4f
    eMongolian     = LANG_MONGOLIAN,     //0x50
    eTibetan       = LANG_TIBETAN,       //0x51
    eWelsh         = LANG_WELSH,         //0x52
    eKhmer         = LANG_KHMER,         //0x53
    eLao           = LANG_LAO,           //0x54
    eBurmese       = LANG_BURMESE,       //0x55
    eGalician      = LANG_GALICIAN,      //0x56
    eKonkani       = LANG_KONKANI,       //0x57
    eManipuri      = LANG_MANIPURI,      //0x58
    eSindhi        = LANG_SINDHI,        //0x59
    eSyriac        = LANG_SYRIAC,        //0x5a
    eSinhalese     = LANG_SINHALESE,     //0x5b
    eCherokee      = LANG_CHEROKEE,      //0x5c
    eInuktitut     = LANG_INUKTITUT,     //0x5d
    eAmharic       = LANG_AMHARIC,       //0x5e
    eTamazight     = LANG_TAMAZIGHT,     //0x5f
    eKashmiri      = LANG_KASHMIRI,      //0x60
    eNepali        = LANG_NEPALI,        //0x61
    eFrisian       = LANG_FRISIAN,       //0x62
    ePashto        = LANG_PASHTO,        //0x63
    eFilipino      = LANG_FILIPINO,      //0x64
    eDivehi        = LANG_DIVEHI,        //0x65
    eEdo           = LANG_EDO,           //0x66
    eFulfulde      = LANG_FULFULDE,      //0x67
    eHausa         = LANG_HAUSA,         //0x68
    eIbibio        = LANG_IBIBIO,        //0x69
    eYoruba        = LANG_YORUBA,        //0x6a
    eQuechua       = LANG_QUECHUA,       //0x6b
    eSesothSaLeboa = LANG_SOTHO,         //0x6c
    eSotho         = LANG_SOTHO,         //0x6c
    eBashkir       = LANG_BASHKIR,       //0x6d
    eLuxembourgish = LANG_LUXEMBOURGISH, //0x6e
    eGreenlandic   = LANG_GREENLANDIC,   //0x6f
    eIgbo          = LANG_IGBO,          //0x70
    eKanuri        = LANG_KANURI,        //0x71
    eAfaanOromoo   = LANG_OROMO,         //0x72
    eOromo         = LANG_OROMO,         //0x72
    eTigrigna      = LANG_TIGRIGNA,      //0x73
    eGuarani       = LANG_GUARANI,       //0x74
    eHawaiian      = LANG_HAWAIIAN,      //0x75
    eLatin         = LANG_LATIN,         //0x76
    eAfSoomaali    = LANG_SOMALI,        //0x77
    eSomali        = LANG_SOMALI,        //0x77
    eYi            = LANG_YI,            //0x78
    ePapiamentu    = LANG_PAPIAMENTU,    //0x79
    eMapudungun    = LANG_MAPUDUNGUN,    //0x7a
    //0x7b
    eMohawk        = LANG_MOHAWK,        //0x7c
    //0x7d
    eBreton        = LANG_BRETON,        //0x7e
    eUyghur        = LANG_UIGHUR,        //0x80
    eUighur        = LANG_UIGHUR,        //0x80
    eMaori         = LANG_MAORI,         //0x81
    eOccitan       = LANG_OCCITAN,       //0x82
    eCorsican      = LANG_CORSICAN,      //0x83
    eAlsatian      = LANG_ALSATIAN,      //0x84
    eYakut         = LANG_YAKUT,         //0x85
    eKiche         = LANG_KICHE,         //0x86
    eKinyarwanda   = LANG_KINYARWANDA,   //0x87
    eWolof         = LANG_WOLOF,         //0x88
    //0x89
    //0x8a
    //0x8b
    eDari          = LANG_DARI,          //0x8c
    eInvariant     = LANG_INVARIANT,     //0x7f
};

//The definition of ESublanguage
enum ESublanguage
{
    eNeutralSublanguage           = SUBLANG_NEUTRAL,            //0x00
    eUserDefaultSublanguage       = SUBLANG_DEFAULT,            //0x01
    eSystemDefaultSublanguage     = SUBLANG_SYS_DEFAULT,        //0x02
    eCustomDefaultSublanguage     = SUBLANG_CUSTOM_DEFAULT,     //0x03
    eCustomUnspecifiedSublanguage = SUBLANG_CUSTOM_UNSPECIFIED, //0x04
    eCustomMuiDefaultSublanguage  = SUBLANG_UI_CUSTOM_DEFAULT,  //0x05
    eArabicSaudiArabia = SUBLANG_ARABIC_SAUDI_ARABIA, //0x01
    eArabicIraq        = SUBLANG_ARABIC_IRAQ,         //0x02
    eArabicEgypt       = SUBLANG_ARABIC_EGYPT,        //0x03
    eArabicLibya       = SUBLANG_ARABIC_LIBYA,        //0x04
    eArabicAlgeria     = SUBLANG_ARABIC_ALGERIA,      //0x05
    eArabicMorocco     = SUBLANG_ARABIC_MOROCCO,      //0x06
    eArabicTunisia     = SUBLANG_ARABIC_TUNISIA,      //0x07
    eArabicOman        = SUBLANG_ARABIC_OMAN,         //0x08
    eArabicYemen       = SUBLANG_ARABIC_YEMEN,        //0x09
    eArabicSyria       = SUBLANG_ARABIC_SYRIA,        //0x0a
    eArabicJordan      = SUBLANG_ARABIC_JORDAN,       //0x0b
    eArabicLebanon     = SUBLANG_ARABIC_LEBANON,      //0x0c
    eArabicKuwait      = SUBLANG_ARABIC_KUWAIT,       //0x0d
    eArabicUAE         = SUBLANG_ARABIC_UAE,          //0x0e
    eArabicBahrain     = SUBLANG_ARABIC_BAHRAIN,      //0x0f
    eArabicQatar       = SUBLANG_ARABIC_QATAR,        //0x10
    eBulgarianBulgaria = SUBLANG_BULGARIAN_BULGARIA, //0x01
    eCatalanSpain = SUBLANG_CATALAN_CATALAN, //0x01
    eChineseTraditional = SUBLANG_CHINESE_TRADITIONAL, //0x01
    eChineseSimplified  = SUBLANG_CHINESE_SIMPLIFIED,  //0x02
    eChineseHongkong    = SUBLANG_CHINESE_HONGKONG,    //0x03
    eChineseSingapore   = SUBLANG_CHINESE_SINGAPORE,   //0x04
    eChineseMacau       = SUBLANG_CHINESE_MACAU,       //0x05
    eCzechCzechRepublic = SUBLANG_CZECH_CZECH_REPUBLIC, //0x01
    eDanishDenmark = SUBLANG_DANISH_DENMARK, //0x01
    eGermanGermany       = SUBLANG_GERMAN,               //0x01
    eGermanSwitzerland   = SUBLANG_GERMAN_SWISS,         //0x02
    eGermanAustria       = SUBLANG_GERMAN_AUSTRIAN,      //0x03
    eGermanLuxembourg    = SUBLANG_GERMAN_LUXEMBOURG,    //0x04
    eGermanLiechtenstein = SUBLANG_GERMAN_LIECHTENSTEIN, //0x05
    eGreekGreece = SUBLANG_GREEK_GREECE, //0x01
    eEnglishUnitedStates   = SUBLANG_ENGLISH_US,           //0x01
    eEnglishUnitedKingdom  = SUBLANG_ENGLISH_UK,           //0x02
    eEnglishAustralia      = SUBLANG_ENGLISH_AUS,          //0x03
    eEnglishCanada         = SUBLANG_ENGLISH_CAN,          //0x04
    eEnglishNewZealand     = SUBLANG_ENGLISH_NZ,           //0x05
    eEnglishIreland        = SUBLANG_ENGLISH_IRELAND,      //0x06
    eEnglishEire           = SUBLANG_ENGLISH_EIRE,         //0x06
    eEnglishSouthAfrica    = SUBLANG_ENGLISH_SOUTH_AFRICA, //0x07
    eEnglishJamaica        = SUBLANG_ENGLISH_JAMAICA,      //0x08
    eEnglishCaribbean      = SUBLANG_ENGLISH_CARIBBEAN,    //0x09
    eEnglishBelize         = SUBLANG_ENGLISH_BELIZE,       //0x0a
    eEnglishTrinidadTobago = SUBLANG_ENGLISH_TRINIDAD,     //0x0b
    eEnglishZimbabwe       = SUBLANG_ENGLISH_ZIMBABWE,     //0x0c
    eEnglishPhilippines    = SUBLANG_ENGLISH_PHILIPPINES,  //0x0d
    //0x0e
    //0x0f
    eEnglishIndia          = SUBLANG_ENGLISH_INDIA,        //0x10
    eEnglishMalaysia       = SUBLANG_ENGLISH_MALAYSIA,     //0x11
    eEnglishSingapore      = SUBLANG_ENGLISH_SINGAPORE,    //0x12
    eSpanishTraditional       = SUBLANG_SPANISH,                    //0x01
    eSpanishCastilian         = SUBLANG_SPANISH,                    //0x01
    eSpanishMexico            = SUBLANG_SPANISH_MEXICAN,            //0x02
    eSpanishModern            = SUBLANG_SPANISH_MODERN,             //0x03
    eSpanishGuatemala         = SUBLANG_SPANISH_GUATEMALA,          //0x04
    eSpanishCostaRica         = SUBLANG_SPANISH_COSTA_RICA,         //0x05
    eSpanishPanama            = SUBLANG_SPANISH_PANAMA,             //0x06
    eSpanishDominicanRepublic = SUBLANG_SPANISH_DOMINICAN_REPUBLIC, //0x07
    eSpanishVenezuela         = SUBLANG_SPANISH_VENEZUELA,          //0x08
    eSpanishColombia          = SUBLANG_SPANISH_COLOMBIA,           //0x09
    eSpanishPeru              = SUBLANG_SPANISH_PERU,               //0x0a
    eSpanishArgentina         = SUBLANG_SPANISH_ARGENTINA,          //0x0b
    eSpanishEcuador           = SUBLANG_SPANISH_ECUADOR,            //0x0c
    eSpanishChile             = SUBLANG_SPANISH_CHILE,              //0x0d
    eSpanishUruguay           = SUBLANG_SPANISH_URUGUAY,            //0x0e
    eSpanishParaguay          = SUBLANG_SPANISH_PARAGUAY,           //0x0f
    eSpanishBolivia           = SUBLANG_SPANISH_BOLIVIA,            //0x10
    eSpanishElSalvador        = SUBLANG_SPANISH_EL_SALVADOR,        //0x11
    eSpanishHonduras          = SUBLANG_SPANISH_HONDURAS,           //0x12
    eSpanishNicaragua         = SUBLANG_SPANISH_NICARAGUA,          //0x13
    eSpanishPuertoRico        = SUBLANG_SPANISH_PUERTO_RICO,        //0x14
    eSpanishUnitedStates      = SUBLANG_SPANISH_US,                 //0x15
    eFinnishFinland = SUBLANG_FINNISH_FINLAND, //0x01
    eFrenchFrance      = SUBLANG_FRENCH,            //0x01
    eFrenchBelgium     = SUBLANG_FRENCH_BELGIAN,    //0x02
    eFrenchCanada      = SUBLANG_FRENCH_CANADIAN,   //0x03
    eFrenchSwitzerland = SUBLANG_FRENCH_SWISS,      //0x04
    eFrenchLuxembourg  = SUBLANG_FRENCH_LUXEMBOURG, //0x05
    eFrenchMonaco      = SUBLANG_FRENCH_MONACO,     //0x06
    eHebrewIsrael = SUBLANG_HEBREW_ISRAEL, //0x01
    eHungarianHungary = SUBLANG_HUNGARIAN_HUNGARY, //0x01
    eIcelandicIceland = SUBLANG_ICELANDIC_ICELAND, //0x01
    eItalianItaly       = SUBLANG_ITALIAN,       //0x01
    eItalianSwitzerland = SUBLANG_ITALIAN_SWISS, //0x02
    eJapaneseJapan = SUBLANG_JAPANESE_JAPAN, //0x01
    eKoreanKorea = SUBLANG_KOREAN,       //0x01
    eKoreanJOHAB = SUBLANG_KOREAN_JOHAB, //0x02
    eDutchNetherlands = SUBLANG_DUTCH,         //0x01
    eDutchBelgium     = SUBLANG_DUTCH_BELGIAN, //0x02
    eNorwegianBokmal  = SUBLANG_NORWEGIAN_BOKMAL,  //0x01
    eNorwegianNynorsk = SUBLANG_NORWEGIAN_NYNORSK, //0x02
    ePolishPoland = SUBLANG_POLISH_POLAND, //0x01
    ePortugueseBrazil   = SUBLANG_PORTUGUESE_BRAZILIAN, //0x01
    ePortuguesePortugal = SUBLANG_PORTUGUESE_PORTUGAL,  //0x02
    eRomanshSwitzerland = SUBLANG_ROMANSH_SWITZERLAND, //0x01
    eRomanianRomania = SUBLANG_ROMANIAN_ROMANIA, //0x01
    eRussianRussia = SUBLANG_RUSSIAN_RUSSIA, //0x01
    eCroatianCroatia                = SUBLANG_CROATIAN_CROATIA,                  //0x01
    eCroatianBosniaHerzegovinaLatin = SUBLANG_CROATIAN_BOSNIA_HERZEGOVINA_LATIN, //0x04
    eSerbianCroatia                   = SUBLANG_SERBIAN_CROATIA,                     //0x01
    eSerbianSerbiaMontenegroLatin     = SUBLANG_SERBIAN_LATIN,                       //0x02
    eSerbianSerbiaMontenegroCyrillic  = SUBLANG_SERBIAN_CYRILLIC,                    //0x03
    eSerbianBosniaHerzegovinaLatin    = SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_LATIN,    //0x06
    eSerbianBosniaHerzegovinaCyrillic = SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_CYRILLIC, //0x07
    eBosnianBosniaHerzegovinaLatin    = SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_LATIN,    //0x05
    eBosnianBosniaHerzegovinaCyrillic = SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_CYRILLIC, //0x08
    eSlovakSlovakia = SUBLANG_SLOVAK_SLOVAKIA, //0x01
    eAlbanianAlbania = SUBLANG_ALBANIAN_ALBANIA, //0x01
    eSwedishSweden  = SUBLANG_SWEDISH_SWEDEN,  //0x01
    eSwedishFinland = SUBLANG_SWEDISH_FINLAND, //0x02
    eThaiThailand = SUBLANG_THAI_THAILAND, //0x01
    eTurkishTurkey = SUBLANG_TURKISH_TURKEY, //0x01
    eUrduPakistan = SUBLANG_URDU_PAKISTAN, //0x01
    eUrduIndia    = SUBLANG_URDU_INDIA,    //0x02
    eIndonesianIndonesia = SUBLANG_INDONESIAN_INDONESIA, //0x01
    eUkrainianUkraine = SUBLANG_UKRAINIAN_UKRAINE, //0x01
    eBelarusianBelarus = SUBLANG_BELARUSIAN_BELARUS, //0x01
    eSlovenianSlovenia = SUBLANG_SLOVENIAN_SLOVENIA, //0x01
    eEstonianEstonia = SUBLANG_ESTONIAN_ESTONIA, //0x01
    eLatvianLatvia = SUBLANG_LATVIAN_LATVIA, //0x01
    eLithuanianLithuania = SUBLANG_LITHUANIAN_LITHUANIA, //0x01
    eLithuanianClassic   = SUBLANG_LITHUANIAN_CLASSIC,   //0x02
    eTajikTajikistan = SUBLANG_TAJIK_TAJIKISTAN, //0x01
    ePersianIran = SUBLANG_PERSIAN_IRAN, //0x01
    eFarsiIran = SUBLANG_FARSI_IRAN, //0x01
    eVietnameseVietnam = SUBLANG_VIETNAMESE_VIETNAM, //0x01
    eArmenianArmenia = SUBLANG_ARMENIAN_ARMENIA, //0x01
    eAzeriAzerbaijanLatin    = SUBLANG_AZERI_LATIN,    //0x01
    eAzeriAzerbaijanCyrillic = SUBLANG_AZERI_CYRILLIC, //0x02
    eBasqueBasque = SUBLANG_BASQUE_BASQUE, //0x01
    eUpperSorbianGermany = SUBLANG_UPPER_SORBIAN_GERMANY, //0x01
    eLowerSorbianGermany = SUBLANG_LOWER_SORBIAN_GERMANY, //0x02
    eMacedonianMacedonia = SUBLANG_MACEDONIAN_MACEDONIA, //0x01
    eSetswanaSouthAfrica = SUBLANG_TSWANA_SOUTH_AFRICA, //0x01
    eTswanaSouthAfrica = SUBLANG_TSWANA_SOUTH_AFRICA, //0x01
    eIsiXhosaSouthAfrica = SUBLANG_XHOSA_SOUTH_AFRICA, //0x01
    eXhosaSouthAfrica = SUBLANG_XHOSA_SOUTH_AFRICA, //0x01
    eIsiZuluSouthAfrica = SUBLANG_ZULU_SOUTH_AFRICA, //0x01
    eZuluSouthAfrica = SUBLANG_ZULU_SOUTH_AFRICA, //0x01
    eAfrikaansSouthAfrica = SUBLANG_AFRIKAANS_SOUTH_AFRICA, //0x01
    eGeorgianGeorgia = SUBLANG_GEORGIAN_GEORGIA, //0x01
    eFaeroeseFaroeIslands = SUBLANG_FAEROESE_FAROE_ISLANDS, //0x01
    eHindiIndia = SUBLANG_HINDI_INDIA, //0x01
    eMalteseMalta = SUBLANG_MALTESE_MALTA, //0x01
    eSamiNorthernNorway  = SUBLANG_SAMI_NORTHERN_NORWAY,  //0x01
    eSamiNorthernSweden  = SUBLANG_SAMI_NORTHERN_SWEDEN,  //0x02
    eSamiNorthernFinland = SUBLANG_SAMI_NORTHERN_FINLAND, //0x03
    eSamiLuleNorway      = SUBLANG_SAMI_LULE_NORWAY,      //0x04
    eSamiLuleSweden      = SUBLANG_SAMI_LULE_SWEDEN,      //0x05
    eSamiSouthernNorway  = SUBLANG_SAMI_SOUTHERN_NORWAY,  //0x06
    eSamiSouthernSweden  = SUBLANG_SAMI_SOUTHERN_SWEDEN,  //0x07
    eSamiSkoltFinland    = SUBLANG_SAMI_SKOLT_FINLAND,    //0x08
    eSamiInariFinland    = SUBLANG_SAMI_INARI_FINLAND,    //0x09
    eIrishIreland        = SUBLANG_IRISH_IRELAND,         //0x02
    eMalayMalaysia = SUBLANG_MALAY_MALAYSIA,          //0x01
    eMalayBrunei   = SUBLANG_MALAY_BRUNEI_DARUSSALAM, //0x02
    eKazakKazakhstan = SUBLANG_KAZAK_KAZAKHSTAN, //0x01
    eKyrgyzKyrgyzstan = SUBLANG_KYRGYZ_KYRGYZSTAN, //0x01
    eSwahiliKenya = SUBLANG_SWAHILI, //0x01
    eTurkmenTurkmenistan = SUBLANG_TURKMEN_TURKMENISTAN, //0x01
    eUzbekUzbekistanLatin    = SUBLANG_UZBEK_LATIN,    //0x01
    eUzbekUzbekistanCyrillic = SUBLANG_UZBEK_CYRILLIC, //0x02
    eTatarRussia = SUBLANG_TATAR_RUSSIA, //0x01
    eBengaliIndia      = SUBLANG_BENGALI_INDIA,      //0x01
    eBengaliBangladesh = SUBLANG_BENGALI_BANGLADESH, //0x02
    ePunjabiIndia = SUBLANG_PUNJABI_INDIA, //0x01
    eGujaratiIndia = SUBLANG_GUJARATI_INDIA, //0x01
    eOriyaIndia = SUBLANG_ORIYA_INDIA, //0x01
    eTamilIndia = SUBLANG_TAMIL_INDIA, //0x01
    eTeluguIndia = SUBLANG_TELUGU_INDIA, //0x01
    eKannadaIndia = SUBLANG_KANNADA_INDIA, //0x01
    eMalayalamIndia = SUBLANG_MALAYALAM_INDIA, //0x01
    eAssameseIndia = SUBLANG_ASSAMESE_INDIA, //0x01
    eMarathiIndia = SUBLANG_MARATHI_INDIA, //0x01
    eSanskritIndia = SUBLANG_SANSKRIT_INDIA, //0x01
    eMongolianMongoliaCyrillic = SUBLANG_MONGOLIAN_CYRILLIC_MONGOLIA, //0x01
    eMongolianChinaMong        = SUBLANG_MONGOLIAN_PRC,               //0x02
    eTibetanChina = SUBLANG_TIBETAN_PRC, //0x01
    eWelshUnitedKingdom = SUBLANG_WELSH_UNITED_KINGDOM, //0x01
    eKhmerCambodia = SUBLANG_KHMER_CAMBODIA, //0x01
    eLaoLaos = SUBLANG_LAO_LAO, //0x01
    eGalicianSpain = SUBLANG_GALICIAN_GALICIAN, //0x01
    eKonkaniIndia = SUBLANG_KONKANI_INDIA, //0x01
    eSindhiPakistan    = SUBLANG_SINDHI_PAKISTAN,    //0x01
    eSindhiAfghanistan = SUBLANG_SINDHI_AFGHANISTAN, //0x02
    eSyriacSyria = SUBLANG_SYRIAC, //0x01
    eSinhaleseSriLanka = SUBLANG_SINHALESE_SRI_LANKA, //0x01
    eInuktitutCanada      = SUBLANG_INUKTITUT_CANADA,       //0x01
    eInuktitutCanadaLatin = SUBLANG_INUKTITUT_CANADA_LATIN, //0x02
    eAmharicEthiopia = SUBLANG_AMHARIC_ETHIOPIA, //0x01
    //0x01
    eTamazightAlgeriaLatin = SUBLANG_TAMAZIGHT_ALGERIA_LATIN, //0x02
    //0x01
    eKashmiriSouthAsia = SUBLANG_KASHMIRI_SASIA, //0x02
    eNepaliNepal = SUBLANG_NEPALI_NEPAL, //0x01
    eNepaliIndia = SUBLANG_NEPALI_INDIA, //0x02
    eFrisianNetherlands = SUBLANG_FRISIAN_NETHERLANDS, //0x01
    ePashtoAfghanistan = SUBLANG_PASHTO_AFGHANISTAN, //0x01
    eFilipinoPhilippines = SUBLANG_FILIPINO_PHILIPPINES, //0x01
    eDivehiMaldives = SUBLANG_DIVEHI_MALDIVES, //0x01
    eHausaNigeria = SUBLANG_HAUSA_NIGERIA_LATIN, //0x01
    eYorubaNigeria = SUBLANG_YORUBA_NIGERIA, //0x01
    eQuechuaBolivia = SUBLANG_QUECHUA_BOLIVIA, //0x01
    eQuechuaEcuador = SUBLANG_QUECHUA_ECUADOR, //0x02
    eQuechuaPeru    = SUBLANG_QUECHUA_PERU,    //0x03
    eSesothSaLeboaSouthAfrica = SUBLANG_SOTHO_NORTHERN_SOUTH_AFRICA, //0x01
    eSothoSouthAfrica = SUBLANG_SOTHO_NORTHERN_SOUTH_AFRICA, //0x01
    eBashkirRussia = SUBLANG_BASHKIR_RUSSIA, //0x01
    eLuxembourgishLuxembourg = SUBLANG_LUXEMBOURGISH_LUXEMBOURG, //0x01
    eGreenlandicGreenland = SUBLANG_GREENLANDIC_GREENLAND, //0x01
    eIgboNigeria = SUBLANG_IGBO_NIGERIA, //0x01
    //0x01
    eTigrignaEritrea = SUBLANG_TIGRIGNA_ERITREA, //0x02
    eYiChina = SUBLANG_YI_PRC, //0x01
    eMapudungunChile = SUBLANG_MAPUDUNGUN_CHILE, //0x01
    eMohawkCanada = SUBLANG_MOHAWK_MOHAWK, //0x01
    eBretonFrance = SUBLANG_BRETON_FRANCE, //0x01
    eUyghurChina = SUBLANG_UIGHUR_PRC, //0x01
    eUighurChina = SUBLANG_UIGHUR_PRC, //0x01
    eMaoriNewZealand = SUBLANG_MAORI_NEW_ZEALAND, //0x01
    eOccitanFrance = SUBLANG_OCCITAN_FRANCE, //0x01
    eCorsicanFrance = SUBLANG_CORSICAN_FRANCE, //0x01
    eAlsatianFrance = SUBLANG_ALSATIAN_FRANCE, //0x01
    eYakutRussia = SUBLANG_YAKUT_RUSSIA, //0x01
    eKicheGuatemala = SUBLANG_KICHE_GUATEMALA, //0x01
    eKinyarwandaRwanda = SUBLANG_KINYARWANDA_RWANDA, //0x01
    eWolofSenegal = SUBLANG_WOLOF_SENEGAL, //0x01
    eDariAfghanistan = SUBLANG_DARI_AFGHANISTAN, //0x01
};

//The definition of ELanguageID
enum ELanguageID
{
    eidNeutral                          = MAKELANGID(LANG_NEUTRAL,       SUBLANG_NEUTRAL),                             //0x0000
    eidUserDefault                      = MAKELANGID(LANG_NEUTRAL,       SUBLANG_DEFAULT),                             //0x0400, LANG_USER_DEFAULT
    eidSystemDefault                    = MAKELANGID(LANG_NEUTRAL,       SUBLANG_SYS_DEFAULT),                         //0x0800, LANG_SYSTEM_DEFAULT
    eidCustomDefault                    = MAKELANGID(LANG_NEUTRAL,       SUBLANG_CUSTOM_DEFAULT),                      //0x0c00
    eidCustomUnspecified                = MAKELANGID(LANG_NEUTRAL,       SUBLANG_CUSTOM_UNSPECIFIED),                  //0x1000
    eidCustomMuiDefault                 = MAKELANGID(LANG_NEUTRAL,       SUBLANG_UI_CUSTOM_DEFAULT),                   //0x1400
    eidArabicSaudiArabia                = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_SAUDI_ARABIA),                 //0x0401
    eidArabicIraq                       = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_IRAQ),                         //0x0801
    eidArabicEgypt                      = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_EGYPT),                        //0x0c01
    eidArabicLibya                      = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_LIBYA),                        //0x1001
    eidArabicAlgeria                    = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_ALGERIA),                      //0x1401
    eidArabicMorocco                    = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_MOROCCO),                      //0x1801
    eidArabicTunisia                    = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_TUNISIA),                      //0x1c01
    eidArabicOman                       = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_OMAN),                         //0x2001
    eidArabicYemen                      = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_YEMEN),                        //0x2401
    eidArabicSyria                      = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_SYRIA),                        //0x2801
    eidArabicJordan                     = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_JORDAN),                       //0x2c01
    eidArabicLebanon                    = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_LEBANON),                      //0x3001
    eidArabicKuwait                     = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_KUWAIT),                       //0x3401
    eidArabicUAE                        = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_UAE),                          //0x3801
    eidArabicBahrain                    = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_BAHRAIN),                      //0x3c01
    eidArabicQatar                      = MAKELANGID(LANG_ARABIC,        SUBLANG_ARABIC_QATAR),                        //0x4001
    eidBulgarianBulgaria                = MAKELANGID(LANG_BULGARIAN,     SUBLANG_BULGARIAN_BULGARIA),                  //0x0402
    eidCatalanSpain                     = MAKELANGID(LANG_CATALAN,       SUBLANG_CATALAN_CATALAN),                     //0x0403
    eidChineseTraditional               = MAKELANGID(LANG_CHINESE,       SUBLANG_CHINESE_TRADITIONAL),                 //0x0404
    eidChineseSimplified                = MAKELANGID(LANG_CHINESE,       SUBLANG_CHINESE_SIMPLIFIED),                  //0x0804
    eidChineseHongkong                  = MAKELANGID(LANG_CHINESE,       SUBLANG_CHINESE_HONGKONG),                    //0x0c04
    eidChineseSingapore                 = MAKELANGID(LANG_CHINESE,       SUBLANG_CHINESE_SINGAPORE),                   //0x1004
    eidChineseMacau                     = MAKELANGID(LANG_CHINESE,       SUBLANG_CHINESE_MACAU),                       //0x1404
    eidCzechCzechRepublic               = MAKELANGID(LANG_CZECH,         SUBLANG_CZECH_CZECH_REPUBLIC),                //0x0405
    eidDanishDenmark                    = MAKELANGID(LANG_DANISH,        SUBLANG_DANISH_DENMARK),                      //0x0406
    eidGermanGermany                    = MAKELANGID(LANG_GERMAN,        SUBLANG_GERMAN),                              //0x0407
    eidGermanSwitzerland                = MAKELANGID(LANG_GERMAN,        SUBLANG_GERMAN_SWISS),                        //0x0807
    eidGermanAustria                    = MAKELANGID(LANG_GERMAN,        SUBLANG_GERMAN_AUSTRIAN),                     //0x0c07
    eidGermanLuxembourg                 = MAKELANGID(LANG_GERMAN,        SUBLANG_GERMAN_LUXEMBOURG),                   //0x1007
    eidGermanLiechtenstein              = MAKELANGID(LANG_GERMAN,        SUBLANG_GERMAN_LIECHTENSTEIN),                //0x1407
    eidGreekGreece                      = MAKELANGID(LANG_GREEK,         SUBLANG_GREEK_GREECE),                        //0x0408
    eidEnglishUnitedStates              = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_US),                          //0x0409
    eidEnglishUnitedKingdom             = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_UK),                          //0x0809
    eidEnglishAustralia                 = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_AUS),                         //0x0c09
    eidEnglishCanada                    = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_CAN),                         //0x1009
    eidEnglishNewZealand                = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_NZ),                          //0x1409
    eidEnglishIreland                   = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_IRELAND),                     //0x1809
    eidEnglishEire                      = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_EIRE),                        //0x1809
    eidEnglishSouthAfrica               = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_SOUTH_AFRICA),                //0x1c09
    eidEnglishJamaica                   = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_JAMAICA),                     //0x2009
    eidEnglishCaribbean                 = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_CARIBBEAN),                   //0x2409
    eidEnglishBelize                    = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_BELIZE),                      //0x2809
    eidEnglishTrinidadTobago            = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_TRINIDAD),                    //0x2c09
    eidEnglishZimbabwe                  = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_ZIMBABWE),                    //0x3009
    eidEnglishPhilippines               = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_PHILIPPINES),                 //0x3409
    eidEnglishIndia                     = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_INDIA),                       //0x4009
    eidEnglishMalaysia                  = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_MALAYSIA),                    //0x4409
    eidEnglishSingapore                 = MAKELANGID(LANG_ENGLISH,       SUBLANG_ENGLISH_SINGAPORE),                   //0x4809
    eidSpanishTraditional               = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH),                             //0x040a
    eidSpanishCastilian                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH),                             //0x040a
    eidSpanishMexico                    = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_MEXICAN),                     //0x080a
    eidSpanishModern                    = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_MODERN),                      //0x0c0a
    eidSpanishGuatemala                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_GUATEMALA),                   //0x100a
    eidSpanishCostaRica                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_COSTA_RICA),                  //0x140a
    eidSpanishPanama                    = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_PANAMA),                      //0x180a
    eidSpanishDominicanRepublic         = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_DOMINICAN_REPUBLIC),          //0x1c0a
    eidSpanishVenezuela                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_VENEZUELA),                   //0x200a
    eidSpanishColombia                  = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_COLOMBIA),                    //0x240a
    eidSpanishPeru                      = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_PERU),                        //0x280a
    eidSpanishArgentina                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_ARGENTINA),                   //0x2c0a
    eidSpanishEcuador                   = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_ECUADOR),                     //0x300a
    eidSpanishChile                     = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_CHILE),                       //0x340a
    eidSpanishUruguay                   = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_URUGUAY),                     //0x380a
    eidSpanishParaguay                  = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_PARAGUAY),                    //0x3c0a
    eidSpanishBolivia                   = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_BOLIVIA),                     //0x400a
    eidSpanishElSalvador                = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_EL_SALVADOR),                 //0x440a
    eidSpanishHonduras                  = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_HONDURAS),                    //0x480a
    eidSpanishNicaragua                 = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_NICARAGUA),                   //0x4c0a
    eidSpanishPuertoRico                = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_PUERTO_RICO),                 //0x500a
    eidSpanishUnitedStates              = MAKELANGID(LANG_SPANISH,       SUBLANG_SPANISH_US),                          //0x540a
    eidFinnishFinland                   = MAKELANGID(LANG_FINNISH,       SUBLANG_FINNISH_FINLAND),                     //0x040b
    eidFrenchFrance                     = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH),                              //0x040c
    eidFrenchBelgium                    = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH_BELGIAN),                      //0x080c
    eidFrenchCanada                     = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH_CANADIAN),                     //0x0c0c
    eidFrenchSwitzerland                = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH_SWISS),                        //0x100c
    eidFrenchLuxembourg                 = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH_LUXEMBOURG),                   //0x140c
    eidFrenchMonaco                     = MAKELANGID(LANG_FRENCH,        SUBLANG_FRENCH_MONACO),                       //0x180c
    eidHebrewIsrael                     = MAKELANGID(LANG_HEBREW,        SUBLANG_HEBREW_ISRAEL),                       //0x040d
    eidHungarianHungary                 = MAKELANGID(LANG_HUNGARIAN,     SUBLANG_HUNGARIAN_HUNGARY),                   //0x040e
    eidIcelandicIceland                 = MAKELANGID(LANG_ICELANDIC,     SUBLANG_ICELANDIC_ICELAND),                   //0x040f
    eidItalianItaly                     = MAKELANGID(LANG_ITALIAN,       SUBLANG_ITALIAN),                             //0x0410
    eidItalianSwitzerland               = MAKELANGID(LANG_ITALIAN,       SUBLANG_ITALIAN_SWISS),                       //0x0810
    eidJapaneseJapan                    = MAKELANGID(LANG_JAPANESE,      SUBLANG_JAPANESE_JAPAN),                      //0x0411
    eidKoreanKorea                      = MAKELANGID(LANG_KOREAN,        SUBLANG_KOREAN),                              //0x0412
    eidKoreanJOHAB                      = MAKELANGID(LANG_KOREAN,        SUBLANG_KOREAN_JOHAB),                        //0x0812
    eidDutchNetherlands                 = MAKELANGID(LANG_DUTCH,         SUBLANG_DUTCH),                               //0x0413
    eidDutchBelgium                     = MAKELANGID(LANG_DUTCH,         SUBLANG_DUTCH_BELGIAN),                       //0x0813
    eidNorwegianBokmal                  = MAKELANGID(LANG_NORWEGIAN,     SUBLANG_NORWEGIAN_BOKMAL),                    //0x0414
    eidNorwegianNynorsk                 = MAKELANGID(LANG_NORWEGIAN,     SUBLANG_NORWEGIAN_NYNORSK),                   //0x0814
    eidPolishPoland                     = MAKELANGID(LANG_POLISH,        SUBLANG_POLISH_POLAND),                       //0x0415
    eidPortugueseBrazil                 = MAKELANGID(LANG_PORTUGUESE,    SUBLANG_PORTUGUESE_BRAZILIAN),                //0x0416
    eidPortuguesePortugal               = MAKELANGID(LANG_PORTUGUESE,    SUBLANG_PORTUGUESE_PORTUGAL),                 //0x0816
    eidRomanshSwitzerland               = MAKELANGID(LANG_ROMANSH,       SUBLANG_ROMANSH_SWITZERLAND),                 //0x0417
    eidRomanianRomania                  = MAKELANGID(LANG_ROMANIAN,      SUBLANG_ROMANIAN_ROMANIA),                    //0x0418
    eidRussianRussia                    = MAKELANGID(LANG_RUSSIAN,       SUBLANG_RUSSIAN_RUSSIA),                      //0x0419
    eidCroatianCroatia                  = MAKELANGID(LANG_CROATIAN,      SUBLANG_CROATIAN_CROATIA),                    //0x041a
    eidCroatianBosniaHerzegovinaLatin   = MAKELANGID(LANG_CROATIAN,      SUBLANG_CROATIAN_BOSNIA_HERZEGOVINA_LATIN),   //0x101a
    eidSerbianCroatia                   = MAKELANGID(LANG_SERBIAN,       SUBLANG_SERBIAN_CROATIA),                     //0x041a
    eidSerbianSerbiaMontenegroLatin     = MAKELANGID(LANG_SERBIAN,       SUBLANG_SERBIAN_LATIN),                       //0x081a
    eidSerbianSerbiaMontenegroCyrillic  = MAKELANGID(LANG_SERBIAN,       SUBLANG_SERBIAN_CYRILLIC),                    //0x0c1a
    eidSerbianBosniaHerzegovinaLatin    = MAKELANGID(LANG_SERBIAN,       SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_LATIN),    //0x181a
    eidSerbianBosniaHerzegovinaCyrillic = MAKELANGID(LANG_SERBIAN,       SUBLANG_SERBIAN_BOSNIA_HERZEGOVINA_CYRILLIC), //0x1c1a
    eidBosnianBosniaHerzegovinaLatin    = MAKELANGID(LANG_BOSNIAN,       SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_LATIN),    //0x201a
    eidBosnianBosniaHerzegovinaCyrillic = MAKELANGID(LANG_BOSNIAN,       SUBLANG_BOSNIAN_BOSNIA_HERZEGOVINA_CYRILLIC), //0x141a
    eidSlovakSlovakia                   = MAKELANGID(LANG_SLOVAK,        SUBLANG_SLOVAK_SLOVAKIA),                     //0x041b
    eidAlbanianAlbania                  = MAKELANGID(LANG_ALBANIAN,      SUBLANG_ALBANIAN_ALBANIA),                    //0x041c
    eidSwedishSweden                    = MAKELANGID(LANG_SWEDISH,       SUBLANG_SWEDISH_SWEDEN),                      //0x041d
    eidSwedishFinland                   = MAKELANGID(LANG_SWEDISH,       SUBLANG_SWEDISH_FINLAND),                     //0x081d
    eidThaiThailand                     = MAKELANGID(LANG_THAI,          SUBLANG_THAI_THAILAND),                       //0x041e
    eidTurkishTurkey                    = MAKELANGID(LANG_TURKISH,       SUBLANG_TURKISH_TURKEY),                      //0x041f
    eidUrduPakistan                     = MAKELANGID(LANG_URDU,          SUBLANG_URDU_PAKISTAN),                       //0x0420
    eidUrduIndia                        = MAKELANGID(LANG_URDU,          SUBLANG_URDU_INDIA),                          //0x0820
    eidIndonesianIndonesia              = MAKELANGID(LANG_INDONESIAN,    SUBLANG_INDONESIAN_INDONESIA),                //0x0421
    eidUkrainianUkraine                 = MAKELANGID(LANG_UKRAINIAN,     SUBLANG_UKRAINIAN_UKRAINE),                   //0x0422
    eidBelarusianBelarus                = MAKELANGID(LANG_BELARUSIAN,    SUBLANG_BELARUSIAN_BELARUS),                  //0x0423
    eidSlovenianSlovenia                = MAKELANGID(LANG_SLOVENIAN,     SUBLANG_SLOVENIAN_SLOVENIA),                  //0x0424
    eidEstonianEstonia                  = MAKELANGID(LANG_ESTONIAN,      SUBLANG_ESTONIAN_ESTONIA),                    //0x0425
    eidLatvianLatvia                    = MAKELANGID(LANG_LATVIAN,       SUBLANG_LATVIAN_LATVIA),                      //0x0426
    eidLithuanianLithuania              = MAKELANGID(LANG_LITHUANIAN,    SUBLANG_LITHUANIAN_LITHUANIA),                //0x0427
    eidLithuanianClassic                = MAKELANGID(LANG_LITHUANIAN,    SUBLANG_LITHUANIAN_CLASSIC),                  //0x0827
    eidTajikTajikistan                  = MAKELANGID(LANG_TAJIK,         SUBLANG_TAJIK_TAJIKISTAN),                    //0x0428
    eidPersianIran                      = MAKELANGID(LANG_PERSIAN,       SUBLANG_PERSIAN_IRAN),                        //0x0429
    eidFarsiIran                        = MAKELANGID(LANG_FARSI,         SUBLANG_FARSI_IRAN),                          //0x0429
    eidVietnameseVietnam                = MAKELANGID(LANG_VIETNAMESE,    SUBLANG_VIETNAMESE_VIETNAM),                  //0x042a
    eidArmenianArmenia                  = MAKELANGID(LANG_ARMENIAN,      SUBLANG_ARMENIAN_ARMENIA),                    //0x042b
    eidAzeriAzerbaijanLatin             = MAKELANGID(LANG_AZERI,         SUBLANG_AZERI_LATIN),                         //0x042c
    eidAzeriAzerbaijanCyrillic          = MAKELANGID(LANG_AZERI,         SUBLANG_AZERI_CYRILLIC),                      //0x082c
    eidBasqueBasque                     = MAKELANGID(LANG_BASQUE,        SUBLANG_BASQUE_BASQUE),                       //0x042d
    eidUpperSorbianGermany              = MAKELANGID(LANG_UPPER_SORBIAN, SUBLANG_UPPER_SORBIAN_GERMANY),               //0x042e
    eidLowerSorbianGermany              = MAKELANGID(LANG_LOWER_SORBIAN, SUBLANG_LOWER_SORBIAN_GERMANY),               //0x082e
    eidMacedonianMacedonia              = MAKELANGID(LANG_MACEDONIAN,    SUBLANG_MACEDONIAN_MACEDONIA),                //0x042f
    eidSutu                             = MAKELANGID(LANG_SUTU,          SUBLANG_DEFAULT),                             //0x0430
    eidXitsonga                         = MAKELANGID(LANG_TSONGA,        SUBLANG_DEFAULT),                             //0x0431
    eidTsonga                           = MAKELANGID(LANG_TSONGA,        SUBLANG_DEFAULT),                             //0x0431
    eidSetswanaSouthAfrica              = MAKELANGID(LANG_TSWANA,        SUBLANG_TSWANA_SOUTH_AFRICA),                 //0x0432
    eidTswanaSouthAfrica                = MAKELANGID(LANG_TSWANA,        SUBLANG_TSWANA_SOUTH_AFRICA),                 //0x0432
    eidLuvenda                          = MAKELANGID(LANG_VENDA,         SUBLANG_DEFAULT),                             //0x0433
    eidTshivenda                        = MAKELANGID(LANG_VENDA,         SUBLANG_DEFAULT),                             //0x0433
    eidVenda                            = MAKELANGID(LANG_VENDA,         SUBLANG_DEFAULT),                             //0x0433
    eidIsiXhosaSouthAfrica              = MAKELANGID(LANG_XHOSA,         SUBLANG_XHOSA_SOUTH_AFRICA),                  //0x0434
    eidXhosaSouthAfrica                 = MAKELANGID(LANG_XHOSA,         SUBLANG_XHOSA_SOUTH_AFRICA),                  //0x0434
    eidIsiZuluSouthAfrica               = MAKELANGID(LANG_ZULU,          SUBLANG_ZULU_SOUTH_AFRICA),                   //0x0435
    eidZuluSouthAfrica                  = MAKELANGID(LANG_ZULU,          SUBLANG_ZULU_SOUTH_AFRICA),                   //0x0435
    eidAfrikaansSouthAfrica             = MAKELANGID(LANG_AFRIKAANS,     SUBLANG_AFRIKAANS_SOUTH_AFRICA),              //0x0436
    eidGeorgianGeorgia                  = MAKELANGID(LANG_GEORGIAN,      SUBLANG_GEORGIAN_GEORGIA),                    //0x0437
    eidFaeroeseFaroeIslands             = MAKELANGID(LANG_FAEROESE,      SUBLANG_FAEROESE_FAROE_ISLANDS),              //0x0438
    eidHindiIndia                       = MAKELANGID(LANG_HINDI,         SUBLANG_HINDI_INDIA),                         //0x0439
    eidMalteseMalta                     = MAKELANGID(LANG_MALTESE,       SUBLANG_MALTESE_MALTA),                       //0x043a
    eidSamiNorthernNorway               = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_NORTHERN_NORWAY),                //0x043b
    eidSamiNorthernSweden               = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_NORTHERN_SWEDEN),                //0x083b
    eidSamiNorthernFinland              = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_NORTHERN_FINLAND),               //0x0c3b
    eidSamiLuleNorway                   = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_LULE_NORWAY),                    //0x103b
    eidSamiLuleSweden                   = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_LULE_SWEDEN),                    //0x143b
    eidSamiSouthernNorway               = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_SOUTHERN_NORWAY),                //0x183b
    eidSamiSouthernSweden               = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_SOUTHERN_SWEDEN),                //0x1c3b
    eidSamiSkoltFinland                 = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_SKOLT_FINLAND),                  //0x203b
    eidSamiInariFinland                 = MAKELANGID(LANG_SAMI,          SUBLANG_SAMI_INARI_FINLAND),                  //0x243b
    eidIrishIreland                     = MAKELANGID(LANG_IRISH,         SUBLANG_IRISH_IRELAND),                       //0x083c
    eidYiddish                          = MAKELANGID(LANG_YIDDISH,       SUBLANG_DEFAULT),                             //0x043d
    eidMalayMalaysia                    = MAKELANGID(LANG_MALAY,         SUBLANG_MALAY_MALAYSIA),                      //0x043e
    eidMalayBrunei                      = MAKELANGID(LANG_MALAY,         SUBLANG_MALAY_BRUNEI_DARUSSALAM),             //0x083e
    eidKazakKazakhstan                  = MAKELANGID(LANG_KAZAK,         SUBLANG_KAZAK_KAZAKHSTAN),                    //0x043f
    eidKyrgyzKyrgyzstan                 = MAKELANGID(LANG_KYRGYZ,        SUBLANG_KYRGYZ_KYRGYZSTAN),                   //0x0440
    eidSwahiliKenya                     = MAKELANGID(LANG_SWAHILI,       SUBLANG_SWAHILI),                             //0x0441
    eidTurkmenTurkmenistan              = MAKELANGID(LANG_TURKMEN,       SUBLANG_TURKMEN_TURKMENISTAN),                //0x0442
    eidUzbekUzbekistanLatin             = MAKELANGID(LANG_UZBEK,         SUBLANG_UZBEK_LATIN),                         //0x0443
    eidUzbekUzbekistanCyrillic          = MAKELANGID(LANG_UZBEK,         SUBLANG_UZBEK_CYRILLIC),                      //0x0843
    eidTatarRussia                      = MAKELANGID(LANG_TATAR,         SUBLANG_TATAR_RUSSIA),                        //0x0444
    eidBengaliIndia                     = MAKELANGID(LANG_BENGALI,       SUBLANG_BENGALI_INDIA),                       //0x0445
    eidBengaliBangladesh                = MAKELANGID(LANG_BENGALI,       SUBLANG_BENGALI_BANGLADESH),                  //0x0845
    eidPunjabiIndia                     = MAKELANGID(LANG_PUNJABI,       SUBLANG_PUNJABI_INDIA),                       //0x0446
    eidGujaratiIndia                    = MAKELANGID(LANG_GUJARATI,      SUBLANG_GUJARATI_INDIA),                      //0x0447
    eidOriyaIndia                       = MAKELANGID(LANG_ORIYA,         SUBLANG_ORIYA_INDIA),                         //0x0448
    eidTamilIndia                       = MAKELANGID(LANG_TAMIL,         SUBLANG_TAMIL_INDIA),                         //0x0449
    eidTeluguIndia                      = MAKELANGID(LANG_TELUGU,        SUBLANG_TELUGU_INDIA),                        //0x044a
    eidKannadaIndia                     = MAKELANGID(LANG_KANNADA,       SUBLANG_KANNADA_INDIA),                       //0x044b
    eidMalayalamIndia                   = MAKELANGID(LANG_MALAYALAM,     SUBLANG_MALAYALAM_INDIA),                     //0x044c
    eidAssameseIndia                    = MAKELANGID(LANG_ASSAMESE,      SUBLANG_ASSAMESE_INDIA),                      //0x044d
    eidMarathiIndia                     = MAKELANGID(LANG_MARATHI,       SUBLANG_MARATHI_INDIA),                       //0x044e
    eidSanskritIndia                    = MAKELANGID(LANG_SANSKRIT,      SUBLANG_SANSKRIT_INDIA),                      //0x044f
    eidMongolianMongoliaCyrillic        = MAKELANGID(LANG_MONGOLIAN,     SUBLANG_MONGOLIAN_CYRILLIC_MONGOLIA),         //0x0450
    eidMongolianChinaMong               = MAKELANGID(LANG_MONGOLIAN,     SUBLANG_MONGOLIAN_PRC),                       //0x0850
    eidTibetanChina                     = MAKELANGID(LANG_TIBETAN,       SUBLANG_TIBETAN_PRC),                         //0x0451
    eidWelshUnitedKingdom               = MAKELANGID(LANG_WELSH,         SUBLANG_WELSH_UNITED_KINGDOM),                //0x0452
    eidKhmerCambodia                    = MAKELANGID(LANG_KHMER,         SUBLANG_KHMER_CAMBODIA),                      //0x0453
    eidLaoLaos                          = MAKELANGID(LANG_LAO,           SUBLANG_LAO_LAO),                             //0x0454
    eidBurmese                          = MAKELANGID(LANG_BURMESE,       SUBLANG_DEFAULT),                             //0x0455
    eidGalicianSpain                    = MAKELANGID(LANG_GALICIAN,      SUBLANG_GALICIAN_GALICIAN),                   //0x0456
    eidKonkaniIndia                     = MAKELANGID(LANG_KONKANI,       SUBLANG_KONKANI_INDIA),                       //0x0457
    eidManipuri                         = MAKELANGID(LANG_MANIPURI,      SUBLANG_DEFAULT),                             //0x0458
    eidSindhiPakistan                   = MAKELANGID(LANG_SINDHI,        SUBLANG_SINDHI_PAKISTAN),                     //0x0459
    eidSindhiAfghanistan                = MAKELANGID(LANG_SINDHI,        SUBLANG_SINDHI_AFGHANISTAN),                  //0x0859
    eidSyriacSyria                      = MAKELANGID(LANG_SYRIAC,        SUBLANG_SYRIAC),                              //0x045a
    eidSinhaleseSriLanka                = MAKELANGID(LANG_SINHALESE,     SUBLANG_SINHALESE_SRI_LANKA),                 //0x045b
    eidCherokee                         = MAKELANGID(LANG_CHEROKEE,      SUBLANG_DEFAULT),                             //0x045c
    eidInuktitutCanada                  = MAKELANGID(LANG_INUKTITUT,     SUBLANG_INUKTITUT_CANADA),                    //0x045d
    eidInuktitutCanadaLatin             = MAKELANGID(LANG_INUKTITUT,     SUBLANG_INUKTITUT_CANADA_LATIN),              //0x085d
    eidAmharicEthiopia                  = MAKELANGID(LANG_AMHARIC,       SUBLANG_AMHARIC_ETHIOPIA),                    //0x045e
    eidTamazightAlgeriaLatin            = MAKELANGID(LANG_TAMAZIGHT,     SUBLANG_TAMAZIGHT_ALGERIA_LATIN),             //0x085f
    eidKashmiriSouthAsia                = MAKELANGID(LANG_KASHMIRI,      SUBLANG_KASHMIRI_SASIA),                      //0x0860
    eidNepaliNepal                      = MAKELANGID(LANG_NEPALI,        SUBLANG_NEPALI_NEPAL),                        //0x0461
    eidNepaliIndia                      = MAKELANGID(LANG_NEPALI,        SUBLANG_NEPALI_INDIA),                        //0x0861
    eidFrisianNetherlands               = MAKELANGID(LANG_FRISIAN,       SUBLANG_FRISIAN_NETHERLANDS),                 //0x0462
    eidPashtoAfghanistan                = MAKELANGID(LANG_PASHTO,        SUBLANG_PASHTO_AFGHANISTAN),                  //0x0463
    eidFilipinoPhilippines              = MAKELANGID(LANG_FILIPINO,      SUBLANG_FILIPINO_PHILIPPINES),                //0x0464
    eidDivehiMaldives                   = MAKELANGID(LANG_DIVEHI,        SUBLANG_DIVEHI_MALDIVES),                     //0x0465
    eidEdo                              = MAKELANGID(LANG_EDO,           SUBLANG_DEFAULT),                             //0x0466
    eidFulfulde                         = MAKELANGID(LANG_FULFULDE,      SUBLANG_DEFAULT),                             //0x0467
    eidHausaNigeria                     = MAKELANGID(LANG_HAUSA,         SUBLANG_HAUSA_NIGERIA_LATIN),                 //0x0468
    eidIbibio                           = MAKELANGID(LANG_IBIBIO,        SUBLANG_DEFAULT),                             //0x0469
    eidYorubaNigeria                    = MAKELANGID(LANG_YORUBA,        SUBLANG_YORUBA_NIGERIA),                      //0x046a
    eidQuechuaBolivia                   = MAKELANGID(LANG_QUECHUA,       SUBLANG_QUECHUA_BOLIVIA),                     //0x046b
    eidQuechuaEcuador                   = MAKELANGID(LANG_QUECHUA,       SUBLANG_QUECHUA_ECUADOR),                     //0x086b
    eidQuechuaPeru                      = MAKELANGID(LANG_QUECHUA,       SUBLANG_QUECHUA_PERU),                        //0x0c6b
    eidSesothSaLeboaSouthAfrica         = MAKELANGID(LANG_SOTHO,         SUBLANG_SOTHO_NORTHERN_SOUTH_AFRICA),         //0x046c
    eidSothoSouthAfrica                 = MAKELANGID(LANG_SOTHO,         SUBLANG_SOTHO_NORTHERN_SOUTH_AFRICA),         //0x046c
    eidBashkirRussia                    = MAKELANGID(LANG_BASHKIR,       SUBLANG_BASHKIR_RUSSIA),                      //0x046d
    eidLuxembourgishLuxembourg          = MAKELANGID(LANG_LUXEMBOURGISH, SUBLANG_LUXEMBOURGISH_LUXEMBOURG),            //0x046e
    eidGreenlandicGreenland             = MAKELANGID(LANG_GREENLANDIC,   SUBLANG_GREENLANDIC_GREENLAND),               //0x046f
    eidIgboNigeria                      = MAKELANGID(LANG_IGBO,          SUBLANG_IGBO_NIGERIA),                        //0x0470
    eidKanuri                           = MAKELANGID(LANG_KANURI,        SUBLANG_DEFAULT),                             //0x0471
    eidAfaanOromoo                      = MAKELANGID(LANG_OROMO,         SUBLANG_DEFAULT),                             //0x0472
    eidOromo                            = MAKELANGID(LANG_OROMO,         SUBLANG_DEFAULT),                             //0x0472
    eidTigrignaEritrea                  = MAKELANGID(LANG_TIGRIGNA,      SUBLANG_TIGRIGNA_ERITREA),                    //0x0873
    eidGuarani                          = MAKELANGID(LANG_GUARANI,       SUBLANG_DEFAULT),                             //0x0474
    eidHawaiian                         = MAKELANGID(LANG_HAWAIIAN,      SUBLANG_DEFAULT),                             //0x0475
    eidLatin                            = MAKELANGID(LANG_LATIN,         SUBLANG_DEFAULT),                             //0x0476
    eidAfSoomaali                       = MAKELANGID(LANG_SOMALI,        SUBLANG_DEFAULT),                             //0x0477
    eidSomali                           = MAKELANGID(LANG_SOMALI,        SUBLANG_DEFAULT),                             //0x0477
    eidYiChina                          = MAKELANGID(LANG_YI,            SUBLANG_YI_PRC),                              //0x0478
    eidPapiamentu                       = MAKELANGID(LANG_PAPIAMENTU,    SUBLANG_DEFAULT),                             //0x0479
    eidMapudungunChile                  = MAKELANGID(LANG_MAPUDUNGUN,    SUBLANG_MAPUDUNGUN_CHILE),                    //0x047a
    eidMohawkCanada                     = MAKELANGID(LANG_MOHAWK,        SUBLANG_MOHAWK_MOHAWK),                       //0x047c
    eidBretonFrance                     = MAKELANGID(LANG_BRETON,        SUBLANG_BRETON_FRANCE),                       //0x047e
    eidUyghurChina                      = MAKELANGID(LANG_UIGHUR,        SUBLANG_UIGHUR_PRC),                          //0x0480
    eidUighurChina                      = MAKELANGID(LANG_UIGHUR,        SUBLANG_UIGHUR_PRC),                          //0x0480
    eidMaoriNewZealand                  = MAKELANGID(LANG_MAORI,         SUBLANG_MAORI_NEW_ZEALAND),                   //0x0481
    eidOccitanFrance                    = MAKELANGID(LANG_OCCITAN,       SUBLANG_OCCITAN_FRANCE),                      //0x0482
    eidCorsicanFrance                   = MAKELANGID(LANG_CORSICAN,      SUBLANG_CORSICAN_FRANCE),                     //0x0483
    eidAlsatianFrance                   = MAKELANGID(LANG_ALSATIAN,      SUBLANG_ALSATIAN_FRANCE),                     //0x0484
    eidYakutRussia                      = MAKELANGID(LANG_YAKUT,         SUBLANG_YAKUT_RUSSIA),                        //0x0485
    eidKicheGuatemala                   = MAKELANGID(LANG_KICHE,         SUBLANG_KICHE_GUATEMALA),                     //0x0486
    eidKinyarwandaRwanda                = MAKELANGID(LANG_KINYARWANDA,   SUBLANG_KINYARWANDA_RWANDA),                  //0x0487
    eidWolofSenegal                     = MAKELANGID(LANG_WOLOF,         SUBLANG_WOLOF_SENEGAL),                       //0x0488
    eidDariAfghanistan                  = MAKELANGID(LANG_DARI,          SUBLANG_DARI_AFGHANISTAN),                    //0x048c
    eidInvariant                        = MAKELANGID(LANG_INVARIANT,     SUBLANG_NEUTRAL),                             //0x007f
};

//The definition of ESortOrder
enum ESortOrder
{
    eDefaultOrder = SORT_DEFAULT, //0x0
    eInvariantMathematicalSymbol = SORT_INVARIANT_MATH, //0x1
    eChineseBIG5          = SORT_CHINESE_BIG5,          //0x0
    eChinesePhonetic      = SORT_CHINESE_PRCP,          //0x0
    eChineseUnicode       = SORT_CHINESE_UNICODE,       //0x1
    eChineseStroke        = SORT_CHINESE_PRC,           //0x2
    eChineseBoPoMoFo      = SORT_CHINESE_BOPOMOFO,      //0x3
    eChineseRadicalStroke = SORT_CHINESE_RADICALSTROKE, //0x4
    eGermanPhoneBook = SORT_GERMAN_PHONE_BOOK, //0x1
    eHungarianDefault   = SORT_HUNGARIAN_DEFAULT,   //0x0
    eHungarianTechnical = SORT_HUNGARIAN_TECHNICAL, //0x1
    eJapaneseXJIS          = SORT_JAPANESE_XJIS,          //0x0
    eJapaneseUnicode       = SORT_JAPANESE_UNICODE,       //0x1
    eJapaneseRadicalStroke = SORT_JAPANESE_RADICALSTROKE, //0x4
    eKoreanKSC     = SORT_KOREAN_KSC,     //0x0
    eKoreanUnicode = SORT_KOREAN_UNICODE, //0x1
    eGeorgianTraditional = SORT_GEORGIAN_TRADITIONAL, //0x0
    eGeorgianModern      = SORT_GEORGIAN_MODERN,      //0x1
};

}
}

#else

//The definition of LANGUAGE_ID_* for resource
#define LANGUAGE_ID_NEUTRAL                          0x0000
#define LANGUAGE_ID_USERDEFAULT                      0x0400
#define LANGUAGE_ID_SYSTEMDEFAULT                    0x0800
#define LANGUAGE_ID_CUSTOMDEFAULT                    0x0c00
#define LANGUAGE_ID_CUSTOMUNSPECIFIED                0x1000
#define LANGUAGE_ID_CUSTOMMUIDEFAULT                 0x1400
#define LANGUAGE_ID_ARABICSAUDIARABIA                0x0401
#define LANGUAGE_ID_ARABICIRAQ                       0x0801
#define LANGUAGE_ID_ARABICEGYPT                      0x0c01
#define LANGUAGE_ID_ARABICLIBYA                      0x1001
#define LANGUAGE_ID_ARABICALGERIA                    0x1401
#define LANGUAGE_ID_ARABICMOROCCO                    0x1801
#define LANGUAGE_ID_ARABICTUNISIA                    0x1c01
#define LANGUAGE_ID_ARABICOMAN                       0x2001
#define LANGUAGE_ID_ARABICYEMEN                      0x2401
#define LANGUAGE_ID_ARABICSYRIA                      0x2801
#define LANGUAGE_ID_ARABICJORDAN                     0x2c01
#define LANGUAGE_ID_ARABICLEBANON                    0x3001
#define LANGUAGE_ID_ARABICKUWAIT                     0x3401
#define LANGUAGE_ID_ARABICUAE                        0x3801
#define LANGUAGE_ID_ARABICBAHRAIN                    0x3c01
#define LANGUAGE_ID_ARABICQATAR                      0x4001
#define LANGUAGE_ID_BULGARIANBULGARIA                0x0402
#define LANGUAGE_ID_CATALANSPAIN                     0x0403
#define LANGUAGE_ID_CHINESETRADITIONAL               0x0404
#define LANGUAGE_ID_CHINESESIMPLIFIED                0x0804
#define LANGUAGE_ID_CHINESEHONGKONG                  0x0c04
#define LANGUAGE_ID_CHINESESINGAPORE                 0x1004
#define LANGUAGE_ID_CHINESEMACAU                     0x1404
#define LANGUAGE_ID_CZECHCZECHREPUBLIC               0x0405
#define LANGUAGE_ID_DANISHDENMARK                    0x0406
#define LANGUAGE_ID_GERMANGERMANY                    0x0407
#define LANGUAGE_ID_GERMANSWITZERLAND                0x0807
#define LANGUAGE_ID_GERMANAUSTRIA                    0x0c07
#define LANGUAGE_ID_GERMANLUXEMBOURG                 0x1007
#define LANGUAGE_ID_GERMANLIECHTENSTEIN              0x1407
#define LANGUAGE_ID_GREEKGREECE                      0x0408
#define LANGUAGE_ID_ENGLISHUNITEDSTATES              0x0409
#define LANGUAGE_ID_ENGLISHUNITEDKINGDOM             0x0809
#define LANGUAGE_ID_ENGLISHAUSTRALIA                 0x0c09
#define LANGUAGE_ID_ENGLISHCANADA                    0x1009
#define LANGUAGE_ID_ENGLISHNEWZEALAND                0x1409
#define LANGUAGE_ID_ENGLISHIRELAND                   0x1809
#define LANGUAGE_ID_ENGLISHEIRE                      0x1809
#define LANGUAGE_ID_ENGLISHSOUTHAFRICA               0x1c09
#define LANGUAGE_ID_ENGLISHJAMAICA                   0x2009
#define LANGUAGE_ID_ENGLISHCARIBBEAN                 0x2409
#define LANGUAGE_ID_ENGLISHBELIZE                    0x2809
#define LANGUAGE_ID_ENGLISHTRINIDADTOBAGO            0x2c09
#define LANGUAGE_ID_ENGLISHZIMBABWE                  0x3009
#define LANGUAGE_ID_ENGLISHPHILIPPINES               0x3409
#define LANGUAGE_ID_ENGLISHINDIA                     0x4009
#define LANGUAGE_ID_ENGLISHMALAYSIA                  0x4409
#define LANGUAGE_ID_ENGLISHSINGAPORE                 0x4809
#define LANGUAGE_ID_SPANISHTRADITIONAL               0x040a
#define LANGUAGE_ID_SPANISHCASTILIAN                 0x040a
#define LANGUAGE_ID_SPANISHMEXICO                    0x080a
#define LANGUAGE_ID_SPANISHMODERN                    0x0c0a
#define LANGUAGE_ID_SPANISHGUATEMALA                 0x100a
#define LANGUAGE_ID_SPANISHCOSTARICA                 0x140a
#define LANGUAGE_ID_SPANISHPANAMA                    0x180a
#define LANGUAGE_ID_SPANISHDOMINICANREPUBLIC         0x1c0a
#define LANGUAGE_ID_SPANISHVENEZUELA                 0x200a
#define LANGUAGE_ID_SPANISHCOLOMBIA                  0x240a
#define LANGUAGE_ID_SPANISHPERU                      0x280a
#define LANGUAGE_ID_SPANISHARGENTINA                 0x2c0a
#define LANGUAGE_ID_SPANISHECUADOR                   0x300a
#define LANGUAGE_ID_SPANISHCHILE                     0x340a
#define LANGUAGE_ID_SPANISHURUGUAY                   0x380a
#define LANGUAGE_ID_SPANISHPARAGUAY                  0x3c0a
#define LANGUAGE_ID_SPANISHBOLIVIA                   0x400a
#define LANGUAGE_ID_SPANISHELSALVADOR                0x440a
#define LANGUAGE_ID_SPANISHHONDURAS                  0x480a
#define LANGUAGE_ID_SPANISHNICARAGUA                 0x4c0a
#define LANGUAGE_ID_SPANISHPUERTORICO                0x500a
#define LANGUAGE_ID_SPANISHUNITEDSTATES              0x540a
#define LANGUAGE_ID_FINNISHFINLAND                   0x040b
#define LANGUAGE_ID_FRENCHFRANCE                     0x040c
#define LANGUAGE_ID_FRENCHBELGIUM                    0x080c
#define LANGUAGE_ID_FRENCHCANADA                     0x0c0c
#define LANGUAGE_ID_FRENCHSWITZERLAND                0x100c
#define LANGUAGE_ID_FRENCHLUXEMBOURG                 0x140c
#define LANGUAGE_ID_FRENCHMONACO                     0x180c
#define LANGUAGE_ID_HEBREWISRAEL                     0x040d
#define LANGUAGE_ID_HUNGARIANHUNGARY                 0x040e
#define LANGUAGE_ID_ICELANDICICELAND                 0x040f
#define LANGUAGE_ID_ITALIANITALY                     0x0410
#define LANGUAGE_ID_ITALIANSWITZERLAND               0x0810
#define LANGUAGE_ID_JAPANESEJAPAN                    0x0411
#define LANGUAGE_ID_KOREANKOREA                      0x0412
#define LANGUAGE_ID_KOREANJOHAB                      0x0812
#define LANGUAGE_ID_DUTCHNETHERLANDS                 0x0413
#define LANGUAGE_ID_DUTCHBELGIUM                     0x0813
#define LANGUAGE_ID_NORWEGIANBOKMAL                  0x0414
#define LANGUAGE_ID_NORWEGIANNYNORSK                 0x0814
#define LANGUAGE_ID_POLISHPOLAND                     0x0415
#define LANGUAGE_ID_PORTUGUESEBRAZIL                 0x0416
#define LANGUAGE_ID_PORTUGUESEPORTUGAL               0x0816
#define LANGUAGE_ID_ROMANSHSWITZERLAND               0x0417
#define LANGUAGE_ID_ROMANIANROMANIA                  0x0418
#define LANGUAGE_ID_RUSSIANRUSSIA                    0x0419
#define LANGUAGE_ID_CROATIANCROATIA                  0x041a
#define LANGUAGE_ID_CROATIANBOSNIAHERZEGOVINALATIN   0x101a
#define LANGUAGE_ID_SERBIANCROATIA                   0x041a
#define LANGUAGE_ID_SERBIANSERBIAMONTENEGROLATIN     0x081a
#define LANGUAGE_ID_SERBIANSERBIAMONTENEGROCYRILLIC  0x0c1a
#define LANGUAGE_ID_SERBIANBOSNIAHERZEGOVINALATIN    0x181a
#define LANGUAGE_ID_SERBIANBOSNIAHERZEGOVINACYRILLIC 0x1c1a
#define LANGUAGE_ID_BOSNIANBOSNIAHERZEGOVINALATIN    0x201a
#define LANGUAGE_ID_BOSNIANBOSNIAHERZEGOVINACYRILLIC 0x141a
#define LANGUAGE_ID_SLOVAKSLOVAKIA                   0x041b
#define LANGUAGE_ID_ALBANIANALBANIA                  0x041c
#define LANGUAGE_ID_SWEDISHSWEDEN                    0x041d
#define LANGUAGE_ID_SWEDISHFINLAND                   0x081d
#define LANGUAGE_ID_THAITHAILAND                     0x041e
#define LANGUAGE_ID_TURKISHTURKEY                    0x041f
#define LANGUAGE_ID_URDUPAKISTAN                     0x0420
#define LANGUAGE_ID_URDUINDIA                        0x0820
#define LANGUAGE_ID_INDONESIANINDONESIA              0x0421
#define LANGUAGE_ID_UKRAINIANUKRAINE                 0x0422
#define LANGUAGE_ID_BELARUSIANBELARUS                0x0423
#define LANGUAGE_ID_SLOVENIANSLOVENIA                0x0424
#define LANGUAGE_ID_ESTONIANESTONIA                  0x0425
#define LANGUAGE_ID_LATVIANLATVIA                    0x0426
#define LANGUAGE_ID_LITHUANIANLITHUANIA              0x0427
#define LANGUAGE_ID_LITHUANIANCLASSIC                0x0827
#define LANGUAGE_ID_TAJIKTAJIKISTAN                  0x0428
#define LANGUAGE_ID_PERSIANIRAN                      0x0429
#define LANGUAGE_ID_FARSIIRAN                        0x0429
#define LANGUAGE_ID_VIETNAMESEVIETNAM                0x042a
#define LANGUAGE_ID_ARMENIANARMENIA                  0x042b
#define LANGUAGE_ID_AZERIAZERBAIJANLATIN             0x042c
#define LANGUAGE_ID_AZERIAZERBAIJANCYRILLIC          0x082c
#define LANGUAGE_ID_BASQUEBASQUE                     0x042d
#define LANGUAGE_ID_UPPERSORBIANGERMANY              0x042e
#define LANGUAGE_ID_LOWERSORBIANGERMANY              0x082e
#define LANGUAGE_ID_MACEDONIANMACEDONIA              0x042f
#define LANGUAGE_ID_SUTU                             0x0430
#define LANGUAGE_ID_XITSONGA                         0x0431
#define LANGUAGE_ID_TSONGA                           0x0431
#define LANGUAGE_ID_SETSWANASOUTHAFRICA              0x0432
#define LANGUAGE_ID_TSWANASOUTHAFRICA                0x0432
#define LANGUAGE_ID_LUVENDA                          0x0433
#define LANGUAGE_ID_TSHIVENDA                        0x0433
#define LANGUAGE_ID_VENDA                            0x0433
#define LANGUAGE_ID_ISIXHOSASOUTHAFRICA              0x0434
#define LANGUAGE_ID_XHOSASOUTHAFRICA                 0x0434
#define LANGUAGE_ID_ISIZULUSOUTHAFRICA               0x0435
#define LANGUAGE_ID_ZULUSOUTHAFRICA                  0x0435
#define LANGUAGE_ID_AFRIKAANSSOUTHAFRICA             0x0436
#define LANGUAGE_ID_GEORGIANGEORGIA                  0x0437
#define LANGUAGE_ID_FAEROESEFAROEISLANDS             0x0438
#define LANGUAGE_ID_HINDIINDIA                       0x0439
#define LANGUAGE_ID_MALTESEMALTA                     0x043a
#define LANGUAGE_ID_SAMINORTHERNNORWAY               0x043b
#define LANGUAGE_ID_SAMINORTHERNSWEDEN               0x083b
#define LANGUAGE_ID_SAMINORTHERNFINLAND              0x0c3b
#define LANGUAGE_ID_SAMILULENORWAY                   0x103b
#define LANGUAGE_ID_SAMILULESWEDEN                   0x143b
#define LANGUAGE_ID_SAMISOUTHERNNORWAY               0x183b
#define LANGUAGE_ID_SAMISOUTHERNSWEDEN               0x1c3b
#define LANGUAGE_ID_SAMISKOLTFINLAND                 0x203b
#define LANGUAGE_ID_SAMIINARIFINLAND                 0x243b
#define LANGUAGE_ID_IRISHIRELAND                     0x083c
#define LANGUAGE_ID_YIDDISH                          0x043d
#define LANGUAGE_ID_MALAYMALAYSIA                    0x043e
#define LANGUAGE_ID_MALAYBRUNEI                      0x083e
#define LANGUAGE_ID_KAZAKKAZAKHSTAN                  0x043f
#define LANGUAGE_ID_KYRGYZKYRGYZSTAN                 0x0440
#define LANGUAGE_ID_SWAHILIKENYA                     0x0441
#define LANGUAGE_ID_TURKMENTURKMENISTAN              0x0442
#define LANGUAGE_ID_UZBEKUZBEKISTANLATIN             0x0443
#define LANGUAGE_ID_UZBEKUZBEKISTANCYRILLIC          0x0843
#define LANGUAGE_ID_TATARRUSSIA                      0x0444
#define LANGUAGE_ID_BENGALIINDIA                     0x0445
#define LANGUAGE_ID_BENGALIBANGLADESH                0x0845
#define LANGUAGE_ID_PUNJABIINDIA                     0x0446
#define LANGUAGE_ID_GUJARATIINDIA                    0x0447
#define LANGUAGE_ID_ORIYAINDIA                       0x0448
#define LANGUAGE_ID_TAMILINDIA                       0x0449
#define LANGUAGE_ID_TELUGUINDIA                      0x044a
#define LANGUAGE_ID_KANNADAINDIA                     0x044b
#define LANGUAGE_ID_MALAYALAMINDIA                   0x044c
#define LANGUAGE_ID_ASSAMESEINDIA                    0x044d
#define LANGUAGE_ID_MARATHIINDIA                     0x044e
#define LANGUAGE_ID_SANSKRITINDIA                    0x044f
#define LANGUAGE_ID_MONGOLIANMONGOLIACYRILLIC        0x0450
#define LANGUAGE_ID_MONGOLIANCHINAMONG               0x0850
#define LANGUAGE_ID_TIBETANCHINA                     0x0451
#define LANGUAGE_ID_WELSHUNITEDKINGDOM               0x0452
#define LANGUAGE_ID_KHMERCAMBODIA                    0x0453
#define LANGUAGE_ID_LAOLAOS                          0x0454
#define LANGUAGE_ID_BURMESE                          0x0455
#define LANGUAGE_ID_GALICIANSPAIN                    0x0456
#define LANGUAGE_ID_KONKANIINDIA                     0x0457
#define LANGUAGE_ID_MANIPURI                         0x0458
#define LANGUAGE_ID_SINDHIPAKISTAN                   0x0459
#define LANGUAGE_ID_SINDHIAFGHANISTAN                0x0859
#define LANGUAGE_ID_SYRIACSYRIA                      0x045a
#define LANGUAGE_ID_SINHALESESRILANKA                0x045b
#define LANGUAGE_ID_CHEROKEE                         0x045c
#define LANGUAGE_ID_INUKTITUTCANADA                  0x045d
#define LANGUAGE_ID_INUKTITUTCANADALATIN             0x085d
#define LANGUAGE_ID_AMHARICETHIOPIA                  0x045e
#define LANGUAGE_ID_TAMAZIGHTALGERIALATIN            0x085f
#define LANGUAGE_ID_KASHMIRISOUTHASIA                0x0860
#define LANGUAGE_ID_NEPALINEPAL                      0x0461
#define LANGUAGE_ID_NEPALIINDIA                      0x0861
#define LANGUAGE_ID_FRISIANNETHERLANDS               0x0462
#define LANGUAGE_ID_PASHTOAFGHANISTAN                0x0463
#define LANGUAGE_ID_FILIPINOPHILIPPINES              0x0464
#define LANGUAGE_ID_DIVEHIMALDIVES                   0x0465
#define LANGUAGE_ID_EDO                              0x0466
#define LANGUAGE_ID_FULFULDE                         0x0467
#define LANGUAGE_ID_HAUSANIGERIA                     0x0468
#define LANGUAGE_ID_IBIBIO                           0x0469
#define LANGUAGE_ID_YORUBANIGERIA                    0x046a
#define LANGUAGE_ID_QUECHUABOLIVIA                   0x046b
#define LANGUAGE_ID_QUECHUAECUADOR                   0x086b
#define LANGUAGE_ID_QUECHUAPERU                      0x0c6b
#define LANGUAGE_ID_SESOTHSALEBOASOUTHAFRICA         0x046c
#define LANGUAGE_ID_SOTHOSOUTHAFRICA                 0x046c
#define LANGUAGE_ID_BASHKIRRUSSIA                    0x046d
#define LANGUAGE_ID_LUXEMBOURGISHLUXEMBOURG          0x046e
#define LANGUAGE_ID_GREENLANDICGREENLAND             0x046f
#define LANGUAGE_ID_IGBONIGERIA                      0x0470
#define LANGUAGE_ID_KANURI                           0x0471
#define LANGUAGE_ID_AFAANOROMOO                      0x0472
#define LANGUAGE_ID_OROMO                            0x0472
#define LANGUAGE_ID_TIGRIGNAERITREA                  0x0873
#define LANGUAGE_ID_GUARANI                          0x0474
#define LANGUAGE_ID_HAWAIIAN                         0x0475
#define LANGUAGE_ID_LATIN                            0x0476
#define LANGUAGE_ID_AFSOOMAALI                       0x0477
#define LANGUAGE_ID_SOMALI                           0x0477
#define LANGUAGE_ID_YICHINA                          0x0478
#define LANGUAGE_ID_PAPIAMENTU                       0x0479
#define LANGUAGE_ID_MAPUDUNGUNCHILE                  0x047a
#define LANGUAGE_ID_MOHAWKCANADA                     0x047c
#define LANGUAGE_ID_BRETONFRANCE                     0x047e
#define LANGUAGE_ID_UYGHURCHINA                      0x0480
#define LANGUAGE_ID_UIGHURCHINA                      0x0480
#define LANGUAGE_ID_MAORINEWZEALAND                  0x0481
#define LANGUAGE_ID_OCCITANFRANCE                    0x0482
#define LANGUAGE_ID_CORSICANFRANCE                   0x0483
#define LANGUAGE_ID_ALSATIANFRANCE                   0x0484
#define LANGUAGE_ID_YAKUTRUSSIA                      0x0485
#define LANGUAGE_ID_KICHEGUATEMALA                   0x0486
#define LANGUAGE_ID_KINYARWANDARWANDA                0x0487
#define LANGUAGE_ID_WOLOFSENEGAL                     0x0488
#define LANGUAGE_ID_DARIAFGHANISTAN                  0x048c
#define LANGUAGE_ID_INVARIANT                        0x007f

#endif

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Language.hpp

\*_________________________________________________________*/
