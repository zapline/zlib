/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ScrollBar.hpp

    Comment:                encapsulation for Scroll Bar Control

    Class Name:             Windows::UserInterface::CScrollBar

    Version:                2.5

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/05/24-2004/05/27 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2005/01/08-2005/01/10 (2.0)
                            2005/04/24-2005/04/24 (2.1)
                            2005/09/25-2005/09/25 (2.2)
                            2010/01/16-2010/01/16 (2.3)
                            2010/01/30-2010/01/30 (2.4)
                            2011/10/06-2011/10/06 (2.5)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef SCROLL_BAR_HPP
#define SCROLL_BAR_HPP

#include <Control.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define ESB_ENABLE_BOTH   0x0000
#define ESB_DISABLE_BOTH  0x0003
#define ESB_DISABLE_LEFT  0x0001
#define ESB_DISABLE_RIGHT 0x0002
#define ESB_DISABLE_UP    0x0001
#define ESB_DISABLE_DOWN  0x0002
#define ESB_DISABLE_LTUP  ESB_DISABLE_LEFT
#define ESB_DISABLE_RTDN  ESB_DISABLE_RIGHT
#define SBM_SETPOS         0x00E0
#define SBM_GETPOS         0x00E1
#define SBM_SETRANGE       0x00E2
#define SBM_GETRANGE       0x00E3
#define SBM_ENABLE_ARROWS  0x00E4
#define SBM_SETRANGEREDRAW 0x00E6
typedef struct tagSCROLLBARINFO *LPSCROLLBARINFO;
#endif
#if !(defined SBM_GETSCROLLBARINFO)
#define SBM_GETSCROLLBARINFO 0x00EB
#endif

//The definition of global functions of Scroll Bar
#if (defined ScrollBar_Enable)
#undef ScrollBar_Enable
#endif
#if (defined ScrollBar_GetPos)
#undef ScrollBar_GetPos
#endif
#if (defined ScrollBar_SetPos)
#undef ScrollBar_SetPos
#endif
#if (defined ScrollBar_GetRange)
#undef ScrollBar_GetRange
#endif
#if (defined ScrollBar_SetRange)
#undef ScrollBar_SetRange
#endif
#define ScrollBar_Enable(a_hScrollBar,a_nArrowOptions) ScrollBar_EnableArrows(a_hScrollBar,a_nArrowOptions)
//#define ScrollBar_Show(a_hScrollBar,a_bShow) ((void)ShowWindow((HWND)(a_hScrollBar),(BOOL)(a_bShow)?SW_SHOWNORMAL:SW_HIDE))
#define ScrollBar_GetPos(a_hScrollBar) ((int)SendMessage((HWND)(a_hScrollBar),SBM_GETPOS,(WPARAM)0,(LPARAM)0))
#define ScrollBar_SetPos(a_hScrollBar,a_nPosition,a_bRedraw) ((void)SendMessage((HWND)(a_hScrollBar),SBM_SETPOS,(WPARAM)(int)(a_nPosition),(LPARAM)(BOOL)(a_bRedraw)))
#define ScrollBar_GetRange(a_hScrollBar,a_pnMinPosition,a_pnMaxPosition) ((void)SendMessage((HWND)(a_hScrollBar),SBM_GETRANGE,(WPARAM)(int*)(a_pnMinPosition),(LPARAM)(int*)(a_pnMaxPosition)))
#define ScrollBar_SetRange(a_hScrollBar,a_nMinPosition,a_nMaxPosition,a_bRedraw) ((void)SendMessage((HWND)(a_hScrollBar),SBM_SETRANGE,(WPARAM)(int)(a_nMinPosition),(LPARAM)(int)(a_nMaxPosition)))
#define ScrollBar_SetRangeRedraw(a_hScrollBar,a_nMinPosition,a_nMaxPosition) ((void)SendMessage((HWND)(a_hScrollBar),SBM_SETRANGEREDRAW,(WPARAM)(int)(a_nMinPosition),(LPARAM)(int)(a_nMaxPosition)))
#define ScrollBar_EnableArrows(a_hScrollBar,a_nArrowFlags) ((BOOL)SendMessage((HWND)(a_hScrollBar),SBM_ENABLE_ARROWS,(WPARAM)(UINT)(a_nArrowFlags),(LPARAM)0))
#define ScrollBar_GetScrollInfo(a_hScrollBar,a_pScrollInfo) ((BOOL)SendMessage((HWND)(a_hScrollBar),SBM_GETSCROLLINFO,(WPARAM)0,(LPARAM)(LPSCROLLINFO)(a_pScrollInfo)))
#define ScrollBar_SetScrollInfo(a_hScrollBar,a_pScrollInfo,a_bRedraw) ((int)SendMessage((HWND)(a_hScrollBar),SBM_SETSCROLLINFO,(WPARAM)(BOOL)(a_bRedraw),(LPARAM)(LPCSCROLLINFO)(a_pScrollInfo)))
#define ScrollBar_GetInfo(a_hScrollBar,a_pScrollBarInfo) ((BOOL)SendMessage((HWND)(a_hScrollBar),SBM_GETSCROLLBARINFO,(WPARAM)0,(LPARAM)(LPSCROLLBARINFO)(a_pScrollBarInfo)))

namespace Windows
{
namespace UserInterface
{

//The definition of EArrowOption
enum EArrowOption
{
    eEnableBoth       = ESB_ENABLE_BOTH, //0x0000
    eDisableBoth      = ESB_DISABLE_BOTH, //0x0003
    eDisableLeft      = ESB_DISABLE_LEFT, //0x0001
    eDisableRight     = ESB_DISABLE_RIGHT, //0x0002
    eDisableUp        = ESB_DISABLE_UP, //0x0001
    eDisableDown      = ESB_DISABLE_DOWN, //0x0002
    eDisableLeftUp    = ESB_DISABLE_LTUP, //0x0001
    eDisableRightDown = ESB_DISABLE_RTDN, //0x0002
};

//The declaration of CScrollBar
class CScrollBar:
    public CControl
{
public:
    CScrollBar(void);
    ~CScrollBar(void);
    void Enable(EArrowOption a_eArrowOption);
    void Show(bool a_bShow);
    int GetPosition(HWND a_hScrollBar);
    void SetPosition(int a_nPosition, bool a_bRedraw);
    void GetRange(int& a_rnMinPosition, int& a_rnMaxPosition);
    void SetRange(int a_nMinPosition, int a_nMaxPosition);
    void SetRangeRedraw(int a_nMinPosition, int a_nMaxPosition);
    void EnableArrows(EArrowOption a_eArrowOption);
    void GetScrollInfo(LPSCROLLINFO a_pScrollInfo);
    void SetScrollInfo(LPSCROLLINFO a_pScrollInfo, bool a_bRedraw);
    void GetInfo(LPSCROLLBARINFO a_pScrollBarInfo);
private:
    using CControl::Enable;
    CScrollBar(const CScrollBar& a_rScrollBar);
    const CScrollBar& operator=(const CScrollBar& a_rScrollBar);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ScrollBar.hpp

\*_________________________________________________________*/
