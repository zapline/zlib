/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              InternetConnect.hpp

    Comment:                encapsulation of Internet API

    Class Name:             Windows::Internet::CConnect

    Version:                4.1

    Build:                  26

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2002/12/26-2003/01/24 (1.0)
                            2004/05/09-2004/05/20 (1.1.14)
                            2004/09/23-2004/09/23 (1.1.15)
                            2004/11/06-2004/11/06 (1.1.16)
                            2005/05/04-2005/05/04 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/24-2010/01/26 (3.1)
                            2010/01/30-2010/01/31 (3.2)
                            2010/02/27-2010/02/27 (4.0)
                            2011/08/11-2011/08/11 (4.1)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef INTERNET_CONNECT_HPP
#define INTERNET_CONNECT_HPP

#include <InternetObject.hpp>
#include <welink.h>

//The definition of compatibility
#if !defined(INTERNET_SERVICE_URL)
#define INTERNET_SERVICE_URL 0
#endif

namespace Windows
{
namespace Internet
{

//The definition of EService
enum EService
{
    eUrlService = INTERNET_SERVICE_URL, //0
    eFtpService = INTERNET_SERVICE_FTP, //1
    eGopherService = INTERNET_SERVICE_GOPHER, //2
    eHttpService = INTERNET_SERVICE_HTTP, //3
};

//The declaration of CConnect
class CConnect:
    public CObject
{
public:
    CConnect(void);
    ~CConnect(void);
    bool Open(HANDLE a_hSession, LPCTSTR a_szServerName, INTERNET_PORT a_nServerPort, EService a_eService, LPCTSTR a_szUserName=(LPCTSTR)NULL, LPCTSTR a_szPassword=(LPCTSTR)NULL, DWORD a_dwFlags=(DWORD)NULL);
private:
    CConnect(const CConnect& a_rConnect);
    const CConnect& operator=(const CConnect& a_rConnect);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of InternetConnect.hpp

\*_________________________________________________________*/
