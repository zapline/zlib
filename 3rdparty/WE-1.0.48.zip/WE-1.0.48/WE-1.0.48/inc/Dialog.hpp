/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Dialog.hpp

    Comment:                encapsulation of Dialog

    Class Name:             Windows::UserInterface::CDialog

    Version:                3.2

    Build:                  33

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/12/13-2000/05/12 (1.0)
                            2004/05/20-2004/05/25 (1.1.10)
                            2004/09/22-2004/09/23 (1.1.11)
                            2004/11/06-2004/11/06 (1.1.12)
                            2004/11/07-2004/11/07 (2.0.14)
                            2004/11/20-2004/11/20 (2.0.15)
                            2004/11/27-2004/11/28 (2.0.17)
                            2004/12/11-2004/12/11 (2.0.18)
                            2004/12/19-2004/12/19 (2.0.19)
                            2004/12/25-2004/12/25 (2.0.20)
                            2005/01/08-2005/01/09 (2.0.21)
                            2005/04/23-2005/04/23 (2.1)
                            2005/05/28-2005/05/28 (2.2)
                            2005/08/20-2005/08/20 (2.3)
                            2005/09/25-2005/09/25 (2.4)
                            2010/01/11-2010/01/28 (3.0)
                            2010/01/30-2010/01/31 (3.1)
                            2011/10/04-2011/10/04 (3.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef DIALOG_HPP
#define DIALOG_HPP

#include <Window.hpp>
#include <welink.h>

//The declaration of global functions
void SetDlgItemFocus(HWND a_hDialog, UINT a_idItem);
void LimitDlgEditText(HWND a_hDialog, UINT a_idEdit, UINT a_nMaxText);
void LimitDlgComboBoxText(HWND a_hDialog, UINT a_idComboBox, int a_nMaxText);
DWORD GetDlgComboBoxCurrentSelectData(HWND a_hDialog, UINT a_idComboBox);
int SetDlgComboBoxCurrentSelectData(HWND a_hDialog, UINT a_idComboBox, DWORD a_dwData);

namespace Windows
{
namespace UserInterface
{

//The declaration of CDialog
class CDialog:
    public CWindow
{
public:
    explicit CDialog(UINT a_idDialog);
    ~CDialog(void);
    INT_PTR DoModule(HWND a_hParent, HMODULE a_hModule);
    void Create(HWND a_hParent, HMODULE a_hModule);
protected:
    UINT m_idDialog;
    HMODULE m_hModule;
protected:
    virtual bool OnInitDialog(void);
    virtual void OnDestroy(void);
    virtual bool OnCommand(UINT a_idControl, UINT a_nCode, HWND a_hControl);
    virtual LRESULT OnNotify(UINT a_idControl, LPNMHDR a_pMessage);
    virtual void OnOK(void);
    virtual void OnCancel(void);
    void EndDialog(INT_PTR a_nResult);
private:
    virtual bool SetContentToControls(void);
    virtual bool GetContentFromControls(void);
    virtual bool DialogProcedure(UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    static INT_PTR CALLBACK DialogProcedure(HWND a_hDialog, UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    using CWindow::Create;
    using CWindow::Destroy;
    using CWindow::Attach;
    using CWindow::Detach;
    CDialog(const CDialog& a_rDailog);
    const CDialog& operator=(const CDialog& a_rDailog);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Dialog.hpp

\*_________________________________________________________*/
