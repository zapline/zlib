/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              MainWindow.hpp

    Comment:                encapsulation of Main Window

    Class Name:             Windows::Extension::CMainWindow

    Version:                5.0

    Build:                  41

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/04/23-2005/04/24 (2.1)
                            2005/05/04-2005/05/04 (3.0)
                            2005/05/28-2005/05/28 (3.1)
                            2005/06/04-2005/06/05 (3.2)
                            2005/07/31-2005/07/31 (3.3)
                            2005/09/25-2005/09/25 (3.4.36)
                            2006/04/02-2006/04/02 (3.4.37)
                            2010/01/17-2010/01/27 (4.0)
                            2010/01/30-2010/01/30 (4.1)
                            2011/10/12-2011/10/12 (5.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef MAIN_WINDOW_HPP
#define MAIN_WINDOW_HPP

#include <Window.hpp>
#include <welink.h>

namespace Windows
{
namespace Extension
{

//The declaration of CMainWindow
class CMainWindow:
    public UserInterface::CWindow
{
protected:
    CMainWindow(LPCTSTR a_szClassName, UINT a_idMenu, UINT a_idIcon);
    ~CMainWindow(void);
public:
    bool Register(HMODULE a_hModule);
    void Unregister(void);
    void Create(LPCTSTR a_szTitle, DWORD a_dwStyle, DWORD a_dwExStyle, int a_nX=CW_USEDEFAULT, int a_nY=CW_USEDEFAULT, int a_nWidth=CW_USEDEFAULT, int a_nHeight=CW_USEDEFAULT);
    bool AttachRemote(void);
    void DetachRemote(void);
    void SetForeground(void);
protected:
    HMODULE m_hModule;
    LPCTSTR m_szClassName;
    UINT m_idMenu;
    UINT m_idIcon;
    DWORD m_dwClassStyle;
    LPCTSTR m_szSystemCursor;
    UINT m_idCursor;
    HBRUSH m_hBackground;
protected:
    virtual bool OnCreate(void);
    virtual void OnDestroy(void);
private:
    virtual void OnPaint(void);
#if (defined _WIN32_WCE)
    virtual void OnCloseToBackground(void);
#endif
    virtual bool OnCommand(UINT a_idControl, UINT a_nCode, HWND a_hControl);
    virtual LRESULT OnNotify(UINT a_idControl, LPNMHDR a_pMessage);
    virtual LRESULT WindowProcedure(UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    static LRESULT CALLBACK WindowProcedure(HWND a_hWindow, UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    using CWindow::Create;
    using CWindow::Attach;
    using CWindow::Detach;
    CMainWindow(const CMainWindow& a_rWindow);
    const CMainWindow& operator=(const CMainWindow& a_rWindow);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of MainWindow.hpp

\*_________________________________________________________*/
