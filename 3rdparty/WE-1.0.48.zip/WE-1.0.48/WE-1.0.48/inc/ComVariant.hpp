/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ComVariant.hpp

    Comment:                encapsulation of COM Variant

    Class Name:             Windows::Component::CVariant

    Version:                4.3

    Build:                  20

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/12-2003/01/13 (1.0)
                            2004/03/21-2004/04/24 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2004/11/07-2004/11/07 (1.1.5)
                            2005/01/08-2005/01/08 (1.1.6)
                            2005/05/01-2005/05/03 (2.0)
                            2005/06/12-2005/06/12 (2.1)
                            2005/08/28-2005/08/28 (3.0)
                            2005/09/23-2005/09/23 (3.1)
                            2010/01/21-2010/01/25 (4.0)
                            2010/01/30-2010/01/30 (4.1)
                            2010/04/25-2010/04/25 (4.2)
                            2011/08/18-2011/08/18 (4.3)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef COM_VARIANT_HPP
#define COM_VARIANT_HPP

#include <we_pragma.h>

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#undef VARIANT_TRUE
#define VARIANT_TRUE ((VARIANT_BOOL)-1)
#endif

namespace Windows
{
namespace Component
{

//The declaration of CVariant
class CVariant:
    public VARIANT
{
public:
    inline CVariant(void);
    inline ~CVariant(void);
    inline CVariant(const wchar_t* a_szValue);
#if !(defined _WIN32_WCE)
    inline CVariant(SAFEARRAY* a_pValue);
#endif
    inline CVariant(IUnknown* a_pInterface);
    inline CVariant(IDispatch* a_pInterface);
    inline CVariant(bool a_bValue);
    inline CVariant(char a_cValue);
    inline CVariant(unsigned char a_cValue);
    inline CVariant(short a_nValue);
    inline CVariant(unsigned short a_nValue);
    inline CVariant(int a_nValue);
    inline CVariant(unsigned int a_nValue);
    inline CVariant(long a_nValue);
    inline CVariant(unsigned long a_nValue);
#if !(defined _WIN32_WCE)
    inline CVariant(long_long a_nValue);
    inline CVariant(unsigned_long_long a_nValue);
#endif
    inline CVariant(float a_fValue);
    inline CVariant(double a_fValue);
    inline VARTYPE GetType(void)const;
    inline operator BSTR(void)const;
#if !(defined _WIN32_WCE)
    inline operator SAFEARRAY*(void)const;
#endif
    inline operator IUnknown*(void)const;
    inline operator IDispatch*(void)const;
    inline operator bool(void)const;
    inline operator char(void)const;
    inline operator unsigned char(void)const;
    inline operator short(void)const;
    inline operator unsigned short(void)const;
    inline operator int(void)const;
    inline operator unsigned int(void)const;
    inline operator long(void)const;
    inline operator unsigned long(void)const;
#if !(defined _WIN32_WCE)
    inline operator long_long(void)const;
    inline operator unsigned_long_long(void)const;
#endif
    inline operator float(void)const;
    inline operator double(void)const;
    inline void AttachFromReturn(VARIANT a_Variant);
    inline VARIANT DetachToReturn(void);
public:
    CVariant(const CVariant& a_rVariant); //do not call this function
private:
    const CVariant& operator=(const CVariant& a_rVariant);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The definition of CVariant
inline CVariant::CVariant(void)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    return;
}

inline CVariant::~CVariant(void)
{
    VERIFY( ::VariantClear(static_cast<VARIANT*>(this))==S_OK );
    ASSERT( vt==VT_EMPTY );
    return;
}

inline CVariant::CVariant(const wchar_t* a_szValue)
{
    ASSERT( a_szValue!=(const wchar_t*)NULL );
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_BSTR;
    bstrVal = ::SysAllocString(a_szValue);
    return;
}

#if !(defined _WIN32_WCE)
inline CVariant::CVariant(SAFEARRAY* a_pValue)
{
    ASSERT( a_pValue!=(SAFEARRAY*)NULL );
    ::VariantInit(static_cast<VARIANT*>(this));
    HRESULT hResult = ::SafeArrayCopy(a_pValue,&parray);
    if( hResult==S_OK )
    {
        ASSERT( parray!=(SAFEARRAY*)NULL );
        VERIFY( ::SafeArrayGetVartype(parray,&vt)==S_OK );
        ASSERT( vt==VT_INT || vt==VT_I1 || vt==VT_I2 || vt==VT_I4 || vt==VT_I8 ||
            vt==VT_UINT || vt==VT_UI1 || vt==VT_UI2 || vt==VT_UI4 || vt==VT_UI8 ||
            vt==VT_R4 || vt==VT_R8 || vt==VT_BOOL ||
            vt==VT_BSTR || vt==VT_VARIANT ||
            vt==VT_UNKNOWN || vt==VT_DISPATCH ||
            vt==VT_CY || vt==VT_DATE || vt==VT_DECIMAL || vt==VT_ERROR ||
            vt==VT_RECORD );
        vt |= VT_ARRAY;
    }
    else
    {
        vt = VT_ERROR;
        scode = hResult;
    }
    return;
}
#endif

inline CVariant::CVariant(IUnknown* a_pInterface)
{
    ASSERT( a_pInterface!=(IUnknown*)NULL );
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UNKNOWN;
    punkVal = a_pInterface;
    a_pInterface->AddRef();
    return;
}

inline CVariant::CVariant(IDispatch* a_pInterface)
{
    ASSERT( a_pInterface!=(IDispatch*)NULL );
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_DISPATCH;
    pdispVal = a_pInterface;
    a_pInterface->AddRef();
    return;
}

inline CVariant::CVariant(bool a_bValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_BOOL;
    boolVal = a_bValue ? VARIANT_TRUE : VARIANT_FALSE;
    return;
}

inline CVariant::CVariant(char a_cValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_I1;
    cVal = a_cValue;
    return;
}

inline CVariant::CVariant(unsigned char a_cValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UI1;
    bVal = a_cValue;
    return;
}

inline CVariant::CVariant(short a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_I2;
    iVal = a_nValue;
    return;
}

inline CVariant::CVariant(unsigned short a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UI2;
    uiVal = a_nValue;
    return;
}

inline CVariant::CVariant(int a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_INT;
    intVal = a_nValue;
    return;
}

inline CVariant::CVariant(unsigned int a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UINT;
    uintVal = a_nValue;
    return;
}

inline CVariant::CVariant(long a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_I4;
    lVal = a_nValue;
    return;
}

inline CVariant::CVariant(unsigned long a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UI4;
    ulVal = a_nValue;
    return;
}

#if !(defined _WIN32_WCE)
inline CVariant::CVariant(long_long a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_I8;
    llVal = a_nValue;
    return;
}

inline CVariant::CVariant(unsigned_long_long a_nValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_UI8;
    ullVal = a_nValue;
    return;
}
#endif

inline CVariant::CVariant(float a_fValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_R4;
    fltVal = a_fValue;
    return;
}

inline CVariant::CVariant(double a_fValue)
{
    ::VariantInit(static_cast<VARIANT*>(this));
    vt = VT_R8;
    dblVal = a_fValue;
    return;
}

inline VARTYPE CVariant::GetType(void)const
{
    return vt;
}

inline CVariant::operator BSTR(void)const
{
    ASSERT( vt==VT_BSTR );
    return bstrVal;
}

#if !(defined _WIN32_WCE)
inline CVariant::operator SAFEARRAY*(void)const
{
    ASSERT( (vt&VT_ARRAY)==VT_ARRAY );
    return parray;
}
#endif

inline CVariant::operator IUnknown*(void)const
{
    ASSERT( vt==VT_UNKNOWN );
    return punkVal;
}

inline CVariant::operator IDispatch*(void)const
{
    ASSERT( vt==VT_DISPATCH );
    return pdispVal;
}

inline CVariant::operator bool(void)const
{
    ASSERT( vt==VT_BOOL );
    ASSERT( boolVal==VARIANT_TRUE || boolVal==VARIANT_FALSE );
    return boolVal==VARIANT_TRUE;
}

inline CVariant::operator char(void)const
{
    ASSERT( vt==VT_I1 );
    return cVal;
}

inline CVariant::operator unsigned char(void)const
{
    ASSERT( vt==VT_UI1 );
    return bVal;
}

inline CVariant::operator short(void)const
{
    ASSERT( vt==VT_I2 );
    return iVal;
}

inline CVariant::operator unsigned short(void)const
{
    ASSERT( vt==VT_UI2 );
    return uiVal;
}

inline CVariant::operator int(void)const
{
    ASSERT( vt==VT_INT );
    return intVal;
}

inline CVariant::operator unsigned int(void)const
{
    ASSERT( vt==VT_UINT );
    return uintVal;
}

inline CVariant::operator long(void)const
{
    ASSERT( vt==VT_I4 );
    return lVal;
}

inline CVariant::operator unsigned long(void)const
{
    ASSERT( vt==VT_UI4 );
    return ulVal;
}

#if !(defined _WIN32_WCE)
inline CVariant::operator long_long(void)const
{
    ASSERT( vt==VT_I8 );
    return llVal;
}

inline CVariant::operator unsigned_long_long(void)const
{
    ASSERT( vt==VT_UI8 );
    return ullVal;
}
#endif

inline CVariant::operator float(void)const
{
    ASSERT( vt==VT_R4 );
    return fltVal;
}

inline CVariant::operator double(void)const
{
    ASSERT( vt==VT_R8 );
    return dblVal;
}

inline void CVariant::AttachFromReturn(VARIANT a_Variant)
{
    ASSERT( vt==VT_EMPTY );
    *static_cast<VARIANT*>(this) = a_Variant;
    return;
}

inline VARIANT CVariant::DetachToReturn(void)
{
    VARIANT Variant = *static_cast<VARIANT*>(this);
    vt = VT_EMPTY;
    byref = (void*)NULL;
    return Variant;
}

}
}

#include <we_pragma_2.h>
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ComVariant.hpp

\*_________________________________________________________*/
