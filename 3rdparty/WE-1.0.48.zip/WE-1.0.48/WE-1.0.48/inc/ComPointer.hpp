/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ComPointer.hpp

    Comment:                encapsulation of COM Pointer

    Class Name:             Windows::Component::CPointer

    Version:                5.1

    Build:                  21

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/12-2003/01/13 (1.0)
                            2004/03/21-2004/04/24 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2004/11/07-2004/11/07 (1.1.5)
                            2005/01/08-2005/01/08 (1.1.6)
                            2005/05/01-2005/05/03 (2.0)
                            2005/06/12-2005/06/12 (2.1)
                            2005/08/28-2005/08/28 (3.0)
                            2005/09/23-2005/09/23 (3.1)
                            2010/01/20-2010/01/26 (4.0)
                            2010/01/30-2010/02/01 (4.1)
                            2010/04/25-2010/04/25 (5.0)
                            2011/07/18-2011/07/18 (5.1)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef COM_POINTER_HPP
#define COM_POINTER_HPP

#include <we_pragma.h>

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#undef VARIANT_TRUE
#define VARIANT_TRUE ((VARIANT_BOOL)-1)
#endif

namespace Windows
{
namespace Component
{

//The declaration of CPointer
template<class t_Interface>
class CPointer
{
public:
    inline CPointer(void);
    inline CPointer(t_Interface* a_pInterface);
    inline ~CPointer(void);
    inline operator t_Interface*(void)const;
    inline t_Interface* operator->(void)const;
    inline t_Interface** operator&(void);
    inline void AttachFromReturn(t_Interface* a_pInterface);
    inline t_Interface* DetachToReturn(void);
    inline bool CreateInstance(REFCLSID a_rClassID, DWORD a_dwContext=CLSCTX_ALL, LPUNKNOWN a_pUnknown=(LPUNKNOWN)NULL);
    template<class t_InterfaceA>
    inline bool QueryInterface(t_InterfaceA** a_ppInterface)const
    {
        ASSERT( a_ppInterface!=(t_InterfaceA**)NULL );
        ASSERT( *a_ppInterface==(t_InterfaceA*)NULL );
        ASSERT( m_pInterface!=(t_Interface*)NULL );
        HRESULT hResult = m_pInterface->QueryInterface(__uuidof(t_InterfaceA),(void**)a_ppInterface);
        ASSERT( hResult!=E_POINTER );
        if( hResult==S_OK )
        {
            ASSERT( *a_ppInterface!=(t_InterfaceA*)NULL );
        }
        else
        {
            ASSERT( *a_ppInterface==(t_InterfaceA*)NULL );
            RETAIL_MESSAGE(TRUE,(TEXT("WARNING: Windows::Component::CPointer::QueryInterface() - IUnknown::QueryInterface() fail! HRESULT=0x%08lX\n"),(ULONG)hResult));
        }
        return hResult==S_OK;
    }
    inline IUnknown* GetObject(void)const;
    inline void swap(CPointer<t_Interface>& a_rInterface);
protected:
    t_Interface* m_pInterface;
public:
    CPointer(const CPointer<t_Interface>& a_rInterface); //do not call this function
private:
    const CPointer<t_Interface>& operator=(const CPointer<t_Interface>& a_rInterface);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The definition of CPointer
template<class t_Interface>
inline CPointer<t_Interface>::CPointer(void):
    m_pInterface((t_Interface*)NULL)
{
    return;
}

template<class t_Interface>
inline CPointer<t_Interface>::CPointer(t_Interface* a_pInterface):
    m_pInterface(a_pInterface)
{
    ASSERT( m_pInterface!=(t_Interface*)NULL );
    m_pInterface->AddRef();
    return;
}

template<class t_Interface>
inline CPointer<t_Interface>::~CPointer(void)
{
    if( m_pInterface!=(t_Interface*)NULL )
    {
        m_pInterface->Release();
#if (defined _DEBUG)
        m_pInterface = (t_Interface*)NULL;
#endif
    }
    return;
}

template<class t_Interface>
inline CPointer<t_Interface>::operator t_Interface*(void)const
{
    return m_pInterface;
}

template<class t_Interface>
inline t_Interface* CPointer<t_Interface>::operator->(void)const
{
    ASSERT( m_pInterface!=(t_Interface*)NULL );
    return m_pInterface;
}

template<class t_Interface>
inline t_Interface** CPointer<t_Interface>::operator&(void)
{
    ASSERT( m_pInterface==(t_Interface*)NULL );
    return &m_pInterface;
}

template<class t_Interface>
inline void CPointer<t_Interface>::AttachFromReturn(t_Interface* a_pInterface)
{
    ASSERT( m_pInterface==(t_Interface*)NULL );
    m_pInterface = a_pInterface;
    return;
}

template<class t_Interface>
inline t_Interface* CPointer<t_Interface>::DetachToReturn(void)
{
    ASSERT( m_pInterface!=(t_Interface*)NULL );
    t_Interface* pInterface = m_pInterface;
    m_pInterface = (t_Interface*)NULL;
    return pInterface;
}

template<class t_Interface>
inline bool CPointer<t_Interface>::CreateInstance(REFCLSID a_rClassID, DWORD a_dwContext, LPUNKNOWN a_pUnknown)
{
    ASSERT( m_pInterface==(t_Interface*)NULL );
    HRESULT hResult = ::CoCreateInstance(a_rClassID,a_pUnknown,a_dwContext,__uuidof(t_Interface),(void**)&m_pInterface);
    ASSERT( hResult!=E_POINTER );
    if( hResult==S_OK )
    {
        ASSERT( m_pInterface!=(t_Interface*)NULL );
    }
    else
    {
        ASSERT( m_pInterface==(t_Interface*)NULL );
        RETAIL_MESSAGE(TRUE,(TEXT("\nERROR: Windows::Component::CPointer::CreateInstance() - ::CoCreateInstance() fail! HRESULT=0x%08lX\n\n"),(ULONG)hResult));
    }
    return hResult==S_OK;
}

template<class t_Interface>
inline IUnknown* CPointer<t_Interface>::GetObject(void)const
{
    ASSERT( m_pInterface!=(t_Interface*)NULL );
    IUnknown* pObject = (IUnknown*)NULL;
    VERIFY( QueryInterface(&pObject) );
    ASSERT( pObject!=(IUnknown*)NULL );
    pObject->Release();
    return pObject;
}

template<class t_Interface>
inline void CPointer<t_Interface>::swap(CPointer<t_Interface>& a_rInterface)
{
    t_Interface* pSwapInterface = m_pInterface;
    m_pInterface = a_rInterface.m_pInterface;
    a_rInterface.m_pInterface = pSwapInterface;
    return;
}

}
}

#include <we_pragma_2.h>
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ComPointer.hpp

\*_________________________________________________________*/
