/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Window.hpp

    Comment:                encapsulation of Window

    Class Name:             Windows::UserInterface::CWindow

    Version:                4.2

    Build:                  42

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/04/06-1999/10/14 (1.0)
                            2004/05/20-2004/05/24 (1.1.25)
                            2004/09/22-2004/09/22 (1.1.26)
                            2004/11/14-2004/11/14 (1.1.27)
                            2004/11/20-2004/11/20 (1.1.28)
                            2004/12/19-2004/12/19 (1.1.29)
                            2005/01/08-2005/01/11 (2.0)
                            2005/04/23-2005/04/24 (2.1)
                            2005/05/04-2005/05/04 (3.0)
                            2005/05/28-2005/05/28 (3.1)
                            2005/06/04-2005/06/04 (3.2)
                            2005/06/19-2005/06/19 (3.3)
                            2005/09/25-2005/09/25 (3.4.36)
                            2006/04/02-2006/04/02 (3.4.37)
                            2010/01/11-2010/01/11 (4.0)
                            2010/01/30-2010/01/30 (4.1)
                            2011/10/04-2011/10/04 (4.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WINDOW_HPP
#define WINDOW_HPP

#include <welink.h>

//The declaration of global functions
#define SetWindowStyle(a_hWindow,a_dwStyle) ((DWORD)SetWindowLong((HWND)(a_hWindow),GWL_STYLE,(LONG)(DWORD)(a_dwStyle)))
#define SetWindowExStyle(a_hWindow,a_dwStyle) ((DWORD)SetWindowLong((HWND)(a_hWindow),GWL_EXSTYLE,(LONG)(DWORD)(a_dwStyle)))
UINT MessageBox(HWND a_hParent, UINT a_idMessageFormat, UINT a_idCaption, DWORD a_dwType, HMODULE a_hModule, ...);
void SetWindowTitle(HWND a_hWindow, UINT a_idText, HMODULE a_hModule);
void SetWindowIcon(HWND a_hWindow, UINT a_idIcon, HMODULE a_hModule);

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#define GetWindowLongPtr GetWindowLong
#define SetWindowLongPtr SetWindowLong
#define GWLP_WNDPROC    GWL_WNDPROC
#define GWLP_HINSTANCE  GWL_HINSTANCE
#define GWLP_HWNDPARENT GWL_HWNDPARENT
#define GWLP_USERDATA   GWL_USERDATA
#define GWLP_ID         GWL_ID
#define DWLP_MSGRESULT  DWL_MSGRESULT
#define DWLP_DLGPROC    DWL_DLGPROC
#define DWLP_USER       DWL_USER
#endif

//The definition of compatibility
#if (defined _WIN32_WCE)
#define WS_OVERLAPPEDWINDOW 0x00000000L
#endif

//The definition of compatibility
#if (defined _WIN32_WCE)
#define SW_SHOWMINIMIZED   2
#define SW_SHOWMINNOACTIVE 7
#define SW_SHOWDEFAULT     10
#define SW_FORCEMINIMIZE   11
#endif

namespace Windows
{
namespace UserInterface
{

//The definition of EShowType
enum EShowType
{
    eHide                    = SW_HIDE, //0
    eShow                    = SW_SHOW, //5
    eShowNormal              = SW_SHOWNORMAL, //1
    eShowMinimized           = SW_SHOWMINIMIZED, //2
    eShowMaximized           = SW_SHOWMAXIMIZED, //3
    eMaximize                = SW_MAXIMIZE, //3
    eMinimize                = SW_MINIMIZE, //6
    eShowNoActivate          = SW_SHOWNA, //8
    eShowNormalNoActivate    = SW_SHOWNOACTIVATE, //4
    eShowMinimizedNoActivate = SW_SHOWMINNOACTIVE, //7
    eRestore                 = SW_RESTORE, //9
    eShowDefault             = SW_SHOWDEFAULT, //10
    eForceMinimize           = SW_FORCEMINIMIZE, //11
};

//The declaration of CWindow
class CWindow
{
public:
    CWindow(void);
    ~CWindow(void);
    void Create(LPCTSTR a_szClass, LPCTSTR a_szTitle, DWORD a_dwStyle, DWORD a_dwExStyle, int a_nX, int a_nY, int a_nWidth, int a_nHeight, HWND a_hParent, UINT a_idControl, HMODULE a_hModule);
    void Destroy(void);
    void Attach(HWND a_hWindow);
    void Detach(void);
    operator HWND(void)const;
    int MessageLoop(void);
    void Show(EShowType a_eShowType);
    void Update(void);
    void Redraw(void);
    LRESULT Send(UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    void Post(UINT a_nMessage, WPARAM a_wParameter, LPARAM a_lParameter);
    void SetFocus(void);
    void SetTitle(LPCTSTR a_szTitle);
    void SetTitle(UINT a_idTitle, HMODULE a_hModule);
    void SetIcon(UINT a_idIcon, HMODULE a_hModule);
protected:
    HWND m_hWindow;
protected:
    void ModifyStyle(DWORD a_dwRemove, DWORD a_dwAdd);
    void ModifyExtendedStyle(DWORD a_dwRemove, DWORD a_dwAdd);
    HWND GetChildWindow(UINT a_idItem);
private:
    CWindow(const CWindow& a_rWindow);
    const CWindow& operator=(const CWindow& a_rWindow);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Window.hpp

\*_________________________________________________________*/
