/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              WmiService.hpp

    Comment:                encapsulation of WMI Service (IWbemServices)

    Class Name:             Windows::Wmi::CService

    Version:                2.0

    Build:                  9

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/08/27-2005/08/28 (1.0)
                            2005/09/25-2005/09/25 (1.1)
                            2010/01/24-2010/01/26 (1.2)
                            2010/01/30-2010/01/30 (1.3.5)
                            2010/04/25-2010/04/25 (1.3.6)
                            2011/07/19-2011/07/19 (1.3.7)
                            2011/08/02-2011/08/02 (2.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WMI_SERVICE_HPP
#define WMI_SERVICE_HPP

#include <ComPointer.hpp>
#include <welink.h>

//The definition of namespaces
#define WMI_NAMESPACE_DEFAULT L"root\\cimv2"
#define WMI_NAMESPACE_DEVICE  L"root\\wmi"

namespace Windows
{
namespace Wmi
{

//The declaration of CService
class CService:
    public Component::CPointer<IWbemServices>
{
public:
    explicit CService(const wchar_t* a_szNamespace);
    ~CService(void);
    IWbemClassObject* GetClassObject(const wchar_t* a_szClass, size_t a_nIndex);
private:
    CService(const CService& a_rService);
    const CService& operator=(const CService& a_rService);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of WmiService.hpp

\*_________________________________________________________*/
