/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Logon.h

    Comment:                encapsulation of Winlogon GINA

    Macro Name:             LOGON_USER_INTERFACE

    Version:                2.2

    Build:                  14

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/12/25-2004/12/26 (1.0.1)
                            2004/12/29-2004/12/29 (1.0.2)
                            2005/01/09-2005/01/09 (1.0.3)
                            2005/05/04-2005/05/07 (1.1)
                            2005/07/31-2005/07/31 (1.2)
                            2005/09/25-2005/09/25 (1.3)
                            2008/06/21-2008/06/21 (1.4)
                            2010/01/25-2010/01/29 (2.0)
                            2010/01/30-2010/01/30 (2.1)
                            2011/10/07-2011/10/07 (2.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef LOGON_H
#define LOGON_H

#include <LogonI.hpp>
#include <Dll.h>
#include <welink.h>

#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxNegotiate,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxInitialize,20))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxDisplayStatusMessage,20))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxRemoveStatusMessage,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxDisplaySASNotice,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxDisplayLockedNotice,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxLoggedOutSAS,32))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxLoggedOnSAS,12))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxWkstaLockedSAS,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxActivateUserShell,16))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxStartApplication,16))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxLogoff,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxShutdown,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxIsLockOk,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxIsLogoffOk,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxScreenSaverNotify,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxGetConsoleSwitchCredentials,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxGetStatusMessage,16))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxNetworkProviderLoad,8))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxDisconnectNotify,4))
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WlxReconnectNotify,4))

//The declaration of global variables
extern Windows::Security::ILogonGina* m_pLogonGina;

//The definition of LOGON_USER_INTERFACE
#define LOGON_USER_INTERFACE(a_LogonGina) \
 \
DYNAMIC_LINK_LIBRARY(a_LogonGina); \
 \
Windows::Security::ILogonGina* m_pLogonGina = static_cast<Windows::Security::ILogonGina*>(&(a_LogonGina))

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Logon.h

\*_________________________________________________________*/
