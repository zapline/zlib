/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              ComString.hpp

    Comment:                encapsulation of COM BSTR

    Class Name:             Windows::Component::CString

    Version:                5.0

    Build:                  15

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/12-2003/01/13 (1.0)
                            2004/03/21-2004/04/24 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2004/11/07-2004/11/07 (1.1.5)
                            2005/01/08-2005/01/08 (1.1.6)
                            2005/05/01-2005/05/03 (2.0)
                            2005/06/12-2005/06/12 (2.1)
                            2005/08/28-2005/08/28 (3.0)
                            2005/09/23-2005/09/23 (3.1)
                            2010/01/20-2010/01/21 (4.0)
                            2010/01/30-2010/02/01 (4.1)
                            2010/04/25-2010/04/25 (5.0)

    Notice:
    Copyright (C) 2010, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef COM_STRING_HPP
#define COM_STRING_HPP

#include <we_pragma.h>

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#undef VARIANT_TRUE
#define VARIANT_TRUE ((VARIANT_BOOL)-1)
#endif

namespace Windows
{
namespace Component
{

//The declaration of CString
class CString
{
public:
    inline CString(void);
    inline CString(const wchar_t* a_szString);
    inline ~CString(void);
    inline unsigned int GetLength(void)const;
    inline operator BSTR(void)const;
    inline BSTR* operator&(void);
    inline void AttachFromReturn(BSTR a_szString);
    inline BSTR DetachToReturn(void);
private:
    BSTR m_szString;
public:
    CString(const CString& a_rsString); //do not call this function
private:
    const CString& operator=(const CString& a_rsString);
    static void* operator new(size_t a_nSize);
    static void* operator new[](size_t a_nSize);
    static void operator delete(void* a_pMemory);
    static void operator delete[](void* a_pMemory);
};

//The definition of CString
inline CString::CString(void):
    m_szString((BSTR)NULL)
{
    return;
}

inline CString::CString(const wchar_t* a_szString):
    m_szString((BSTR)NULL)
{
    if( a_szString!=(const wchar_t*)NULL )
    {
        m_szString = ::SysAllocString(a_szString);
    }
    return;
}

inline CString::~CString(void)
{
    if( m_szString!=(BSTR)NULL )
    {
        ::SysFreeString(m_szString);
#if (defined _DEBUG)
        m_szString = (BSTR)NULL;
#endif
    }
    return;
}

inline unsigned int CString::GetLength(void)const
{
    ASSERT( m_szString!=(BSTR)NULL );
    return ::SysStringLen(m_szString);
}

inline CString::operator BSTR(void)const
{
    return m_szString;
}

inline BSTR* CString::operator&(void)
{
    ASSERT( m_szString==(BSTR)NULL );
    return &m_szString;
}

inline void CString::AttachFromReturn(BSTR a_szString)
{
    ASSERT( m_szString==(BSTR)NULL );
    m_szString = a_szString;
    return;
}

inline BSTR CString::DetachToReturn(void)
{
    BSTR szString = m_szString;
    m_szString = (BSTR)NULL;
    return szString;
}

}
}

#include <we_pragma_2.h>
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of ComString.hpp

\*_________________________________________________________*/
