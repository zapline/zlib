/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              PipeServer.hpp

    Comment:                encapsulation of Named Pipe

    Class Name:             Windows::Base::CPipeServer
                            Windows::Base::CInboundPipeServer
                            Windows::Base::COutboundPipeServer

    Version:                3.2

    Build:                  8

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/06/19-2005/06/19 (1.0)
                            2005/07/23-2005/07/23 (1.1)
                            2005/09/10-2005/09/10 (2.0)
                            2005/09/24-2005/09/24 (2.1)
                            2010/01/24-2010/01/27 (3.0)
                            2010/01/30-2010/01/30 (3.1)
                            2011/10/03-2011/10/03 (3.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef PIPE_SERVER_HPP
#define PIPE_SERVER_HPP

#include <Pipe.hpp>
#include <welink.h>

namespace Windows
{
namespace Base
{

//The declaration of CPipeServer
class CPipeServer:
    public CPipe
{
public:
    CPipeServer(void);
    virtual ~CPipeServer(void);
    virtual void Close(void);
    bool Create(LPCTSTR a_szPipeName, DWORD a_dwBufferSize, DWORD a_dwTimeout, LPSECURITY_ATTRIBUTES a_pSecurity=(LPSECURITY_ATTRIBUTES)NULL);
    bool Connect(void);
    void Disconnect(void);
protected:
    DWORD m_dwMode;
    dsal::tstring m_sPipeName;
private:
    volatile bool m_bConnected;
    volatile bool m_bConnecting;
    volatile bool m_bCancelConnecting;
private:
    CPipeServer(const CPipeServer& a_rPipe);
    const CPipeServer& operator=(const CPipeServer& a_rPipe);
};

//The declaration of CInboundPipeServer
class CInboundPipeServer:
    public CPipeServer
{
public:
    CInboundPipeServer(void);
    virtual ~CInboundPipeServer(void);
private:
    using CPipeServer::Write;
    CInboundPipeServer(const CInboundPipeServer& a_rPipe);
    const CInboundPipeServer& operator=(const CInboundPipeServer& a_rPipe);
};

//The declaration of COutboundPipeServer
class COutboundPipeServer:
    public CPipeServer
{
public:
    COutboundPipeServer(void);
    virtual ~COutboundPipeServer(void);
private:
    using CPipeServer::Read;
    COutboundPipeServer(const COutboundPipeServer& a_rPipe);
    const COutboundPipeServer& operator=(const COutboundPipeServer& a_rPipe);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of PipeServer.hpp

\*_________________________________________________________*/
