/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              PipeClient.hpp

    Comment:                encapsulation of Named Pipe

    Class Name:             Windows::Base::CPipeClient
                            Windows::Base::CInboundPipeClient
                            Windows::Base::COutboundPipeClient

    Version:                3.2

    Build:                  8

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/06/19-2005/06/19 (1.0)
                            2005/07/23-2005/07/23 (1.1)
                            2005/09/10-2005/09/10 (2.0)
                            2005/09/24-2005/09/24 (2.1.4)
                            2008/06/21-2008/06/21 (2.1.5)
                            2010/01/24-2010/01/24 (3.0)
                            2010/01/30-2010/01/30 (3.1)
                            2011/10/03-2011/10/03 (3.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef PIPE_CLIENT_HPP
#define PIPE_CLIENT_HPP

#include <Pipe.hpp>
#include <welink.h>

namespace Windows
{
namespace Base
{

//The declaration of CPipeClient
class CPipeClient:
    public CPipe
{
public:
    CPipeClient(void);
    virtual ~CPipeClient(void);
    bool Open(LPCTSTR a_szPipeName, LPCTSTR a_szComputerName=(LPCTSTR)NULL, LPSECURITY_ATTRIBUTES a_pSecurity=(LPSECURITY_ATTRIBUTES)NULL);
    bool Wait(LPCTSTR a_szPipeName, LPCTSTR a_szComputerName=(LPCTSTR)NULL, DWORD a_dwTimeout=NMPWAIT_WAIT_FOREVER);
protected:
    DWORD m_dwMode;
private:
    CPipeClient(const CPipeClient& a_rPipe);
    const CPipeClient& operator=(const CPipeClient& a_rPipe);
};

//The declaration of CInboundPipeClient
class CInboundPipeClient:
    public CPipeClient
{
public:
    CInboundPipeClient(void);
    virtual ~CInboundPipeClient(void);
private:
    using CPipeClient::Write;
    CInboundPipeClient(const CInboundPipeClient& a_rPipe);
    const CInboundPipeClient& operator=(const CInboundPipeClient& a_rPipe);
};

//The declaration of COutboundPipeClient
class COutboundPipeClient:
    public CPipeClient
{
public:
    COutboundPipeClient(void);
    virtual ~COutboundPipeClient(void);
private:
    using CPipeClient::Read;
    COutboundPipeClient(const COutboundPipeClient& a_rPipe);
    const COutboundPipeClient& operator=(const COutboundPipeClient& a_rPipe);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of PipeClient.hpp

\*_________________________________________________________*/
