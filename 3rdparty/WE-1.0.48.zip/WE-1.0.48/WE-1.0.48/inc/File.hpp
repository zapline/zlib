/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              File.hpp

    Comment:                encapsulation of File I/O

    Class Name:             Windows::Base::CFile

    Version:                4.0

    Build:                  43

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/06/09-1999/11/02 (0.5)
                            2003/01/02-2003/04/26 (1.0)
                            2004/04/10-2004/05/25 (1.1.29)
                            2004/09/22-2004/09/23 (1.1.30)
                            2005/05/04-2005/05/04 (2.0.31)
                            2005/09/10-2005/09/10 (2.0.32)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/05-2010/01/26 (3.1)
                            2010/01/29-2010/01/29 (3.2)
                            2011/10/01-2011/10/02 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef FILE_HPP
#define FILE_HPP

#include <FileI.hpp>
#include <welink.h>

namespace Windows
{
namespace Base
{

//The definition of ECreationDisposition
enum ECreationDisposition
{
    eCreateNew = CREATE_NEW, //1
    eCreateAlways = CREATE_ALWAYS, //2
    eOpenExisting = OPEN_EXISTING, //3
    eOpenAlways = OPEN_ALWAYS, //4
    eTruncateExisting = TRUNCATE_EXISTING, //5
};

//The declaration of CFile
class CFile:
    public IFile
{
public:
    CFile(void);
    virtual ~CFile(void);
    virtual void Close(void);
    virtual bool Seek(LONGLONG a_nDistance, EMoveMethod a_eMoveMethod)const;
    virtual bool Seek(ULONGLONG a_nPosition)const;
    virtual bool SeekToBegin(void)const;
    virtual bool SeekToEnd(void)const;
    virtual bool Read(void* a_pBuffer, DWORD a_dwNumberOfBytesToRead, DWORD& a_rdwNumberOfBytesRead)const;
    virtual bool Write(const void* a_pBuffer, DWORD a_dwNumberOfBytesToWrite, DWORD& a_rdwNumberOfBytesWritten)const;
    virtual ULONGLONG GetLength(void)const;
    virtual bool SetLength(ULONGLONG a_nLength)const;
    virtual bool GetTime(FILETIME* a_pCreationTime, FILETIME* a_pLastAccessTime, FILETIME* a_pLastWriteTime)const;
    virtual bool SetTime(const FILETIME* a_pCreationTime, const FILETIME* a_pLastAccessTime, const FILETIME* a_pLastWriteTime)const;
    virtual operator HANDLE(void)const;
    bool Open(LPCTSTR a_szFileName, ECreationDisposition a_eDisposition=eOpenAlways, DWORD a_dwAccessMode=GENERIC_READ|GENERIC_WRITE, DWORD a_dwShareMode=(DWORD)NULL, DWORD a_dwAttributes=FILE_ATTRIBUTE_NORMAL, LPSECURITY_ATTRIBUTES a_pSecurity=(LPSECURITY_ATTRIBUTES)NULL, HANDLE a_hTemplate=(HANDLE)NULL);
    bool Flush(void)const;
    static bool Delete(LPCTSTR a_szFileName);
    static bool Rename(LPCTSTR a_szOldFileName, LPCTSTR a_szNewFileName);
    static bool CreateFolder(LPCTSTR a_szFolderName, LPSECURITY_ATTRIBUTES a_pSecurity=(LPSECURITY_ATTRIBUTES)NULL);
    static bool DeleteFolder(LPCTSTR a_szFolderName);
protected:
    HANDLE m_hFile;
private:
    CFile(const CFile& a_rFile);
    const CFile& operator=(const CFile& a_rFile);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of File.hpp

\*_________________________________________________________*/
