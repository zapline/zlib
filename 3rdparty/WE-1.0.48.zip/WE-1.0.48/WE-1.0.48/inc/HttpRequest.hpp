/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              HttpRequest.hpp

    Comment:                encapsulation of Internet API (HTTP)

    Class Name:             Windows::Internet::CHttpRequest

    Version:                4.0

    Build:                  26

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2002/12/26-2003/01/24 (1.0)
                            2004/05/09-2004/05/20 (1.1.14)
                            2004/09/23-2004/09/23 (1.1.15)
                            2004/11/06-2004/11/06 (1.1.16)
                            2005/05/04-2005/05/04 (2.0)
                            2005/09/25-2005/09/25 (2.1.18)
                            2008/06/21-2008/06/21 (2.1.19)
                            2010/01/24-2010/01/24 (2.2)
                            2010/01/30-2010/01/30 (2.3)
                            2010/02/27-2010/02/27 (3.0)
                            2010/06/04-2010/06/04 (3.1)
                            2011/08/24-2011/08/24 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef HTTP_REQUEST_HPP
#define HTTP_REQUEST_HPP

#include <InternetFile.hpp>
#include <welink.h>

//The definition of compatibility
#if !defined(HTTP_QUERY_EXPECT)
#define HTTP_QUERY_EXPECT                68
#define HTTP_QUERY_PROXY_CONNECTION      69
#define HTTP_QUERY_UNLESS_MODIFIED_SINCE 70
#define HTTP_QUERY_ECHO_REQUEST          71
#define HTTP_QUERY_ECHO_REPLY            72
#define HTTP_QUERY_ECHO_HEADERS          73
#define HTTP_QUERY_ECHO_HEADERS_CRLF     74
#define HTTP_QUERY_PROXY_SUPPORT         75
#define HTTP_QUERY_AUTHENTICATION_INFO   76
#define HTTP_QUERY_PASSPORT_URLS         77
#define HTTP_QUERY_PASSPORT_CONFIG       78
#endif

//The definition of compatibility
#if !defined(HTTP_STATUS_RETRY_WITH)
#define HTTP_STATUS_RETRY_WITH 449
#endif

namespace Windows
{
namespace Internet
{

//The definition of EHttpQueryFlag
enum EHttpQueryFlag
{
    eHttpMimeVersion = HTTP_QUERY_MIME_VERSION, //0
    eHttpContentType = HTTP_QUERY_CONTENT_TYPE, //1
    eHttpContentTransferEncoding = HTTP_QUERY_CONTENT_TRANSFER_ENCODING, //2
    eHttpContentID = HTTP_QUERY_CONTENT_ID, //3
    eHttpContentDescription = HTTP_QUERY_CONTENT_DESCRIPTION, //4
    eHttpContentLength = HTTP_QUERY_CONTENT_LENGTH, //5
    eHttpContentLanguage = HTTP_QUERY_CONTENT_LANGUAGE, //6
    eHttpAllow = HTTP_QUERY_ALLOW, //7
    eHttpPublic = HTTP_QUERY_PUBLIC, //8
    eHttpDate = HTTP_QUERY_DATE, //9
    eHttpExpires = HTTP_QUERY_EXPIRES, //10
    eHttpLastModified = HTTP_QUERY_LAST_MODIFIED, //11
    eHttpMessageID = HTTP_QUERY_MESSAGE_ID, //12
    eHttpUri = HTTP_QUERY_URI, //13
    eHttpDerivedFrom = HTTP_QUERY_DERIVED_FROM, //14
    eHttpCost = HTTP_QUERY_COST, //15
    eHttpLink = HTTP_QUERY_LINK, //16
    eHttpPragma = HTTP_QUERY_PRAGMA, //17
    eHttpVersion = HTTP_QUERY_VERSION, //18
    eHttpStatusCode = HTTP_QUERY_STATUS_CODE, //19
    eHttpStatusText = HTTP_QUERY_STATUS_TEXT, //20
    eHttpRawHeaders = HTTP_QUERY_RAW_HEADERS, //21
    eHttpRawHeadersCrlf = HTTP_QUERY_RAW_HEADERS_CRLF, //22
    eHttpConnection = HTTP_QUERY_CONNECTION, //23
    eHttpAccept = HTTP_QUERY_ACCEPT, //24
    eHttpAcceptCharset = HTTP_QUERY_ACCEPT_CHARSET, //25
    eHttpAcceptEncoding = HTTP_QUERY_ACCEPT_ENCODING, //26
    eHttpAcceptLanguage = HTTP_QUERY_ACCEPT_LANGUAGE, //27
    eHttpAuthorization = HTTP_QUERY_AUTHORIZATION, //28
    eHttpContentEncoding = HTTP_QUERY_CONTENT_ENCODING, //29
    eHttpForwarded = HTTP_QUERY_FORWARDED, //30
    eHttpFrom = HTTP_QUERY_FROM, //31
    eHttpIfModifiedSince = HTTP_QUERY_IF_MODIFIED_SINCE, //32
    eHttpLocation = HTTP_QUERY_LOCATION, //33
    eHttpOriginalUri = HTTP_QUERY_ORIG_URI, //34
    eHttpReferer = HTTP_QUERY_REFERER, //35
    eHttpRetryAfter = HTTP_QUERY_RETRY_AFTER, //36
    eHttpServer = HTTP_QUERY_SERVER, //37
    eHttpTitle = HTTP_QUERY_TITLE, //38
    eHttpUserAgent = HTTP_QUERY_USER_AGENT, //39
    eHttpWWWAuthenticate = HTTP_QUERY_WWW_AUTHENTICATE, //40
    eHttpProxyAuthenticate = HTTP_QUERY_PROXY_AUTHENTICATE, //41
    eHttpAcceptRanges = HTTP_QUERY_ACCEPT_RANGES, //42
    eHttpSetCookie = HTTP_QUERY_SET_COOKIE, //43
    eHttpCookie = HTTP_QUERY_COOKIE, //44
    eHttpRequestMethod = HTTP_QUERY_REQUEST_METHOD, //45
    eHttpRefresh = HTTP_QUERY_REFRESH, //46
    eHttpContentDisposition = HTTP_QUERY_CONTENT_DISPOSITION, //47
    eHttpAge = HTTP_QUERY_AGE, //48
    eHttpCacheControl = HTTP_QUERY_CACHE_CONTROL, //49
    eHttpContentBase = HTTP_QUERY_CONTENT_BASE, //50
    eHttpContentLocation = HTTP_QUERY_CONTENT_LOCATION, //51
    eHttpContentMD5 = HTTP_QUERY_CONTENT_MD5, //52
    eHttpContentRange = HTTP_QUERY_CONTENT_RANGE, //53
    eHttpEntityTag = HTTP_QUERY_ETAG, //54
    eHttpHost = HTTP_QUERY_HOST, //55
    eHttpIfMatch = HTTP_QUERY_IF_MATCH, //56
    eHttpIfNoneMatch = HTTP_QUERY_IF_NONE_MATCH, //57
    eHttpIfRange = HTTP_QUERY_IF_RANGE, //58
    eHttpIfUnmodifiedSince = HTTP_QUERY_IF_UNMODIFIED_SINCE, //59
    eHttpMaxForwards = HTTP_QUERY_MAX_FORWARDS, //60
    eHttpProxyAuthorization = HTTP_QUERY_PROXY_AUTHORIZATION, //61
    eHttpRange = HTTP_QUERY_RANGE, //62
    eHttpTransferEncoding = HTTP_QUERY_TRANSFER_ENCODING, //63
    eHttpUpgrade = HTTP_QUERY_UPGRADE, //64
    eHttpVary = HTTP_QUERY_VARY, //65
    eHttpVia = HTTP_QUERY_VIA, //66
    eHttpWarning = HTTP_QUERY_WARNING, //67
    eHttpExpect = HTTP_QUERY_EXPECT, //68
    eHttpProxyConnection = HTTP_QUERY_PROXY_CONNECTION, //69
    eHttpUnlessModifiedSince = HTTP_QUERY_UNLESS_MODIFIED_SINCE, //70
    eHttpEchoRequest = HTTP_QUERY_ECHO_REQUEST, //71
    eHttpEchoReply = HTTP_QUERY_ECHO_REPLY, //72
    eHttpEchoHeaders = HTTP_QUERY_ECHO_HEADERS, //73
    eHttpEchoHeadersCrlf = HTTP_QUERY_ECHO_HEADERS_CRLF, //74
    eHttpProxySupport = HTTP_QUERY_PROXY_SUPPORT, //75
    eHttpAuthenticationInfo = HTTP_QUERY_AUTHENTICATION_INFO, //76
    eHttpPassportUrls = HTTP_QUERY_PASSPORT_URLS, //77
    eHttpPassportConfig = HTTP_QUERY_PASSPORT_CONFIG, //78
    eHttpCustom = HTTP_QUERY_CUSTOM, //65535
};

//The definition of EHttpStatus
enum EHttpStatus
{
    eStatusError = 0,
    eStatusContinue = HTTP_STATUS_CONTINUE, //100
    eStatusSwitchProtocols = HTTP_STATUS_SWITCH_PROTOCOLS, //101
    eStatusOK = HTTP_STATUS_OK, //200
    eStatusCreated = HTTP_STATUS_CREATED, //201
    eStatusAccepted = HTTP_STATUS_ACCEPTED, //202
    eStatusPartial = HTTP_STATUS_PARTIAL, //203
    eStatusNoContent = HTTP_STATUS_NO_CONTENT, //204
    eStatusResetContent = HTTP_STATUS_RESET_CONTENT, //205
    eStatusPartialContent = HTTP_STATUS_PARTIAL_CONTENT, //206
    eStatusAmbiguous = HTTP_STATUS_AMBIGUOUS, //300
    eStatusMoved = HTTP_STATUS_MOVED, //301
    eStatusRedirect = HTTP_STATUS_REDIRECT, //302
    eStatusRedirectMethod = HTTP_STATUS_REDIRECT_METHOD, //303
    eStatusNotModified = HTTP_STATUS_NOT_MODIFIED, //304
    eStatusUseProxy = HTTP_STATUS_USE_PROXY, //305
    eStatusRedirectKeepVerb = HTTP_STATUS_REDIRECT_KEEP_VERB, //307
    eStatusBadRequest = HTTP_STATUS_BAD_REQUEST, //400
    eStatusDenied = HTTP_STATUS_DENIED, //401
    eStatusPaymentRequired = HTTP_STATUS_PAYMENT_REQ, //402
    eStatusForbidden = HTTP_STATUS_FORBIDDEN, //403
    eStatusNotFound = HTTP_STATUS_NOT_FOUND, //404
    eStatusBadMethod = HTTP_STATUS_BAD_METHOD, //405
    eStatusNoneAcceptable = HTTP_STATUS_NONE_ACCEPTABLE, //406
    eStatusProxyAuthenticationRequired = HTTP_STATUS_PROXY_AUTH_REQ, //407
    eStatusRequestTimeout = HTTP_STATUS_REQUEST_TIMEOUT, //408
    eStatusConflict = HTTP_STATUS_CONFLICT, //409
    eStatusGone = HTTP_STATUS_GONE, //410
    eStatusLengthRequired = HTTP_STATUS_LENGTH_REQUIRED, //411
    eStatusPrecondFailed = HTTP_STATUS_PRECOND_FAILED, //412
    eStatusRequestTooLarge = HTTP_STATUS_REQUEST_TOO_LARGE, //413
    eStatusUriTooLong = HTTP_STATUS_URI_TOO_LONG, //414
    eStatusUnsupportedMedia = HTTP_STATUS_UNSUPPORTED_MEDIA, //415
    eStatusRetryWith = HTTP_STATUS_RETRY_WITH, //449
    eStatusServerError = HTTP_STATUS_SERVER_ERROR, //500
    eStatusNotSupported = HTTP_STATUS_NOT_SUPPORTED, //501
    eStatusBadGateway = HTTP_STATUS_BAD_GATEWAY, //502
    eStatusServiceUnavailable = HTTP_STATUS_SERVICE_UNAVAIL, //503
    eStatusGatewayTimeout = HTTP_STATUS_GATEWAY_TIMEOUT, //504
    eStatusVersionNotSupport = HTTP_STATUS_VERSION_NOT_SUP, //505
};

//The declaration of CHttpRequest
class CHttpRequest:
    public CFile
{
public:
    CHttpRequest(void);
    virtual ~CHttpRequest(void);
    virtual ULONGLONG GetLength(void)const;
    virtual bool SetLength(ULONGLONG a_nLength)const;
    virtual bool GetTime(FILETIME* a_pCreationTime, FILETIME* a_pLastAccessTime, FILETIME* a_pLastWriteTime)const;
    virtual bool SetTime(const FILETIME* a_pCreationTime, const FILETIME* a_pLastAccessTime, const FILETIME* a_pLastWriteTime)const;
    bool Open(HANDLE a_hConnect, LPCTSTR a_szVerb, LPCTSTR a_szObjectName, LPCTSTR* a_pszAcceptTypes, DWORD a_dwFlags);
    bool AddRequestHeaders(LPCTSTR a_szHeaders, DWORD a_dwModifiers)const;
    bool SendRequest(LPCTSTR a_szHeaders=(LPCTSTR)NULL, const void* a_pOptional=(const void*)NULL, DWORD a_dwOptionalLength=(DWORD)0)const;
    DWORD QueryInfoLength(EHttpQueryFlag a_eInfo)const;
    bool QueryInfo(EHttpQueryFlag a_eInfo, LPTSTR a_szInfo, DWORD a_dwBufferSize)const;
    bool QueryInfo(EHttpQueryFlag a_eInfo, DWORD& a_rdwInfo)const;
    bool QueryInfo(EHttpQueryFlag a_eInfo, ULONGLONG& a_rnInfo)const;
    bool QueryInfo(EHttpQueryFlag a_eInfo, FILETIME& a_rInfo)const;
    bool SetContentRange(ULONGLONG a_nBegin, ULONGLONG a_nEnd)const;
    bool SetContentRange(ULONGLONG a_nBegin)const;
    EHttpStatus GetStatusCode(void)const;
    ULONGLONG GetContentLength(void)const;
    void GetContentRange(ULONGLONG& a_rnBegin, ULONGLONG& a_rnEnd)const;
    bool GetLastModified(FILETIME& a_rTime)const;
    bool GetOriginationDate(FILETIME& a_rTime)const;
private:
    CHttpRequest(const CHttpRequest& a_rRequest);
    const CHttpRequest& operator=(const CHttpRequest& a_rRequest);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of HttpRequest.hpp

\*_________________________________________________________*/
