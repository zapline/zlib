/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              CodePage.hpp

    Comment:                encapsulation of Code Page

    Type Name:              Windows::International::ECodePage

    Version:                1.4

    Build:                  6

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/08/05-1999/08/16 (0.5)
                            2004/04/14-2004/04/25 (1.0)
                            2004/09/23-2004/09/23 (1.1)
                            2005/04/23-2005/04/23 (1.2)
                            2010/01/18-2010/01/18 (1.3)
                            2011/11/19-2011/11/19 (1.4)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef CODE_PAGE_HPP
#define CODE_PAGE_HPP

//The definition of CP_*
//#define CP_ACP          0
//#define CP_OEMCP        1
//#define CP_MACCP        2
//#define CP_THREAD_ACP   3
//#define CP_SYMBOL       42
//#define CP_UTF7         65000
//#define CP_UTF8         65001
#define CP_UTF16        1200
#define CP_UTF16_BE     1201
#define CP_UTF32        12000
#define CP_UTF32_BE     12001
#define CP_ANSI_THAI                874
#define CP_ANSI_JAPANESE            932
#define CP_ANSI_SHIFT_JIS           932
#define CP_ANSI_SIMPLIFIED_CHINESE  936
#define CP_ANSI_GB2312              936
#define CP_ANSI_KOREAN              949
#define CP_ANSI_UNIFIED_HANGEUL     949
#define CP_ANSI_TRADITIONAL_CHINESE 950
#define CP_ANSI_BIG5                950
#define CP_ANSI_CENTRAL_EUROPEAN    1250
#define CP_ANSI_CYRILLIC            1251
#define CP_ANSI_LATIN_I             1252
#define CP_ANSI_GREEK               1253
#define CP_ANSI_TURKISH             1254
#define CP_ANSI_HEBREW              1255
#define CP_ANSI_ARABIC              1256
#define CP_ANSI_BALTIC              1257
#define CP_ANSI_VIETNAMESE          1258
#define CP_OEM_UNITED_STATES        437
#define CP_OEM_GREEK                737
#define CP_OEM_437G                 737
#define CP_OEM_BALTIC               775
#define CP_OEM_LATIN_I              850
#define CP_OEM_MULTILINGUAL         850
#define CP_OEM_LATIN_II             852
#define CP_OEM_CYRILLIC             855
#define CP_OEM_CYRILLIC_RUSSIAN     855
#define CP_OEM_TURKISH              857
#define CP_OEM_LATIN_I_PLUS         858
#define CP_OEM_MULTILINGUAL_PLUS    858
#define CP_OEM_PORTUGUESE           860
#define CP_OEM_ICELANDIC            861
#define CP_OEM_HEBREW               862
#define CP_OEM_FRENCH_CANADIAN      863
#define CP_OEM_ARABIC               864
#define CP_OEM_NORDIC               865
#define CP_OEM_RUSSIAN              866
#define CP_OEM_MODERN_GREEK         869
#define CP_OEM_THAI                 874
#define CP_OEM_JAPANESE             932
#define CP_OEM_SHIFT_JIS            932
#define CP_OEM_SIMPLIFIED_CHINESE   936
#define CP_OEM_GB2312               936
#define CP_OEM_KOREAN               949
#define CP_OEM_UNIFIED_HANGEUL      949
#define CP_OEM_TRADITIONAL_CHINESE  950
#define CP_OEM_BIG5                 950
#define CP_OEM_VIETNAMESE           1258
#define CP_MAC_ROMAN                10000
#define CP_MAC_JAPANESE             10001
#define CP_MAC_TRADITIONAL_CHINESE  10002
#define CP_MAC_BIG5                 10002
#define CP_MAC_KOREAN               10003
#define CP_MAC_ARABIC               10004
#define CP_MAC_HEBREW               10005
#define CP_MAC_GREEK                10006
#define CP_MAC_CYRILLIC             10007
#define CP_MAC_SIMPLIFIED_CHINESE   10008
#define CP_MAC_GB2312               10008
#define CP_MAC_ROMANIA              10010
#define CP_MAC_UKRAINE              10017
#define CP_MAC_THAI                 10021
#define CP_MAC_LATIN_II             10029
#define CP_MAC_ICELANDIC            10079
#define CP_MAC_TURKISH              10081
#define CP_MAC_CROATIAN             10082
#define CP_ISO_NON_SPACING_ACCENT                   20269
#define CP_ISO_6937                                 20269
#define CP_ISO_LATIN_I                              28591
#define CP_ISO_8859_1                               28591
#define CP_ISO_CENTRAL_EUROPE                       28592
#define CP_ISO_8859_2                               28592
#define CP_ISO_LATIN_III                            28593
#define CP_ISO_8859_3                               28593
#define CP_ISO_BALTIC                               28594
#define CP_ISO_8859_4                               28594
#define CP_ISO_CYRILLIC                             28595
#define CP_ISO_8859_5                               28595
#define CP_ISO_ARABIC                               28596
#define CP_ISO_8859_6                               28596
#define CP_ISO_GREEK                                28597
#define CP_ISO_8859_7                               28597
#define CP_ISO_HEBREW                               28598
#define CP_ISO_8859_8                               28598
#define CP_ISO_TURKISH                              28599
#define CP_ISO_8859_9                               28599
#define CP_ISO_ESTONIAN                             28603
#define CP_ISO_8859_13                              28603
#define CP_ISO_LATIN_IX                             28605
#define CP_ISO_8859_15                              28605
#define CP_ISO_HEBREW_I                             38598
#define CP_ISO_8859_8_I                             38598
#define CP_ISO_JAPANESE_NO_HALFWIDTH_KATAKANA       50220
#define CP_ISO_2022_JAPANESE_NO_HALFWIDTH_KATAKANA  50220
#define CP_ISO_JAPANESE_HALFWIDTH_KATAKANA          50221
#define CP_ISO_2022_JAPANESE_HALFWIDTH_KATAKANA     50221
#define CP_ISO_JAPANESE                             50222
#define CP_ISO_2022_JAPANESE                        50222
#define CP_ISO_KOREAN                               50225
#define CP_ISO_2022_KOREAN                          50225
#define CP_ISO_SIMPLIFIED_CHINESE                   50227
#define CP_ISO_2022_SIMPLIFIED_CHINESE              50227
#define CP_ISO_TRADITIONAL_CHINESE                  50229
#define CP_ISO_2022_TRADITIONAL_CHINESE             50229
#define CP_IBM_EBCDIC_UNITED_STATES                     37
#define CP_IBM_EBCDIC_CANADA                            37
#define CP_IBM_EBCDIC_INTERNATIONAL                     500
#define CP_IBM_EBCDIC_MULTILINGUAL                      870
#define CP_IBM_EBCDIC_ROECE                             870
#define CP_IBM_EBCDIC_LATIN_II                          870
#define CP_IBM_EBCDIC_MODERN_GREEK                      875
#define CP_IBM_EBCDIC_LATIN_V                           1026
#define CP_IBM_EBCDIC_LATIN_V_TURKISH                   1026
#define CP_IBM_EBCDIC_LATIN_I                           1047
#define CP_IBM_EBCDIC_OPEN_SYSTEM                       1047
#define CP_IBM_EBCDIC_UNITED_STATES_PLUS                1140
#define CP_IBM_EBCDIC_CANADA_PLUS                       1140
#define CP_IBM_EBCDIC_GERMANY_PLUS                      1141
#define CP_IBM_EBCDIC_DENMARK_PLUS                      1142
#define CP_IBM_EBCDIC_NORWAY_PLUS                       1142
#define CP_IBM_EBCDIC_FINLAND_PLUS                      1143
#define CP_IBM_EBCDIC_SWEDEN_PLUS                       1143
#define CP_IBM_EBCDIC_ITALY_PLUS                        1144
#define CP_IBM_EBCDIC_SPAIN_PLUS                        1145
#define CP_IBM_EBCDIC_LATIN_AMERICA_PLUS                1145
#define CP_IBM_EBCDIC_UNITED_KINGDOM_PLUS               1146
#define CP_IBM_EBCDIC_FRANCE_PLUS                       1147
#define CP_IBM_EBCDIC_INTERNATIONAL_PLUS                1148
#define CP_IBM_EBCDIC_ICELANDIC_PLUS                    1149
#define CP_IBM_EBCDIC_GERMANY                           20273
#define CP_IBM_EBCDIC_DENMARK                           20277
#define CP_IBM_EBCDIC_NORWAY                            20277
#define CP_IBM_EBCDIC_FINLAND                           20278
#define CP_IBM_EBCDIC_SWEDEN                            20278
#define CP_IBM_EBCDIC_ITALY                             20280
#define CP_IBM_EBCDIC_SPAIN                             20284
#define CP_IBM_EBCDIC_LATIN_AMERICA                     20284
#define CP_IBM_EBCDIC_UNITED_KINGDOM                    20285
#define CP_IBM_EBCDIC_JAPANESE_KATAKANA_EXTENDED        20290
#define CP_IBM_EBCDIC_FRANCE                            20297
#define CP_IBM_EBCDIC_ARABIC                            20420
#define CP_IBM_EBCDIC_GREEK                             20423
#define CP_IBM_EBCDIC_HEBREW                            20424
#define CP_IBM_EBCDIC_KOREAN_EXTENDED                   20833
#define CP_IBM_EBCDIC_THAI                              20838
#define CP_IBM_EBCDIC_ICELANDIC                         20871
#define CP_IBM_EBCDIC_RUSSIAN                           20880
#define CP_IBM_EBCDIC_CYRILLIC_RUSSIAN                  20880
#define CP_IBM_EBCDIC_TURKISH                           20905
#define CP_IBM_EBCDIC_SERBIAN                           21025
#define CP_IBM_EBCDIC_CYRILLIC_SERBIAN                  21025
#define CP_IBM_EBCDIC_BULGARIAN                         21025
#define CP_IBM_EBCDIC_CYRILLIC_BULGARIAN                21025
#define CP_IBM_EBCDIC_LATIN_I_PLUS                      20924
#define CP_IBM_EBCDIC_OPEN_SYSTEM_PLUS                  20924
#define CP_IBM_EBCDIC_JAPANESE_EXTENDED                 50930
#define CP_IBM_EBCDIC_JAPANESE_UNITED_STATES            50931
#define CP_IBM_EBCDIC_JAPANESE_CANADA                   50931
#define CP_IBM_EBCDIC_KOREAN_WITH_EXTENDED              50933
#define CP_IBM_EBCDIC_SIMPLIFIED_CHINESE_WITH_EXTENDED  50935
#define CP_IBM_EBCDIC_SIMPLIFIED_CHINESE                50936
#define CP_IBM_EBCDIC_TRADITIONAL_CHINESE_UNITED_STATES 50937
#define CP_IBM_EBCDIC_TRADITIONAL_CHINESE_CANADA        50937
#define CP_IBM_EBCDIC_JAPANESE_WITH_LATIN_EXTENDED      50939
#define CP_EUC_JAPANESE             51932
#define CP_EUC_SIMPLIFIED_CHINESE   51936
#define CP_EUC_KOREAN               51949
#define CP_EUC_TRADITIONAL_CHINESE  51950
#define CP_ASCII_UNITED_STATES  20127
#define CP_IA5                  20105
#define CP_IA5_GERMAN           20106
#define CP_IA5_SWEDISH          20107
#define CP_IA5_NORWEGIAN        20108
#define CP_EUROPA_3             29001
#define CP_ARABIC_ASMO              708
#define CP_ARABIC_ASMO_708          708
#define CP_ARABIC_ASMO_449_PLUS     709
#define CP_ARABIC_BCON_V4           709
#define CP_ARABIC_TRANSPARENT       710
#define CP_ARABIC_TRANSPARENT_ASMO  720
#define CP_RUSSIAN_KOI8_R   20866
#define CP_KOI8_R           20866
#define CP_UKRAINIAN_KOI8_U 21866
#define CP_KOI8_U           21866
#define CP_JAPANESE_JIS_0208_1990   20932
#define CP_JAPANESE_JIS_0212_1990   20932
#define CP_JIS_0208_1990            20932
#define CP_JIS_0212_1990            20932
#define CP_SIMPLIFIED_CHINESE_GB2312    20936
#define CP_SIMPLIFIED_CHINESE_HZ_GB2312 52936
#define CP_SIMPLIFIED_CHINESE_GB18030   54936
#define CP_GB2312                       20936
#define CP_HZ_GB2312                    52936
#define CP_GB18030                      54936
#define CP_KOREAN_JOHAB     1361
#define CP_UNIFIED_HANGEUL  1361
#define CP_KSC5601_1992     1361
#define CP_KOREAN_WANSUNG   20949
#define CP_ISCII_DEVANAGARI 57002
#define CP_ISCII_BENGALI    57003
#define CP_ISCII_TAMIL      57004
#define CP_ISCII_TELUGU     57005
#define CP_ISCII_ASSAMESE   57006
#define CP_ISCII_ORIYA      57007
#define CP_ISCII_KANNADA    57008
#define CP_ISCII_MALAYALAM  57009
#define CP_ISCII_GUJARATI   57010
#define CP_ISCII_PUNJABI    57011
#define CP_TAIWAN_CNS       20000
#define CP_TAIWAN_TCA       20001
#define CP_TAIWAN_ETEN      20002
#define CP_TAIWAN_IBM_5550  20003
#define CP_TAIWAN_TELE_TEXT 20004
#define CP_TAIWAN_WANG      20005
#define CP_T_61 20261
#define CP_EXTENDED_ALPHA_LOWERCASE 21027

#if !(defined RC_INVOKED)

namespace Windows
{
namespace International
{

//The definition of ECodePage
enum ECodePage
{
    eCodePageDefaultANSI = CP_ACP,        //0
    eCodePageDefaultOEM  = CP_OEMCP,      //1
    eCodePageDefaultMAC  = CP_MACCP,      //2
    eCodePageThreadANSI  = CP_THREAD_ACP, //3
    eCodePageSymbol      = CP_SYMBOL,     //42
    eCodePageUTF7        = CP_UTF7,       //65000
    eCodePageUTF8        = CP_UTF8,       //65001
    eCodePageUTF16       = CP_UTF16,      //1200
    eCodePageUTF16_BE    = CP_UTF16_BE,   //1201
    eCodePageUTF32       = CP_UTF32,      //12000
    eCodePageUTF32_BE    = CP_UTF32_BE,   //12001
    eCodePageANSI_Thai               = CP_ANSI_THAI,                //874
    eCodePageANSI_Japanese           = CP_ANSI_JAPANESE,            //932
    eCodePageANSI_ShiftJIS           = CP_ANSI_SHIFT_JIS,           //932
    eCodePageANSI_SimplifiedChinese  = CP_ANSI_SIMPLIFIED_CHINESE,  //936
    eCodePageANSI_GB2312             = CP_ANSI_GB2312,              //936
    eCodePageANSI_Korean             = CP_ANSI_KOREAN,              //949
    eCodePageANSI_UnifiedHangeul     = CP_ANSI_UNIFIED_HANGEUL,     //949
    eCodePageANSI_TraditionalChinese = CP_ANSI_TRADITIONAL_CHINESE, //950
    eCodePageANSI_BIG5               = CP_ANSI_BIG5,                //950
    eCodePageANSI_CentralEuropean    = CP_ANSI_CENTRAL_EUROPEAN,    //1250
    eCodePageANSI_Cyrillic           = CP_ANSI_CYRILLIC,            //1251
    eCodePageANSI_LatinI             = CP_ANSI_LATIN_I,             //1252
    eCodePageANSI_Greek              = CP_ANSI_GREEK,               //1253
    eCodePageANSI_Turkish            = CP_ANSI_TURKISH,             //1254
    eCodePageANSI_Hebrew             = CP_ANSI_HEBREW,              //1255
    eCodePageANSI_Arabic             = CP_ANSI_ARABIC,              //1256
    eCodePageANSI_Baltic             = CP_ANSI_BALTIC,              //1257
    eCodePageANSI_Vietnamese         = CP_ANSI_VIETNAMESE,          //1258
    eCodePageOEM_UnitedStates       = CP_OEM_UNITED_STATES,       //437
    eCodePageOEM_Greek              = CP_OEM_GREEK,               //737
    eCodePageOEM_437G               = CP_OEM_437G,                //737
    eCodePageOEM_Baltic             = CP_OEM_BALTIC,              //775
    eCodePageOEM_LatinI             = CP_OEM_LATIN_I,             //850
    eCodePageOEM_Multilingual       = CP_OEM_MULTILINGUAL,        //850
    eCodePageOEM_LatinII            = CP_OEM_LATIN_II,            //852
    eCodePageOEM_Cyrillic           = CP_OEM_CYRILLIC,            //855
    eCodePageOEM_CyrillicRussian    = CP_OEM_CYRILLIC_RUSSIAN,    //855
    eCodePageOEM_Turkish            = CP_OEM_TURKISH,             //857
    eCodePageOEM_LatinIPlus         = CP_OEM_LATIN_I_PLUS,        //858
    eCodePageOEM_MultilingualPlus   = CP_OEM_MULTILINGUAL_PLUS,   //858
    eCodePageOEM_Portuguese         = CP_OEM_PORTUGUESE,          //860
    eCodePageOEM_Icelandic          = CP_OEM_ICELANDIC,           //861
    eCodePageOEM_Hebrew             = CP_OEM_HEBREW,              //862
    eCodePageOEM_FrenchCanadian     = CP_OEM_FRENCH_CANADIAN,     //863
    eCodePageOEM_Arabic             = CP_OEM_ARABIC,              //864
    eCodePageOEM_Nordic             = CP_OEM_NORDIC,              //865
    eCodePageOEM_Russian            = CP_OEM_RUSSIAN,             //866
    eCodePageOEM_ModernGreek        = CP_OEM_MODERN_GREEK,        //869
    eCodePageOEM_Thai               = CP_OEM_THAI,                //874
    eCodePageOEM_Japanese           = CP_OEM_JAPANESE,            //932
    eCodePageOEM_ShiftJIS           = CP_OEM_SHIFT_JIS,           //932
    eCodePageOEM_SimplifiedChinese  = CP_OEM_SIMPLIFIED_CHINESE,  //936
    eCodePageOEM_GB2312             = CP_OEM_GB2312,              //936
    eCodePageOEM_Korean             = CP_OEM_KOREAN,              //949
    eCodePageOEM_UnifiedHangeul     = CP_OEM_UNIFIED_HANGEUL,     //949
    eCodePageOEM_TraditionalChinese = CP_OEM_TRADITIONAL_CHINESE, //950
    eCodePageOEM_BIG5               = CP_OEM_BIG5,                //950
    eCodePageOEM_Vietnamese         = CP_OEM_VIETNAMESE,          //1258
    eCodePageMAC_Roman              = CP_MAC_ROMAN,               //10000
    eCodePageMAC_Japanese           = CP_MAC_JAPANESE,            //10001
    eCodePageMAC_TraditionalChinese = CP_MAC_TRADITIONAL_CHINESE, //10002
    eCodePageMAC_BIG5               = CP_MAC_BIG5,                //10002
    eCodePageMAC_Korean             = CP_MAC_KOREAN,              //10003
    eCodePageMAC_Arabic             = CP_MAC_ARABIC,              //10004
    eCodePageMAC_Hebrew             = CP_MAC_HEBREW,              //10005
    eCodePageMAC_Greek              = CP_MAC_GREEK,               //10006
    eCodePageMAC_Cyrillic           = CP_MAC_CYRILLIC,            //10007
    eCodePageMAC_SimplifiedChinese  = CP_MAC_SIMPLIFIED_CHINESE,  //10008
    eCodePageMAC_GB2312             = CP_MAC_GB2312,              //10008
    eCodePageMAC_Romania            = CP_MAC_ROMANIA,             //10010
    eCodePageMAC_Ukraine            = CP_MAC_UKRAINE,             //10017
    eCodePageMAC_Thai               = CP_MAC_THAI,                //10021
    eCodePageMAC_LatinII            = CP_MAC_LATIN_II,            //10029
    eCodePageMAC_Icelandic          = CP_MAC_ICELANDIC,           //10079
    eCodePageMAC_Turkish            = CP_MAC_TURKISH,             //10081
    eCodePageMAC_Croatian           = CP_MAC_CROATIAN,            //10082
    eCodePageISO_NonSpacingAccent         = CP_ISO_NON_SPACING_ACCENT,                  //20269
    eCodePageISO_6937                     = CP_ISO_6937,                                //20269
    eCodePageISO_LatinI                   = CP_ISO_LATIN_I,                             //28591
    eCodePageISO_8859_1                   = CP_ISO_8859_1,                              //28591
    eCodePageISO_CentralEurope            = CP_ISO_CENTRAL_EUROPE,                      //28592
    eCodePageISO_8859_2                   = CP_ISO_8859_2,                              //28592
    eCodePageISO_LatinIII                 = CP_ISO_LATIN_III,                           //28593
    eCodePageISO_8859_3                   = CP_ISO_8859_3,                              //28593
    eCodePageISO_Baltic                   = CP_ISO_BALTIC,                              //28594
    eCodePageISO_8859_4                   = CP_ISO_8859_4,                              //28594
    eCodePageISO_Cyrillic                 = CP_ISO_CYRILLIC,                            //28595
    eCodePageISO_8859_5                   = CP_ISO_8859_5,                              //28595
    eCodePageISO_Arabic                   = CP_ISO_ARABIC,                              //28596
    eCodePageISO_8859_6                   = CP_ISO_8859_6,                              //28596
    eCodePageISO_Greek                    = CP_ISO_GREEK,                               //28597
    eCodePageISO_8859_7                   = CP_ISO_8859_7,                              //28597
    eCodePageISO_Hebrew                   = CP_ISO_HEBREW,                              //28598
    eCodePageISO_8859_8                   = CP_ISO_8859_8,                              //28598
    eCodePageISO_Turkish                  = CP_ISO_TURKISH,                             //28599
    eCodePageISO_8859_9                   = CP_ISO_8859_9,                              //28599
    eCodePageISO_Estonian                 = CP_ISO_ESTONIAN,                            //28603
    eCodePageISO_8859_13                  = CP_ISO_8859_13,                             //28603
    eCodePageISO_Latin_IX                 = CP_ISO_LATIN_IX,                            //28605
    eCodePageISO_8859_15                  = CP_ISO_8859_15,                             //28605
    eCodePageISO_Hebrew_Logical           = CP_ISO_HEBREW_I,                            //38598
    eCodePageISO_8859_8_Logical           = CP_ISO_8859_8_I,                            //38598
    eCodePageISO_JapaneseNoHK             = CP_ISO_JAPANESE_NO_HALFWIDTH_KATAKANA,      //50220
    eCodePageISO_2022_JapaneseNoHK        = CP_ISO_2022_JAPANESE_NO_HALFWIDTH_KATAKANA, //50220
    eCodePageISO_JapaneseWithHK           = CP_ISO_JAPANESE_HALFWIDTH_KATAKANA,         //50221
    eCodePageISO_2022_JapaneseWithHK      = CP_ISO_2022_JAPANESE_HALFWIDTH_KATAKANA,    //50221
    eCodePageISO_Japanese                 = CP_ISO_JAPANESE,                            //50222
    eCodePageISO_2022_Japanese            = CP_ISO_2022_JAPANESE,                       //50222
    eCodePageISO_Korean                   = CP_ISO_KOREAN,                              //50225
    eCodePageISO_2022_Korean              = CP_ISO_2022_KOREAN,                         //50225
    eCodePageISO_SimplifiedChinese        = CP_ISO_SIMPLIFIED_CHINESE,                  //50227
    eCodePageISO_2022_SimplifiedChinese   = CP_ISO_2022_SIMPLIFIED_CHINESE,             //50227
    eCodePageISO_TraditionalChinese       = CP_ISO_TRADITIONAL_CHINESE,                 //50229
    eCodePageISO_2022_TraditionalChinese  = CP_ISO_2022_TRADITIONAL_CHINESE,            //50229
    eCodePageIBM_UnitedStates                   = CP_IBM_EBCDIC_UNITED_STATES,                     //37
    eCodePageIBM_Canada                         = CP_IBM_EBCDIC_CANADA,                            //37
    eCodePageIBM_International                  = CP_IBM_EBCDIC_INTERNATIONAL,                     //500
    eCodePageIBM_Multilingual                   = CP_IBM_EBCDIC_MULTILINGUAL,                      //870
    eCodePageIBM_Roece                          = CP_IBM_EBCDIC_ROECE,                             //870
    eCodePageIBM_LatinII                        = CP_IBM_EBCDIC_LATIN_II,                          //870
    eCodePageIBM_ModernGreek                    = CP_IBM_EBCDIC_MODERN_GREEK,                      //875
    eCodePageIBM_LatinV                         = CP_IBM_EBCDIC_LATIN_V,                           //1026
    eCodePageIBM_LatinVTurkish                  = CP_IBM_EBCDIC_LATIN_V_TURKISH,                   //1026
    eCodePageIBM_LatinI                         = CP_IBM_EBCDIC_LATIN_I,                           //1047
    eCodePageIBM_OpenSystem                     = CP_IBM_EBCDIC_OPEN_SYSTEM,                       //1047
    eCodePageIBM_UnitedStatesPlus               = CP_IBM_EBCDIC_UNITED_STATES_PLUS,                //1140
    eCodePageIBM_CanadaPlus                     = CP_IBM_EBCDIC_CANADA_PLUS,                       //1140
    eCodePageIBM_GermanyPlus                    = CP_IBM_EBCDIC_GERMANY_PLUS,                      //1141
    eCodePageIBM_DenmarkPlus                    = CP_IBM_EBCDIC_DENMARK_PLUS,                      //1142
    eCodePageIBM_NorwayPlus                     = CP_IBM_EBCDIC_NORWAY_PLUS,                       //1142
    eCodePageIBM_FinlandPlus                    = CP_IBM_EBCDIC_FINLAND_PLUS,                      //1143
    eCodePageIBM_SwedenPlus                     = CP_IBM_EBCDIC_SWEDEN_PLUS,                       //1143
    eCodePageIBM_ItalyPlus                      = CP_IBM_EBCDIC_ITALY_PLUS,                        //1144
    eCodePageIBM_SpainPlus                      = CP_IBM_EBCDIC_SPAIN_PLUS,                        //1145
    eCodePageIBM_LatinAmericaPlus               = CP_IBM_EBCDIC_LATIN_AMERICA_PLUS,                //1145
    eCodePageIBM_UnitedKingdomPlus              = CP_IBM_EBCDIC_UNITED_KINGDOM_PLUS,               //1146
    eCodePageIBM_FrancePlus                     = CP_IBM_EBCDIC_FRANCE_PLUS,                       //1147
    eCodePageIBM_InternationalPlus              = CP_IBM_EBCDIC_INTERNATIONAL_PLUS,                //1148
    eCodePageIBM_IcelandicPlus                  = CP_IBM_EBCDIC_ICELANDIC_PLUS,                    //1149
    eCodePageIBM_Germany                        = CP_IBM_EBCDIC_GERMANY,                           //20273
    eCodePageIBM_Denmark                        = CP_IBM_EBCDIC_DENMARK,                           //20277
    eCodePageIBM_Norway                         = CP_IBM_EBCDIC_NORWAY,                            //20277
    eCodePageIBM_Finland                        = CP_IBM_EBCDIC_FINLAND,                           //20278
    eCodePageIBM_Sweden                         = CP_IBM_EBCDIC_SWEDEN,                            //20278
    eCodePageIBM_Italy                          = CP_IBM_EBCDIC_ITALY,                             //20280
    eCodePageIBM_Spain                          = CP_IBM_EBCDIC_SPAIN,                             //20284
    eCodePageIBM_LatinAmerica                   = CP_IBM_EBCDIC_LATIN_AMERICA,                     //20284
    eCodePageIBM_UnitedKingdom                  = CP_IBM_EBCDIC_UNITED_KINGDOM,                    //20285
    eCodePageIBM_JapaneseKatakanaExtended       = CP_IBM_EBCDIC_JAPANESE_KATAKANA_EXTENDED,        //20290
    eCodePageIBM_France                         = CP_IBM_EBCDIC_FRANCE,                            //20297
    eCodePageIBM_Arabic                         = CP_IBM_EBCDIC_ARABIC,                            //20420
    eCodePageIBM_Greek                          = CP_IBM_EBCDIC_GREEK,                             //20423
    eCodePageIBM_Hebrew                         = CP_IBM_EBCDIC_HEBREW,                            //20424
    eCodePageIBM_KoreanExtended                 = CP_IBM_EBCDIC_KOREAN_EXTENDED,                   //20833
    eCodePageIBM_Thai                           = CP_IBM_EBCDIC_THAI,                              //20838
    eCodePageIBM_Icelandic                      = CP_IBM_EBCDIC_ICELANDIC,                         //20871
    eCodePageIBM_Russian                        = CP_IBM_EBCDIC_RUSSIAN,                           //20880
    eCodePageIBM_CyrillicRussian                = CP_IBM_EBCDIC_CYRILLIC_RUSSIAN,                  //20880
    eCodePageIBM_Turkish                        = CP_IBM_EBCDIC_TURKISH,                           //20905
    eCodePageIBM_Serbian                        = CP_IBM_EBCDIC_SERBIAN,                           //21025
    eCodePageIBM_CyrillicSerbian                = CP_IBM_EBCDIC_CYRILLIC_SERBIAN,                  //21025
    eCodePageIBM_Bulgarian                      = CP_IBM_EBCDIC_BULGARIAN,                         //21025
    eCodePageIBM_CyrillicBulgarian              = CP_IBM_EBCDIC_CYRILLIC_BULGARIAN,                //21025
    eCodePageIBM_LatinIPlus                     = CP_IBM_EBCDIC_LATIN_I_PLUS,                      //20924
    eCodePageIBM_OpenSystemPlus                 = CP_IBM_EBCDIC_OPEN_SYSTEM_PLUS,                  //20924
    eCodePageIBM_JapaneseExtended               = CP_IBM_EBCDIC_JAPANESE_EXTENDED,                 //50930
    eCodePageIBM_JapaneseUnitedStates           = CP_IBM_EBCDIC_JAPANESE_UNITED_STATES,            //50931
    eCodePageIBM_JapaneseCanada                 = CP_IBM_EBCDIC_JAPANESE_CANADA,                   //50931
    eCodePageIBM_KoreanWithExtended             = CP_IBM_EBCDIC_KOREAN_WITH_EXTENDED,              //50933
    eCodePageIBM_SimplifiedChineseWithExtended  = CP_IBM_EBCDIC_SIMPLIFIED_CHINESE_WITH_EXTENDED,  //50935
    eCodePageIBM_SimplifiedChinese              = CP_IBM_EBCDIC_SIMPLIFIED_CHINESE,                //50936
    eCodePageIBM_TraditionalChineseUnitedStates = CP_IBM_EBCDIC_TRADITIONAL_CHINESE_UNITED_STATES, //50937
    eCodePageIBM_TraditionalChineseCanada       = CP_IBM_EBCDIC_TRADITIONAL_CHINESE_CANADA,        //50937
    eCodePageIBM_JapaneseWithLatinExtended      = CP_IBM_EBCDIC_JAPANESE_WITH_LATIN_EXTENDED,      //50939
    eCodePageEUC_Japanese           = CP_EUC_JAPANESE,            //51932
    eCodePageEUC_SimplifiedChinese  = CP_EUC_SIMPLIFIED_CHINESE,  //51936
    eCodePageEUC_Korean             = CP_EUC_KOREAN,              //51949
    eCodePageEUC_TraditionalChinese = CP_EUC_TRADITIONAL_CHINESE, //51950
    eCodePageASCII_UnitedStates = CP_ASCII_UNITED_STATES, //20127
    eCodePageIA5                = CP_IA5,                 //20105
    eCodePageIA5_German         = CP_IA5_GERMAN,          //20106
    eCodePageIA5_Swedish        = CP_IA5_SWEDISH,         //20107
    eCodePageIA5_Norwegian      = CP_IA5_NORWEGIAN,       //20108
    eCodePageEuropa_3           = CP_EUROPA_3,            //29001
    eCodePageArabic_ASMO            = CP_ARABIC_ASMO,             //708
    eCodePageArabic_ASMO708         = CP_ARABIC_ASMO_708,         //708
    eCodePageArabic_ASMO449Plus     = CP_ARABIC_ASMO_449_PLUS,    //709
    eCodePageArabic_BCON_4          = CP_ARABIC_BCON_V4,          //709
    eCodePageArabic_Transparent     = CP_ARABIC_TRANSPARENT,      //710
    eCodePageArabic_TransparentASMO = CP_ARABIC_TRANSPARENT_ASMO, //720
    eCodePageRussian_KOI8_R   = CP_RUSSIAN_KOI8_R,   //20866
    eCodePageKOI8_R           = CP_KOI8_R,           //20866
    eCodePageUkrainian_KOI8_U = CP_UKRAINIAN_KOI8_U, //21866
    eCodePageKOI8_U           = CP_KOI8_U,           //21866
    eCodePageJapanese_JIS_0208_1990 = CP_JAPANESE_JIS_0208_1990, //20932
    eCodePageJapanese_JIS_0212_1990 = CP_JAPANESE_JIS_0212_1990, //20932
    eCodePageJIS_0208_1990          = CP_JIS_0208_1990,          //20932
    eCodePageJIS_0212_1990          = CP_JIS_0212_1990,          //20932
    eCodePageSimplifiedChinese_GB2312    = CP_SIMPLIFIED_CHINESE_GB2312,    //20936
    eCodePageSimplifiedChinese_HZ_GB2312 = CP_SIMPLIFIED_CHINESE_HZ_GB2312, //52936
    eCodePageSimplifiedChinese_GB18030   = CP_SIMPLIFIED_CHINESE_GB18030,   //54936
    eCodePageGB2312                      = CP_GB2312,                       //20936
    eCodePageHZ_GB2312                   = CP_HZ_GB2312,                    //52936
    eCodePageGB18030                     = CP_GB18030,                      //54936
    eCodePageKorean_JOHAB   = CP_KOREAN_JOHAB,    //1361
    eCodePageUnifiedHangeul = CP_UNIFIED_HANGEUL, //1361
    eCodePageKSC5601_1992   = CP_KSC5601_1992,    //1361
    eCodePageKorean_Wansung = CP_KOREAN_WANSUNG,  //20949
    eCodePageISCII_Devanagari = CP_ISCII_DEVANAGARI, //57002
    eCodePageISCII_Bengali    = CP_ISCII_BENGALI,    //57003
    eCodePageISCII_Tamil      = CP_ISCII_TAMIL,      //57004
    eCodePageISCII_Telugu     = CP_ISCII_TELUGU,     //57005
    eCodePageISCII_Assamese   = CP_ISCII_ASSAMESE,   //57006
    eCodePageISCII_Oriya      = CP_ISCII_ORIYA,      //57007
    eCodePageISCII_Kannada    = CP_ISCII_KANNADA,    //57008
    eCodePageISCII_Malayalam  = CP_ISCII_MALAYALAM,  //57009
    eCodePageISCII_Gujarati   = CP_ISCII_GUJARATI,   //57010
    eCodePageISCII_Punjabi    = CP_ISCII_PUNJABI,    //57011
    eCodePageTaiwan_CNS      = CP_TAIWAN_CNS,       //20000
    eCodePageTaiwan_TCA      = CP_TAIWAN_TCA,       //20001
    eCodePageTaiwan_Eten     = CP_TAIWAN_ETEN,      //20002
    eCodePageTaiwan_IBM5550  = CP_TAIWAN_IBM_5550,  //20003
    eCodePageTaiwan_TeleText = CP_TAIWAN_TELE_TEXT, //20004
    eCodePageTaiwan_Wang     = CP_TAIWAN_WANG,      //20005
    eCodePageT61 = CP_T_61, //20261
    eCodePageExtendedAlphaLowercase = CP_EXTENDED_ALPHA_LOWERCASE, //21027
};

}
}

#endif

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of CodePage.hpp

\*_________________________________________________________*/
