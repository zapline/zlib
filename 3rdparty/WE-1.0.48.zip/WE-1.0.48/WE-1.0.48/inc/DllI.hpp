/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              DllI.hpp

    Comment:                interface of Dynamic Link Library

    Interface Name:         Windows::Base::IDll

    Version:                4.0

    Build:                  9

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/10/20-2004/10/23 (1.0.1)
                            2004/11/06-2004/11/06 (1.0.2)
                            2004/12/05-2004/12/05 (1.0.3)
                            2004/12/11-2004/12/11 (1.0.4)
                            2005/04/23-2005/04/23 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2008/06/21-2008/06/21 (3.0)
                            2010/01/10-2010/01/10 (3.1)
                            2011/09/05-2011/09/05 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef DYNAMIC_LINK_LIBRARY_INTERFACE_HPP
#define DYNAMIC_LINK_LIBRARY_INTERFACE_HPP

namespace Windows
{
namespace Base
{

//The declaration of IDll
class IDll
{
protected:
    inline IDll(void){};
    inline ~IDll(void){};
public:
    virtual bool OnProcessAttach(HMODULE a_hModule, bool a_bStaticLoad)=0;
    virtual void OnProcessDetach(HMODULE a_hModule, bool a_bStaticLoad)=0;
    virtual void OnThreadAttach(HMODULE a_hModule)=0;
    virtual void OnThreadDetach(HMODULE a_hModule)=0;
    virtual operator HMODULE(void)const=0;
private:
    IDll(const IDll& a_rDll);
    const IDll& operator=(const IDll& a_rDll);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of DllI.hpp

\*_________________________________________________________*/
