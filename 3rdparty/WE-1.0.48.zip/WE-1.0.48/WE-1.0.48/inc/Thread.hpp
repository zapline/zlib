/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Thread.hpp

    Comment:                encapsulation of Thread

    Class Name:             Windows::Base::CThread

    Version:                4.0

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/12/25-2004/12/25 (1.0)
                            2005/04/23-2005/04/23 (1.1)
                            2005/07/31-2005/07/31 (1.2)
                            2005/09/04-2005/09/04 (1.3)
                            2005/09/10-2005/09/10 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2010/01/10-2010/01/11 (3.0)
                            2010/01/29-2010/02/02 (3.1)
                            2011/09/16-2011/09/16 (4.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef THREAD_HPP
#define THREAD_HPP

#include <welink.h>

namespace Windows
{
namespace Base
{

//The definition of EThreadPriority
enum EThreadPriority
{
    eTimeCriticalPriority = THREAD_PRIORITY_TIME_CRITICAL,
    eHighestPriority      = THREAD_PRIORITY_HIGHEST,
    eAboveNormalPriority  = THREAD_PRIORITY_ABOVE_NORMAL,
    eNormalPriority       = THREAD_PRIORITY_NORMAL,
    eBelowNormalPriority  = THREAD_PRIORITY_BELOW_NORMAL,
    eLowestPriority       = THREAD_PRIORITY_LOWEST,
#if (defined _WIN32_WCE)
    eAboveIdlePriority    = THREAD_PRIORITY_ABOVE_IDLE,
#endif
    eIdlePriority         = THREAD_PRIORITY_IDLE,
};

//The declaration of CThread
class CThread
{
public:
    CThread(void);
    ~CThread(void);
    bool Start(LPTHREAD_START_ROUTINE a_pStartAddress, void* a_pParameter);
    void Resume(void);
    void Suspend(void);
    void WaitExit(void)const;
    bool WaitExit(DWORD a_dwMilliseconds)const;
    DWORD GetExitCode(void)const;
    bool SetPriority(EThreadPriority a_ePriority);
    EThreadPriority GetPriority(void)const;
    operator HANDLE(void)const;
private:
    HANDLE m_hThread;
private:
    CThread(const CThread& a_rThread);
    const CThread& operator=(const CThread& a_rThread);
};

}
}

//The definition of THREAD_PROCEDURE_DECLARATION
#define THREAD_PROCEDURE_DECLARATION(a_ThreadProcedure) \
 \
static DWORD WINAPI a_ThreadProcedure(void* a_pParameter)

//The definition of THREAD_PROCEDURE_DEFINITION
#define THREAD_PROCEDURE_DEFINITION(a_CClass, a_ThreadProcedure) \
 \
DWORD WINAPI a_CClass::a_ThreadProcedure(void* a_pParameter) \
{ \
    ASSERT( a_pParameter!=(void*)NULL ); \
    a_CClass* pObject = (a_CClass*)a_pParameter; \
    return pObject->a_ThreadProcedure(); \
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Thread.hpp

\*_________________________________________________________*/
