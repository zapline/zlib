/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              DeviceContext.hpp

    Comment:                encapsulation of Device Context

    Class Name:             Windows::Graphics::CDC

    Version:                3.0

    Build:                  9

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/11/20-2004/11/20 (1.0.1)
                            2005/01/08-2005/01/08 (1.0.2)
                            2005/04/23-2005/04/23 (1.1.3)
                            2005/05/03-2005/05/03 (1.1.4)
                            2005/07/31-2005/07/31 (2.0)
                            2005/09/25-2005/09/25 (2.1)
                            2010/01/11-2010/01/11 (2.2)
                            2010/01/29-2010/01/29 (2.3)
                            2011/09/28-2011/09/28 (3.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef DEVICE_CONTEXT_HPP
#define DEVICE_CONTEXT_HPP

#include <welink.h>

namespace Windows
{
namespace Graphics
{

//The declaration of CDC
class CDC
{
protected:
    CDC(void);
    ~CDC(void);
public:
    HBITMAP Select(HBITMAP a_hBitmap);
    HBRUSH Select(HBRUSH a_hBrush);
    HFONT Select(HFONT a_hFont);
    HPEN Select(HPEN a_hPen);
    HRGN Select(HRGN a_hRegion);
    operator HDC(void)const;
protected:
    HDC m_hDeviceContext;
private:
    CDC(const CDC& a_rDeviceContext);
    const CDC& operator=(const CDC& a_rDeviceContext);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of DeviceContext.hpp

\*_________________________________________________________*/
