/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Control.hpp

    Comment:                encapsulation for Common Control

    Class Name:             Windows::UserInterface::CControl

    Version:                2.6

    Build:                  12

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/08/31-1999/11/17 (1.0)
                            2004/05/24-2004/05/27 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2005/01/08-2005/01/10 (2.0)
                            2005/04/23-2005/04/24 (2.1)
                            2005/06/19-2005/06/19 (2.2)
                            2005/09/25-2005/09/25 (2.3)
                            2010/01/16-2010/01/16 (2.4)
                            2010/01/30-2010/01/30 (2.5)
                            2011/10/05-2011/10/06 (2.6)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef CONTROL_HPP
#define CONTROL_HPP

#include <Window.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define IMAGE_ENHMETAFILE 3
#endif

//The definition of class names
#if !(defined WC_STATIC)
#define WC_STATIC    TEXT("STATIC")
#endif
#if !(defined WC_BUTTON)
#define WC_BUTTON    TEXT("BUTTON")
#endif
#if !(defined WC_EDIT)
#define WC_EDIT      TEXT("EDIT")
#endif
#if !(defined WC_SCROLLBAR)
#define WC_SCROLLBAR TEXT("SCROLLBAR")
#endif
#if !(defined WC_LISTBOX)
#define WC_LISTBOX   TEXT("LISTBOX")
#endif
#if !(defined WC_COMBOBOX)
#define WC_COMBOBOX  TEXT("COMBOBOX")
#endif

#if !(defined WC_DIALOG)
#if (defined _WIN32_WCE)
#define WC_DIALOG TEXT("Dialog")
#else
#define WC_DIALOG MAKEINTATOM(0x8002)
//#define WC_DIALOG TEXT("#32770")
#endif
#endif

//The definition of global functions
#define Control_Enable(a_hControl,a_bEnable) ((BOOL)EnableWindow((HWND)(a_hControl),(BOOL)(a_bEnable)))
#define Control_GetTextLength(a_hControl) ((int)GetWindowTextLength((HWND)(a_hControl)))
#define Control_GetText(a_hControl,a_szText,a_nBufferSize) ((int)GetWindowText((HWND)(a_hControl),(LPTSTR)(a_szText),(int)(a_nBufferSize)))
#define Control_SetText(a_hControl,a_szText) ((BOOL)SetWindowText((HWND)(a_hControl),(LPCTSTR)(a_szText)))

namespace Windows
{
namespace UserInterface
{

//The definition of EImageType
enum EImageType
{
    eBitmap           = IMAGE_BITMAP, //0
    eIcon             = IMAGE_ICON, //1
    eCursor           = IMAGE_CURSOR, //2
    eEnhancedMetafile = IMAGE_ENHMETAFILE, //3
};

//The declaration of CControl
class CControl:
    public CWindow
{
public:
    CControl(void);
    ~CControl(void);
    void Attach(HWND a_hParent, UINT a_idControl);
    bool Enable(bool a_bEnable);
    int GetTextLength(void);
    void GetText(LPTSTR a_szText, int a_nBufferSize);
    void SetText(LPCTSTR a_szText);
private:
    CControl(const CControl& a_rControl);
    const CControl& operator=(const CControl& a_rControl);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Control.hpp

\*_________________________________________________________*/
