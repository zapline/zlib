/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              InternetUrl.hpp

    Comment:                encapsulation of Internet API

    Class Name:             Windows::Internet::CUrl

    Version:                1.2

    Build:                  5

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2010/02/28-2010/02/28 (1.0)
                            2010/06/04-2010/06/04 (1.1)
                            2011/09/12-2011/09/12 (1.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef INTERNET_URL_HPP
#define INTERNET_URL_HPP

#include <welink.h>

namespace Windows
{
namespace Internet
{

//The declaration of CUrl
class CUrl
{
public:
    TCHAR m_acUrl[INTERNET_MAX_URL_LENGTH+1];
    TCHAR m_acScheme[INTERNET_MAX_SCHEME_LENGTH+1];
    TCHAR m_acHostName[INTERNET_MAX_HOST_NAME_LENGTH+1];
    TCHAR m_acPath[INTERNET_MAX_PATH_LENGTH+1];
    TCHAR m_acUserName[INTERNET_MAX_USER_NAME_LENGTH+1];
    TCHAR m_acPassword[INTERNET_MAX_PASSWORD_LENGTH+1];
    INTERNET_SCHEME m_eScheme;
    INTERNET_PORT m_nPort;
public:
    CUrl(LPCTSTR a_szUrl);
    //~CUrl(void);
    //CUrl(const CUrl& a_rUrl);
    //const CUrl& operator=(const CUrl& a_rUrl);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of InternetUrl.hpp

\*_________________________________________________________*/
