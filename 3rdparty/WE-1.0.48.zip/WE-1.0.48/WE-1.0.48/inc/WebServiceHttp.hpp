/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              WebServiceHttp.hpp

    Comment:                encapsulation of Web Service through HTTP

    Class Name:             Windows::Extension::CWebServiceHttp

    Version:                4.4

    Build:                  31

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/24-2003/06/15 (1.0)
                            2004/05/19-2003/05/27 (1.1.10)
                            2004/09/23-2004/09/23 (1.1.11)
                            2004/10/31-2004/10/31 (1.1.12)
                            2004/11/06-2004/11/06 (1.1.13)
                            2004/11/07-2004/11/07 (1.1.14)
                            2004/11/14-2004/11/14 (1.1.15)
                            2004/11/20-2004/11/20 (1.1.16)
                            2005/01/08-2005/01/08 (1.1.17)
                            2005/05/04-2005/05/04 (2.0)
                            2005/08/28-2005/08/28 (2.1)
                            2005/09/25-2005/09/25 (2.2)
                            2008/06/21-2008/06/21 (3.0)
                            2008/07/06-2008/07/06 (3.1)
                            2008/07/13-2008/07/13 (3.2)
                            2010/01/26-2010/01/26 (4.0)
                            2010/01/30-2010/01/31 (4.1)
                            2010/02/27-2010/02/27 (4.2)
                            2010/04/25-2010/04/25 (4.3)
                            2011/10/02-2011/10/02 (4.4)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WEB_SERVICE_HTTP_HPP
#define WEB_SERVICE_HTTP_HPP

#include <WebServiceProxyI.hpp>
#include <InternetSession.hpp>
#include <InternetConnect.hpp>
#include <InternetUrl.hpp>
#include <HttpRequest.hpp>
#include <ComPointer.hpp>
#include <welink.h>

namespace Windows
{
namespace Extension
{

//The declaration of CWebServiceHttp
class CWebServiceHttp:
    public WebService::IProxy
{
public:
    CWebServiceHttp(const wchar_t* a_szEndPointUrl, const wchar_t* a_szAgent);
    virtual ~CWebServiceHttp(void);
    operator bool(void)const;
    virtual void BeginAction(const wchar_t* a_szAction);
    virtual bool EndAction(void);
    virtual void PushParameter(const wchar_t* a_szName, const wchar_t* a_szValue);
    virtual void PushParameter(const wchar_t* a_szName, int a_nValue);
    virtual void PushParameter(const wchar_t* a_szName, dsal::const_list_i<dsal::wstring>* a_pValues);
    virtual void PushParameter(const wchar_t* a_szName, dsal::const_list_i<int>* a_pValues);
    virtual bool IsFault(void)const;
    virtual bool GetReturnValue(dsal::wstring& a_rsValue)const;
    virtual bool GetReturnValue(int& a_rnValue)const;
    virtual bool GetReturnParameter(const wchar_t* a_szName, dsal::wstring& a_rsValue)const;
    virtual bool GetReturnParameter(const wchar_t* a_szName, dsal::list_i<dsal::wstring>* a_pValues)const;
protected:
    Internet::CSession m_Session;
    Internet::CConnect m_Connect;
    Internet::CHttpRequest m_HttpFile;
    Internet::CUrl m_EndPointUrl;
    dsal::wstring m_sAction;
    dsal::wstring m_sRequest;
    Component::CPointer<IXMLDOMNode> m_pResult;
    bool m_bFault;
private:
    void GetReturnParameter(const wchar_t* a_szName, IXMLDOMNode** a_ppParameterNode)const;
    CWebServiceHttp(const CWebServiceHttp& a_rProxy);
    const CWebServiceHttp& operator=(const CWebServiceHttp& a_rProxy);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of WebServiceHttp.hpp

\*_________________________________________________________*/
