/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Application.h

    Comment:                encapsulation of Application

    Macro Name:             WINDOWS_APPLICATION

    Version:                3.0

    Build:                  11

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/06/11-2005/06/11 (1.0)
                            2005/07/31-2005/07/31 (1.1)
                            2005/09/25-2005/09/25 (1.2)
                            2008/06/21-2008/06/21 (1.3)
                            2010/01/10-2010/01/29 (2.0)
                            2010/01/30-2010/01/30 (2.1)
                            2011/08/29-2011/08/29 (3.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef APPLICATION_H
#define APPLICATION_H

#include <ApplicationI.hpp>
#include <welink.h>

//The pragma directive for link WinMain, wWinMain
#if !(defined _UNICODE) || (defined _WIN32_WCE)
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(WinMain,16))
#else
#pragma comment(linker, "/include:" __STD_FUNCTION_SYMBOL(wWinMain,16))
#endif

//The declaration of global variables
extern Windows::Base::IApplication* m_pApplication;

//The definition of WINDOWS_APPLICATION
#define WINDOWS_APPLICATION(a_Application) \
 \
Windows::Base::IApplication* m_pApplication = static_cast<Windows::Base::IApplication*>(&(a_Application))
  
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Application.h

\*_________________________________________________________*/
