/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Resource.hpp

    Comment:                encapsulation of Resource

    Module Name:            Windows::UserInterface::Resource

    Version:                2.0

    Build:                  13

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   1999/08/11-1999/08/11 (1.0)
                            2004/05/21-2004/05/27 (1.1.3)
                            2004/09/22-2004/09/23 (1.1.4)
                            2004/11/14-2004/11/14 (1.1.5)
                            2004/11/20-2004/11/20 (1.1.6)
                            2005/01/08-2005/01/08 (1.1.7)
                            2005/01/15-2005/01/15 (1.1.8)
                            2005/04/23-2005/04/23 (1.2)
                            2005/09/25-2005/09/25 (1.3)
                            2010/01/11-2010/01/11 (1.4)
                            2010/01/30-2010/01/30 (1.5)
                            2011/09/29-2011/09/29 (2.0)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef RESOURCE_HPP
#define RESOURCE_HPP

#include <welink.h>

//The definition of IDC_STATIC
#if !(defined IDC_STATIC)
#define IDC_STATIC ((UINT)-1)
#endif

namespace Windows
{
namespace UserInterface
{
namespace Resource
{

//The declaration of global functions
int GetStringLength(UINT a_idString, HMODULE a_hModule);

}
}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Resource.hpp

\*_________________________________________________________*/
