/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              welink.h

    Comment:                Windows Extension link directive

    Version:                2.2

    Build:                  7

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/09/23-2004/09/23 (1.0)
                            2005/08/20-2005/08/20 (1.1)
                            2010/01/26-2010/01/26 (1.2)
                            2010/02/01-2010/02/01 (1.3)
                            2010/08/05-2010/08/05 (2.0)
                            2011/08/10-2011/08/10 (2.1)
                            2011/08/10-2011/08/10 (2.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WINDOWS_EXTENSION_LINK_H
#define WINDOWS_EXTENSION_LINK_H
#if (defined _MSC_VER)

/*The pragma directive for link
*/
#if !(defined _UNICODE)

#if (defined _DAL_SHIP)
#pragma comment(lib,"we")
#elif (defined NDEBUG)
#pragma comment(lib,"wer")
#elif (defined _DEBUG)
#pragma comment(lib,"wed")
#endif

#else

#if (defined _DAL_SHIP)
#pragma comment(lib,"weu")
#elif (defined NDEBUG)
#pragma comment(lib,"weur")
#elif (defined _DEBUG)
#pragma comment(lib,"weud")
#endif

#endif

/*The definition of compatibility
*/
#if (defined _WIN32_WCE)
#if (defined _MIPS_) || (defined MIPS)
#define _M_MIPS
#endif
#endif

/*The definition of __STD_FUNCTION_SYMBOL, __C_FUNCTION_SYMBOL
*/
#if (defined _WIN32_WCE)

#if (defined _M_IX86) || (defined _M_SH)
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) "_" #a_Symbol
#elif (defined _M_ARM) || (defined _M_MIPS)
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) #a_Symbol
#else
#pragma message ("warning: unknown CPU")
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) #a_Symbol
#endif

#else

#if (defined _M_IX86)
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) "_" #a_Symbol "@" #a_nOffset
#define __C_FUNCTION_SYMBOL(a_Symbol) "_" #a_Symbol
#elif (defined _M_X64) || (defined _M_IA64)
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) #a_Symbol
#else
#pragma message ("warning: unknown CPU")
#define __STD_FUNCTION_SYMBOL(a_Symbol, a_nOffset) #a_Symbol
#endif

#endif

#if !(defined __C_FUNCTION_SYMBOL)
#define __C_FUNCTION_SYMBOL(a_Symbol) __STD_FUNCTION_SYMBOL(a_Symbol,0)
#endif

#endif
#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of welink.h

\*_________________________________________________________*/
