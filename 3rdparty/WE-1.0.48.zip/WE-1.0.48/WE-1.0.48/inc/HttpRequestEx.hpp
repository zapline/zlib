/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              HttpRequestEx.hpp

    Comment:                extension of Windows::Internet::CHttpRequest

    Class Name:             Windows::Extension::CHttpRequestEx

    Version:                2.2

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2003/01/03-2003/01/16 (1.0)
                            2008/03/30-2008/03/30 (1.1)
                            2010/02/27-2010/02/27 (2.0)
                            2010/06/04-2010/06/05 (2.1)
                            2011/08/28-2011/08/29 (2.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef HTTP_REQUEST_EXTENSION_HPP
#define HTTP_REQUEST_EXTENSION_HPP

#include <HttpRequest.hpp>
#include <welink.h>

namespace Windows
{
namespace Extension
{

//The declaration of CHttpRequestEx
class CHttpRequestEx:
    public Windows::Internet::CHttpRequest
{
public:
    CHttpRequestEx(void);
    virtual ~CHttpRequestEx(void);
    bool RequestContent(HANDLE a_hConnect, LPCTSTR a_szPath, DWORD a_dwFlags);
    bool RequestContent(HANDLE a_hConnect, LPCTSTR a_szPath, DWORD a_dwFlags, ULONGLONG a_nPosition);
    Windows::Internet::EHttpStatus SendRequestEx(void);
    bool GetTimeEx(FILETIME& a_rTime)const;
private:
    CHttpRequestEx(const CHttpRequestEx& a_rRequest);
    const CHttpRequestEx& operator=(const CHttpRequestEx& a_rRequest);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of HttpRequestEx.hpp

\*_________________________________________________________*/
