/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              WebServiceProxyI.hpp

    Comment:                interface of Web Service Client Proxy

    Class Name:             Windows::WebService::IProxy

    Version:                3.1

    Build:                  6

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2005/05/04-2005/05/04 (1.0)
                            2005/09/25-2005/09/25 (1.1)
                            2008/06/21-2008/06/21 (2.0)
                            2008/07/06-2008/07/06 (2.1)
                            2010/01/25-2010/01/26 (3.0)
                            2011/11/09-2011/11/09 (3.1)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WEB_SERVICE_PROXY_HPP
#define WEB_SERVICE_PROXY_HPP

namespace dsal { template<class t_Item> class list_i; }
namespace dsal { template<class t_Item> class basic_string; }
namespace dsal { typedef basic_string<wchar_t> wstring; }

namespace Windows
{
namespace WebService
{

//The declaration of IProxy
class IProxy
{
protected:
    inline IProxy(void){};
    inline ~IProxy(void){};
public:
    virtual void BeginAction(const wchar_t* a_szAction)=0;
    virtual bool EndAction(void)=0;
    virtual void PushParameter(const wchar_t* a_szName, const wchar_t* a_szValue)=0;
    virtual void PushParameter(const wchar_t* a_szName, int a_nValue)=0;
    virtual void PushParameter(const wchar_t* a_szName, dsal::const_list_i<dsal::wstring>* a_pValues)=0;
    virtual void PushParameter(const wchar_t* a_szName, dsal::const_list_i<int>* a_pValues)=0;
    virtual bool IsFault(void)const=0;
    virtual bool GetReturnValue(dsal::wstring& a_rsValue)const=0;
    virtual bool GetReturnValue(int& a_rnValue)const=0;
    virtual bool GetReturnParameter(const wchar_t* a_szName, dsal::wstring& a_rsValue)const=0;
    virtual bool GetReturnParameter(const wchar_t* a_szName, dsal::list_i<dsal::wstring>* a_pValues)const=0;
private:
    IProxy(const IProxy& a_rProxy);
    const IProxy& operator=(const IProxy& a_rProxy);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of WebServiceProxyI.hpp

\*_________________________________________________________*/
