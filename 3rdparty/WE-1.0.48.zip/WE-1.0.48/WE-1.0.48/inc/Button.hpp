/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Button.hpp

    Comment:                encapsulation for Button Control

    Class Name:             Windows::UserInterface::CButton

    Version:                2.5

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/05/24-2004/05/27 (1.1.3)
                            2004/09/22-2004/09/22 (1.1.4)
                            2005/01/08-2005/01/10 (2.0)
                            2005/04/24-2005/04/24 (2.1)
                            2005/09/25-2005/09/25 (2.2)
                            2010/01/16-2010/01/16 (2.3)
                            2010/01/30-2010/01/30 (2.4)
                            2011/10/06-2011/10/06 (2.5)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef BUTTON_HPP
#define BUTTON_HPP

#include <Control.hpp>
#include <welink.h>

//The definition of compatibility
#if (defined _WIN32_WCE)
#define BM_GETIMAGE 0x00F6
#define BM_SETIMAGE 0x00F7
#endif

//The definition of global functions of Button
//#define Button_Enable(a_hButton,a_bEnable) ((BOOL)EnableWindow((HWND)(a_hButton),(BOOL)(a_bEnable)))
//#define Button_GetTextLength(a_hButton) ((int)GetWindowTextLength((HWND)(a_hButton)))
//#define Button_GetText(a_hButton,a_szText,a_nBufferSize) ((int)GetWindowText((HWND)(a_hButton),(LPTSTR)(a_szText),(int)(a_nBufferSize)))
//#define Button_SetText(a_hButton,a_szText) ((BOOL)SetWindowText((HWND)(a_hButton),(LPCTSTR)(a_szText)))
//#define Button_GetCheck(a_hButton) ((UINT)SendMessage((HWND)(a_hButton),BM_GETCHECK,(WPARAM)0,(LPARAM)0))
//#define Button_SetCheck(a_hButton,a_nCheckState) ((void)SendMessage((HWND)(a_hButton),BM_SETCHECK,(WPARAM)(UINT)(a_nCheckState),(LPARAM)0))
//#define Button_GetState(a_hButton) ((UINT)SendMessage((HWND)(a_hButton),BM_GETSTATE,(WPARAM)0,(LPARAM)0))
//#define Button_SetState(a_hButton,a_bHighlight) ((void)SendMessage((HWND)(a_hButton),BM_SETSTATE,(WPARAM)(BOOL)(a_bHighlight),(LPARAM)0))
//#define Button_SetStyle(a_hButton,a_dwStyle,a_bRedraw) ((void)SendMessage((HWND)(a_hButton),BM_SETSTYLE,(WPARAM)LOWORD(a_dwStyle),MAKELPARAM((WORD)(BOOL)(a_bRedraw),(WORD)0)))
#define Button_Click(a_hButton) ((void)SendMessage((HWND)(a_hButton),BM_CLICK,(WPARAM)0,(LPARAM)0))
#define Button_GetImage(a_hButton,a_nImageType) ((HANDLE)SendMessage((HWND)(a_hButton),BM_GETIMAGE,(WPARAM)(UINT)(a_nImageType),(LPARAM)0))
#define Button_SetImage(a_hButton,a_nImageType,a_hImage) ((HANDLE)SendMessage((HWND)(a_hButton),BM_SETIMAGE,(WPARAM)(UINT)(a_nImageType),(LPARAM)(HANDLE)(a_hImage)))

namespace Windows
{
namespace UserInterface
{

//The definition of ECheckState
enum ECheckState
{
    eUnchecked     = BST_UNCHECKED, //0x0000
    eChecked       = BST_CHECKED, //0x0001
    eIndeterminate = BST_INDETERMINATE, //0x0002
    ePushed        = BST_PUSHED, //0x0004
    eFocus         = BST_FOCUS, //0x0008
};

//The declaration of CButton
class CButton:
    public CControl
{
public:
    CButton(void);
    ~CButton(void);
    ECheckState GetCheck(void);
    void SetCheck(ECheckState a_eCheckState);
    ECheckState GetState(void);
    void SetState(bool a_bHighlight);
    void SetStyle(DWORD a_dwStyle, bool a_bRedraw);
    void Click(void);
    HANDLE GetImage(EImageType a_eImageType);
    HANDLE SetImage(EImageType a_eImageType, HANDLE a_hImage);
private:
    CButton(const CButton& a_rButton);
    const CButton& operator=(const CButton& a_rButton);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Button.hpp

\*_________________________________________________________*/
