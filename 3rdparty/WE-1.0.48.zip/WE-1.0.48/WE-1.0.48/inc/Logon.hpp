/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              Logon.hpp

    Comment:                encapsulation of Winlogon GINA

    Class Name:             Windows::Security::CLogonGina
                            Windows::Security::CLogon

    Version:                2.2

    Build:                  15

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/12/25-2004/12/26 (1.0.1)
                            2004/12/29-2004/12/29 (1.0.2)
                            2005/01/09-2005/01/09 (1.0.3)
                            2005/05/04-2005/05/07 (1.1)
                            2005/07/31-2005/07/31 (1.2)
                            2005/09/25-2005/09/25 (1.3)
                            2008/06/21-2008/06/21 (1.4)
                            2010/01/25-2010/01/27 (2.0)
                            2010/01/30-2010/01/31 (2.1)
                            2011/10/07-2011/10/07 (2.2)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef LOGON_HPP
#define LOGON_HPP

#include <Dll.hpp>
#include <LogonI.hpp>
#include <LogonUserToken.hpp>
#include <welink.h>

namespace Windows
{
namespace Security
{

//The declaration of CLogonGina
class CLogonGina:
    public Base::CDll,
    public ILogonGina
{
protected:
    CLogonGina(void);
    ~CLogonGina(void);
private:
    virtual bool Negotiate(DWORD a_dwWinlogonVersion, DWORD* a_pdwLogonVersion);
    virtual ILogon* Initialize(LPCWSTR a_szWindowStation, HANDLE a_hWinlogon, const WLX_DISPATCH* a_pWinlogonFunctionTable);
private:
    CLogonGina(const CLogonGina& a_rLogonGina);
    const CLogonGina& operator=(const CLogonGina& a_rLogonGina);
};

//The declaration of CLogon
class CLogon:
    public ILogon
{
public:
    CLogon(HMODULE a_hModule, LPCWSTR a_szWindowStation, HANDLE a_hWinlogon, const WLX_DISPATCH* a_pWinlogonFunctionTable);
    virtual ~CLogon(void);
protected:
    HMODULE m_hModule;
    LPCWSTR m_szWindowStation;
    HANDLE m_hWinlogon;
    const WLX_DISPATCH* m_pWinlogonFunctionTable;
    CLogonUserToken m_UserToken;
    WCHAR m_acUserName[UNLEN+1+DNLEN+1]; //"domain/user", or "user@domain"
public:
    static LPWSTR DuplicateString(LPCWSTR a_szString);
protected:
    bool Login(LPCWSTR a_szUserName, LPCWSTR a_szDomain, LPCWSTR a_szPassword, LUID& a_rAuthenticationId, SID& a_rLogonSid);
    void Logout(void);
private:
    virtual bool DisplayStatusMessage(HDESK a_hDesktop, DWORD a_dwOptions, LPCWSTR a_szTitle, LPCWSTR a_szMessage);
    virtual bool RemoveStatusMessage(void);
    virtual void DisplaySASNotice(void);
    virtual void DisplayLockedNotice(void);
    virtual int LoggedOutSAS(DWORD a_dwSasType, LUID& a_rAuthenticationId, SID& a_rLogonSid, DWORD& a_rdwOptions, HANDLE& a_rhToken, WLX_MPR_NOTIFY_INFO& a_rNetworkProviderNotifyInfo, PWLX_PROFILE& a_rpProfile);
    virtual int LoggedOnSAS(DWORD a_dwSasType);
    virtual int LockedSAS(DWORD a_dwSasType);
    virtual bool ActivateUserShell(LPCWSTR a_szDesktopName, LPCWSTR a_szNetworkProviderLogonScript, void* a_pEnvironment);
    virtual bool StartApplication(LPCWSTR a_szDesktopName, LPCWSTR a_szCommandLine, void* a_pEnvironment);
    virtual void Logoff(void);
    virtual void Shutdown(DWORD a_dwShutdownType);
    virtual bool IsLockOK(void);
    virtual bool IsLogoffOK(void);
    virtual bool ScreenSaverNotify(bool a_bSecure, bool& a_rbLock);
    virtual bool GetConsoleSwitchCredentials(WLX_CONSOLESWITCH_CREDENTIALS_INFO& a_rInfo);
    virtual bool GetStatusMessage(DWORD& a_rdwOptions, LPWSTR a_szMessage, DWORD a_dwBufferSize);
    virtual bool NetworkProviderLoad(WLX_MPR_NOTIFY_INFO& a_rNetworkProviderNotifyInfo);
    virtual void DisconnectNotify(void);
    virtual void ReconnectNotify(void);
private:
    CLogon(const CLogon& a_rLogon);
    const CLogon& operator=(const CLogon& a_rLogon);
};

}
}

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of Logon.hpp

\*_________________________________________________________*/
