/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    File Name:              wedef.h

    Comment:                Windows Extension definition

    Version:                2.3

    Build:                  10

    Author:                 Dong Fang (Walter Dong)

    Contact:                dongfang@ustc.edu
                            dongf@live.com

    Time:                   2004/11/06-2004/11/06 (1.0.1)
                            2005/05/04-2005/05/04 (1.0.2)
                            2010/01/16-2010/02/01 (2.0)
                            2010/09/26-2010/09/26 (2.1)
                            2011/08/09-2011/08/09 (2.2)
                            2011/10/07-2011/10/07 (2.3)

    Notice:
    Copyright (C) 2010-2011, Dong Fang (Walter Dong).
    All rights reserved.
    This file is part of Windows Extension (WE).

    This software is published under the terms of FreeBSD-style license.
    To get license other than FreeBSD-style, contact Dong Fang (Walter Dong).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY DONG FANG (WALTER DONG) "AS IS" AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL DONG FANG (WALTER DONG) BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

\*_________________________________________________________*/
#ifndef WINDOWS_EXTENSION_DEFINE_H
#define WINDOWS_EXTENSION_DEFINE_H

#if (defined _MSC_VER)
/*Microsoft eMbedded Visual C++ 4.0
*/
#if (defined _WIN32_WCE)
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
#pragma warning(disable:4514) /* Compiler Warning (level 4), 'function' : unreferenced inline function has been removed */
#pragma warning(push)
#pragma warning(disable:4052) /* Compiler Warning (level 1), function declarations different; one contains variable arguments */
#pragma warning(disable:4115) /* Compiler Warning (level 4), 'type' : named type definition in parentheses */
#pragma warning(disable:4201) /* Compiler Warning (level 4), nonstandard extension used : nameless struct/union */
#pragma warning(disable:4214) /* Compiler Warning (level 4), nonstandard extension used : bit field types other than int */
#endif
#endif
#endif

#include <windows.h>

#if (defined _MSC_VER)
/*Microsoft eMbedded Visual C++ 4.0
*/
#if (defined _WIN32_WCE)
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
#pragma warning(pop)
#endif
#endif
#endif

/*The definition of capability __CAPABILITY__PRAGMA_MESSAGE
*/
#if !(defined __CAPABILITY__PRAGMA_MESSAGE)
#if (defined _MSC_VER)
    #define __CAPABILITY__PRAGMA_MESSAGE
#elif (defined __GNUC__) && ((__GNUC__<4) || ((__GNUC__==4) && (__GNUC_MINOR__<=2)))
    /* gcc version below 4, gcc 4.2 does not support pragma message */
#else
    #define __CAPABILITY__PRAGMA_MESSAGE
#endif
#endif

/*The definition of _UNICODE, UNICODE
*/
#if (defined _UNICODE)
#elif (defined UNICODE)
    #define _UNICODE
        #if (defined __CAPABILITY__PRAGMA_MESSAGE)
        #pragma message ("warning: UNICODE defined, treated as the same meaning of _UNICODE")
        #endif
#endif

/*The definition of __UNREFERENCED_PARAMETER
*/
#if !(defined __UNREFERENCED_PARAMETER)
#define __UNREFERENCED_PARAMETER(a_Variable) (void)(a_Variable)
#endif

/*The definition of __ARRAY_ITEM_COUNT
*/
#if !(defined __ARRAY_ITEM_COUNT)
#define __ARRAY_ITEM_COUNT(a_Array) (sizeof(a_Array)/sizeof(a_Array[0]))
#endif

/*The definition of __WIDE_TEXT
*/
#if !(defined __WIDE_TEXT)
    #if (defined __L_TEXT)
    #undef __L_TEXT
        #if (defined __CAPABILITY__PRAGMA_MESSAGE)
        #pragma message ("warning: __L_TEXT defined previously, undefine previous __L_TEXT")
        #endif
    #endif
#define __L_TEXT(a_Text) L##a_Text
#define __WIDE_TEXT(a_Text) __L_TEXT(a_Text)
#endif

/*The definition of MAX_STRLEN_*
*/
#define MAX_STRLEN_INT  11 //[0x80000000,0x7FFFFFFF] = [-2147483648,2147483647]
#define MAX_STRLEN_UINT 10 //[0x00000000,0xFFFFFFFF] = [0,4294967295]
#define MAX_STRLEN_LONG  11 //[0x80000000,0x7FFFFFFF] = [-2147483648,2147483647]
#define MAX_STRLEN_ULONG 10 //[0x00000000,0xFFFFFFFF] = [0,4294967295]
#define MAX_STRLEN_LONGLONG  20 //[0x8000000000000000,0x7FFFFFFFFFFFFFFF] = [-9223372036854775808,9223372036854775807]
#define MAX_STRLEN_ULONGLONG 20 //[0x0000000000000000,0xFFFFFFFFFFFFFFFF] = [0,18446744073709551615]
#define MAX_STRLEN_DWORD 10 //[0x00000000,0xFFFFFFFF] = [0,4294967295]
#define MAX_STRLEN_QWORD 20 //[0x0000000000000000,0xFFFFFFFFFFFFFFFF] = [0,18446744073709551615]

/*The definition of LONGLONG_MAX, LONGLONG_MIN, ULONGLONG_MAX
*/
#if !(defined LONGLONG_MAX)
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
#define LONGLONG_MAX (LONGLONG)(0x7FFFFFFFFFFFFFFFI64)
#else
#define LONGLONG_MAX (LONGLONG)(0x7FFFFFFFFFFFFFFFLL)
#endif
#endif

#if !(defined LONGLONG_MIN)
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
#define LONGLONG_MIN (LONGLONG)(0x8000000000000000I64)
#else
#define LONGLONG_MIN (LONGLONG)(0x8000000000000000LL)
#endif
#endif

#if !(defined ULONGLONG_MAX)
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
#define ULONGLONG_MAX (ULONGLONG)(0xFFFFFFFFFFFFFFFFI64)
#else
#define ULONGLONG_MAX (ULONGLONG)(0xFFFFFFFFFFFFFFFFLL)
#endif
#endif

/*The definition of QWORD
*/
typedef unsigned __int64 QWORD;

/*The definition of MAKEDWORD, MAKEQWORD, LODWORD, HIDWORD
*/
#define MAKEDWORD(wLow, wHigh) ((DWORD)(((DWORD)(WORD)(wLow))|(((DWORD)(WORD)(wHigh))<<16)))
#define MAKEQWORD(dwLow, dwHigh) ((QWORD)(((QWORD)(DWORD)(dwLow))|(((QWORD)(DWORD)(dwHigh))<<32)))
#define LODWORD(qwValue) ((DWORD)(QWORD)(qwValue))
#define HIDWORD(qwValue) ((DWORD)(((QWORD)(qwValue))>>32))

/*The definition of compatibility
*/
#if (_MSC_VER==1200) || (_MSC_VER==1201) || (_MSC_VER==1202)
typedef __int64 long_long;
typedef unsigned __int64 unsigned_long_long;
#else
typedef long long long_long;
typedef unsigned long long unsigned_long_long;
#endif

#endif
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*\

    End of wedef.h

\*_________________________________________________________*/
